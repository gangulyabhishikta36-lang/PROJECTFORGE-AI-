"""
persistence_manager.py
======================
Server-side persistence and export manager for ProjectForge AI.
Handles atomic project saves, safe file retrieval, progress tracking,
and sanitized ZIP project packaging.
"""

import os
import json
import zipfile
import io
import re
import tempfile
import time
from typing import Dict, Any, Optional, List


class PersistenceManager:
    DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "projects")

    @classmethod
    def _ensure_dir(cls):
        os.makedirs(cls.DATA_DIR, exist_ok=True)

    @classmethod
    def _sanitize_id(cls, project_id: str) -> str:
        """Sanitizes project ID to prevent directory traversal attacks."""
        if not project_id or not isinstance(project_id, str):
            raise ValueError("Invalid project ID.")
        clean = re.sub(r"[^a-zA-Z0-9_-]", "", project_id)
        if not clean:
            raise ValueError("Project ID contained only invalid characters.")
        return clean

    @classmethod
    def get_project_path(cls, project_id: str) -> str:
        cls._ensure_dir()
        safe_id = cls._sanitize_id(project_id)
        return os.path.join(cls.DATA_DIR, f"{safe_id}.json")

    @classmethod
    def save_project(cls, project_data: Dict[str, Any]) -> str:
        """
        Atomically saves project state to disk.
        Uses write-to-temp + rename to protect against interrupted writes.
        """
        cls._ensure_dir()
        project_id = project_data.get("id")
        if not project_id:
            raise ValueError("Cannot save project without an 'id' attribute.")

        safe_id = cls._sanitize_id(project_id)
        target_path = cls.get_project_path(safe_id)

        # Update saved timestamp
        project_data["updated_at"] = time.time()
        if "created_at" not in project_data:
            project_data["created_at"] = time.time()

        # Write to temporary file in same directory then atomically rename
        temp_fd, temp_path = tempfile.mkstemp(dir=cls.DATA_DIR, prefix=f"tmp_{safe_id}_", suffix=".json")
        try:
            with os.fdopen(temp_fd, "w", encoding="utf-8") as f:
                json.dump(project_data, f, indent=2, ensure_ascii=False)
            # Atomic replace
            os.replace(temp_path, target_path)
        except Exception:
            if os.path.exists(temp_path):
                os.remove(temp_path)
            raise

        return safe_id

    @classmethod
    def get_project(cls, project_id: str) -> Optional[Dict[str, Any]]:
        """Retrieves project state from disk. Returns None if not found."""
        try:
            path = cls.get_project_path(project_id)
            if not os.path.exists(path):
                return None
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return None

    @classmethod
    def update_learner_progress(
        cls,
        project_id: str,
        files: Optional[List[Dict[str, Any]]] = None,
        active_milestone_id: Optional[str] = None,
        verification_update: Optional[Dict[str, Any]] = None,
        layer3_update: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Updates and persists learner code, active milestone, and verification history."""
        project = cls.get_project(project_id)
        if not project:
            raise ValueError(f"Project '{project_id}' not found.")

        if files is not None:
            # Validate files list
            if not isinstance(files, list):
                raise ValueError("Files must be a list of file dictionaries.")
            project["files"] = files

        if active_milestone_id is not None:
            project["active_milestone_id"] = active_milestone_id

        if verification_update:
            if "verification_history" not in project:
                project["verification_history"] = []
            project["verification_history"].append(verification_update)

        if layer3_update:
            if "mastery_assessments" not in project:
                project["mastery_assessments"] = {}
            m_id = layer3_update.get("milestone_id", "m_default")
            project["mastery_assessments"][m_id] = layer3_update

        cls.save_project(project)
        return project

    @classmethod
    def export_project_zip(cls, project_id: str) -> io.BytesIO:
        """
        Generates an in-memory ZIP archive of learner project files and README summary.
        Sanitizes filenames to prevent path traversal in zip extraction.
        Excludes any sensitive environment or grading secrets.
        """
        project = cls.get_project(project_id)
        if not project:
            raise ValueError(f"Project '{project_id}' not found.")

        buffer = io.BytesIO()
        with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as zf:
            # 1. Write user files
            for file_entry in project.get("files", []):
                fname = file_entry.get("name", "untitled.txt")
                # Sanitize filename
                safe_name = re.sub(r"[^\w\.-]", "_", os.path.basename(fname))
                content = file_entry.get("content", "")
                zf.writestr(safe_name, content.encode("utf-8"))

            # 2. Write project summary & mastery report
            title = project.get("title", "Project")
            domain = project.get("domain", "Unknown")
            diff = project.get("difficulty_profile", {}).get("master_difficulty", 5)
            mastery = project.get("mastery_assessments", {})

            readme_text = (
                f"# {title}\n\n"
                f"Generated by ProjectForge AI\n"
                f"- Domain: {domain}\n"
                f"- Master Difficulty: {diff}/10\n\n"
                f"## Learning Objectives\n"
            )
            for obj in project.get("learning_objectives", []):
                readme_text += f"- {obj}\n"

            readme_text += "\n## Milestone Completion & Mastery Status\n"
            for m in project.get("milestones", []):
                m_id = m["id"]
                m_assessed = mastery.get(m_id, {})
                status_icon = " [Mastered]" if m_assessed.get("passed") else " [Completed]"
                readme_text += f"- **{m.get('title')}**{status_icon}\n"

            zf.writestr("PROJECT_MASTERY_REPORT.md", readme_text.encode("utf-8"))

        buffer.seek(0)
        return buffer
