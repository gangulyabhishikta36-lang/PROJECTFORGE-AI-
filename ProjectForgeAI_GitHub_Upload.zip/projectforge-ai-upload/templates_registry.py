"""
templates_registry.py
=====================
Curated educational project templates with known, deterministic test criteria.
"""

from typing import List, Dict, Any


CURATED_TEMPLATES: List[Dict[str, Any]] = [
    {
        "template_id": "tpl_linear_regression",
        "title": "Linear Regression with Gradient Descent from Scratch",
        "description": "Formulate hypothesis, loss surfaces, and analytical gradient updates in pure Python with loss convergence verification.",
        "domain": "data_science",
        "difficulty_range": [3, 7],
        "prerequisites": ["Python variables & loops", "Derivatives intuition", "Basic coordinate geometry"],
        "learning_objectives": [
            "Compute Mean Squared Error (MSE)",
            "Derive and apply gradient updates analytically",
            "Monitor loss convergence and tune learning rates",
        ],
        "supported_execution_mode": "browser_pyodide",
        "template_version": "1.2.0",
        "prompt": "Build a linear regression model from scratch using gradient descent.",
    },
    {
        "template_id": "tpl_orbital_gravity",
        "title": "Planetary Orbit N-Body Gravitational Simulation",
        "description": "Simulate gravitational orbital dynamics on HTML5 Canvas, measuring energy drift and contrasting Euler with Verlet integrators.",
        "domain": "simulation",
        "difficulty_range": [4, 9],
        "prerequisites": ["Newton's Second Law", "Trigonometry & Vectors", "HTML5 Canvas basic API"],
        "learning_objectives": [
            "Decompose gravitational forces into Cartesian components",
            "Implement numerical integration timesteps",
            "Evaluate mechanical energy conservation and numerical drift",
        ],
        "supported_execution_mode": "browser_iframe",
        "template_version": "1.1.0",
        "prompt": "Build a planetary orbit gravitational physics simulation with canvas and energy conservation.",
    },
    {
        "template_id": "tpl_cellular_automata",
        "title": "Interactive Cellular Automata & Epidemic Contagion Model",
        "description": "Construct an interactive grid simulation modeling pathogen spread (SIR model) with dynamic parameter sliders and real-time canvas rendering.",
        "domain": "simulation",
        "difficulty_range": [3, 8],
        "prerequisites": ["2D Arrays / Matrices", "Conditional logic", "Basic probabilities"],
        "learning_objectives": [
            "Model state transitions on 2D grid graphs",
            "Measure infection curves and herd immunity thresholds",
            "Optimize grid updates with double-buffering",
        ],
        "supported_execution_mode": "browser_iframe",
        "template_version": "1.0.0",
        "prompt": "Build an interactive cellular automata simulation of epidemic spread with canvas.",
    },
    {
        "template_id": "tpl_sorting_visualizer",
        "title": "Algorithmic Sorting Engine & Time-Complexity Visualizer",
        "description": "Implement Quicksort and Merge Sort with real-time comparison counters, recursion stack meters, and visual bar animation.",
        "domain": "algorithms",
        "difficulty_range": [2, 6],
        "prerequisites": ["Recursion basics", "Arrays & swapping", "Asymptotic O(n) notation"],
        "learning_objectives": [
            "Understand divide-and-conquer partitioning",
            "Instrument algorithms to count operations accurately",
            "Contrast average vs. worst-case complexity",
        ],
        "supported_execution_mode": "browser_iframe",
        "template_version": "1.0.0",
        "prompt": "Build an interactive sorting algorithm visualizer with comparison counters.",
    },
]


def get_all_templates() -> List[Dict[str, Any]]:
    return CURATED_TEMPLATES


def get_template_by_id(template_id: str) -> Dict[str, Any]:
    for tpl in CURATED_TEMPLATES:
        if tpl["template_id"] == template_id:
            return tpl
    return None
