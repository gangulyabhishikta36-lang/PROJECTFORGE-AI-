"""
difficulty_engine.py
====================
Calibrates and validates 4-dimensional difficulty profiles for ProjectForge AI.
Dimensions:
  - conceptual: 1-10 (Theoretical abstraction, mathematical rigor)
  - implementation: 1-10 (Architecture, code volume, plumbing complexity)
  - prerequisite: 1-10 (Assumed foundational domain knowledge)
  - independence: 1-10 (How much is devised unaided vs. guided)
"""

from typing import Dict, Any, Tuple


class DifficultyEngine:
    DIMENSIONS = ("conceptual", "implementation", "prerequisite", "independence")

    @classmethod
    def calculate_preset(cls, master_difficulty: int) -> Dict[str, int]:
        """
        Derives a balanced 4-dimensional profile from a master slider value (1 to 10).
        Different levels emphasize different growth curves:
          - Level 1-2: Foundations (Low concepts, low implementation, zero prereqs, high guidance)
          - Level 3-4: Apprentice (Guided building, introduction of formal domain concepts)
          - Level 5-6: Moderate (Balanced architecture, real-world constraints)
          - Level 7-8: Advanced (Algorithmic rigor, async/modular design, high independence)
          - Level 9-10: Mastery (Deep mathematical/systems theory, production architecture, full autonomy)
        """
        d = max(1, min(10, int(master_difficulty)))

        # Calibrate dimensions with smooth pedagogical scaling
        conceptual = d
        # Implementation scales slightly faster in mid-tier, plateauing at rigorous clean code
        implementation = min(10, max(1, round(d * 0.95)))
        # Prerequisite depth stays forgiving in early levels
        prerequisite = max(1, round((d - 1) * 0.9 + 1))
        # Independence scales steadily: low levels have high hand-holding (low independence)
        independence = d

        return {
            "conceptual": int(conceptual),
            "implementation": int(implementation),
            "prerequisite": int(prerequisite),
            "independence": int(independence),
            "master_difficulty": d,
        }

    @classmethod
    def validate_profile(cls, profile: Dict[str, Any]) -> Tuple[bool, str, Dict[str, int]]:
        """
        Validates an incoming 4D profile.
        Returns (is_valid, error_message, sanitized_profile).
        """
        if not isinstance(profile, dict):
            return False, "Difficulty profile must be a key-value dictionary.", {}

        sanitized: Dict[str, int] = {}
        for dim in cls.DIMENSIONS:
            if dim not in profile:
                return False, f"Missing difficulty dimension: '{dim}'.", {}
            val = profile[dim]
            try:
                int_val = int(val)
            except (ValueError, TypeError):
                return False, f"Dimension '{dim}' must be an integer between 1 and 10.", {}

            if not (1 <= int_val <= 10):
                return False, f"Dimension '{dim}' must be between 1 and 10 (received {int_val}).", {}

            sanitized[dim] = int_val

        # Calculate effective aggregate difficulty
        avg_diff = sum(sanitized.values()) / len(cls.DIMENSIONS)
        sanitized["master_difficulty"] = round(avg_diff)

        return True, "", sanitized

    @classmethod
    def get_pedagogical_parameters(cls, profile: Dict[str, int]) -> Dict[str, Any]:
        """
        Derives operational pedagogical constraints based on the 4D profile:
          - scaffolding_ratio: % of starter code boilerplate provided (85% down to 5%)
          - milestone_count: recommended number of steps (3 to 6)
          - hint_tier_limit: level of initial assistance permitted
          - tolerance_strictness: numerical tolerance margin for calculations
        """
        c = profile.get("conceptual", 5)
        imp = profile.get("implementation", 5)
        ind = profile.get("independence", 5)

        # Scaffolding inverse of independence & implementation
        scaffolding_ratio = max(5, min(85, round(95 - (ind * 5.5 + imp * 3.5))))

        # Number of milestones
        if ind <= 3:
            milestones = 3  # short, manageable bites
        elif ind <= 7:
            milestones = 4
        else:
            milestones = 5  # comprehensive engineering pipeline

        # Numerical tolerance strictness for Layer 2 verifications (lower = tighter)
        # e.g., Level 1 allows 5% tolerance, Level 10 requires 0.05%
        tolerance_margin = max(0.0005, 0.05 * (1.1 - (c / 10.0)))

        return {
            "scaffolding_ratio_pct": scaffolding_ratio,
            "recommended_milestones": milestones,
            "numerical_tolerance": round(tolerance_margin, 5),
            "theory_depth": "formal" if c >= 7 else "applied" if c >= 4 else "intuitive",
            "autonomy_mode": "autonomous" if ind >= 8 else "scaffolded" if ind >= 4 else "guided",
        }
