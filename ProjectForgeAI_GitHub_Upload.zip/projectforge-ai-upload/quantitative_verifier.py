"""
quantitative_verifier.py
=========================
Rigorously checks mathematical, statistical, and simulation invariants for Layer 2.
Evaluates numerical tolerances, physical conservation laws, loss convergence,
and boundary conditions without executing arbitrary client code on the server.
"""

import math
from typing import Dict, Any, List, Union


class QuantitativeVerifier:
    @staticmethod
    def is_close(actual: float, expected: float, rtol: float = 1e-4, atol: float = 1e-5) -> bool:
        """Evaluates whether actual is within floating point tolerance of expected."""
        try:
            act = float(actual)
            exp = float(expected)
            if math.isnan(act) or math.isnan(exp):
                return False
            if math.isinf(act) or math.isinf(exp):
                return act == exp
            return abs(act - exp) <= (atol + rtol * abs(exp))
        except (ValueError, TypeError, OverflowError):
            return False

    @classmethod
    def verify_numerical_arrays(
        cls, actual_array: List[float], expected_array: List[float], rtol: float = 1e-3, atol: float = 1e-4
    ) -> Dict[str, Any]:
        """Compares two numerical vectors with element-wise tolerance check."""
        if not isinstance(actual_array, list) or not isinstance(expected_array, list):
            return {
                "passed": False,
                "reason": "Arrays must be lists of numerical values.",
                "max_error": None,
            }

        if len(actual_array) != len(expected_array):
            return {
                "passed": False,
                "reason": f"Dimension mismatch: expected {len(expected_array)} elements, received {len(actual_array)}.",
                "max_error": None,
            }

        max_err = 0.0
        mismatches = []
        for i, (act, exp) in enumerate(zip(actual_array, expected_array)):
            try:
                a_f, e_f = float(act), float(exp)
                diff = abs(a_f - e_f)
                if diff > max_err:
                    max_err = diff
                if not cls.is_close(a_f, e_f, rtol=rtol, atol=atol):
                    mismatches.append({"index": i, "actual": a_f, "expected": e_f, "error": diff})
            except (ValueError, TypeError):
                return {
                    "passed": False,
                    "reason": f"Non-numerical value at index {i}.",
                    "max_error": None,
                }

        passed = len(mismatches) == 0
        return {
            "passed": passed,
            "max_error": max_err,
            "mismatch_count": len(mismatches),
            "sample_mismatches": mismatches[:3],
        }

    @classmethod
    def verify_energy_conservation(
        cls, initial_energy: float, final_energy: float, tolerance: float = 0.02
    ) -> Dict[str, Any]:
        """
        Verifies Hamiltonian/energy conservation in dynamic or orbital simulations:
        |E_final - E_initial| / |E_initial| <= tolerance
        """
        try:
            e0 = float(initial_energy)
            e_final = float(final_energy)
            if abs(e0) < 1e-12:
                diff = abs(e_final - e0)
                passed = diff <= tolerance
                drift_pct = diff * 100
            else:
                drift_pct = (abs(e_final - e0) / abs(e0)) * 100
                passed = (drift_pct / 100.0) <= tolerance

            return {
                "passed": passed,
                "drift_percentage": round(drift_pct, 4),
                "tolerance_percentage": round(tolerance * 100, 4),
                "reason": (
                    f"Energy drift was {drift_pct:.2f}%, within the {tolerance * 100:.2f}% limit."
                    if passed
                    else f"Energy drift was {drift_pct:.2f}%, which exceeds the allowable {tolerance * 100:.2f}% limit. Check integration timestep or Euler vs. Verlet formulation."
                ),
            }
        except (ValueError, TypeError, ZeroDivisionError) as e:
            return {"passed": False, "reason": f"Invalid energy values provided: {str(e)}"}

    @classmethod
    def verify_loss_convergence(
        cls, loss_history: List[float], min_reduction_pct: float = 50.0, require_monotonic_trend: bool = True
    ) -> Dict[str, Any]:
        """
        Verifies gradient descent convergence:
        1. Loss decreases significantly from initial to final epoch.
        2. Average downward trend (loss isn't diverging or oscillating chaotically).
        """
        if not loss_history or len(loss_history) < 2:
            return {"passed": False, "reason": "Loss history must contain at least 2 recorded epochs."}

        try:
            losses = [float(x) for x in loss_history]
        except (ValueError, TypeError):
            return {"passed": False, "reason": "Loss values must be numerical."}

        initial_loss = losses[0]
        final_loss = losses[-1]

        if math.isnan(final_loss) or math.isinf(final_loss):
            return {
                "passed": False,
                "reason": "Loss exploded to NaN or Inf. The learning rate is likely too high.",
            }

        if final_loss > initial_loss:
            return {
                "passed": False,
                "reason": f"Loss increased from {initial_loss:.4f} to {final_loss:.4f}. Model is diverging. Reduce learning rate or check gradient signs.",
            }

        reduction_pct = ((initial_loss - final_loss) / (abs(initial_loss) + 1e-8)) * 100
        if reduction_pct < min_reduction_pct:
            return {
                "passed": False,
                "reason": f"Loss reduction was only {reduction_pct:.1f}% (required >= {min_reduction_pct}%). Train for more iterations or adjust learning rate.",
            }

        return {
            "passed": True,
            "reduction_percentage": round(reduction_pct, 2),
            "initial_loss": round(initial_loss, 4),
            "final_loss": round(final_loss, 4),
            "reason": f"Loss smoothly reduced by {reduction_pct:.1f}% across training epochs.",
        }

    @classmethod
    def evaluate_check(cls, check_spec: Dict[str, Any], evaluation_payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        Evaluates a single Layer 2 deterministic or quantitative check specification against
        learner-submitted output data.
        """
        check_type = check_spec.get("type", "scalar_match")
        check_id = check_spec.get("id", "check")
        name = check_spec.get("name", "Verification Check")

        if check_type == "scalar_match":
            key = check_spec.get("payload_key", check_id)
            actual = evaluation_payload.get(key)
            expected = check_spec.get("expected")
            rtol = float(check_spec.get("rtol", 1e-3))
            atol = float(check_spec.get("atol", 1e-4))

            if actual is None:
                return {
                    "check_id": check_id,
                    "name": name,
                    "passed": False,
                    "status": "fail",
                    "diagnostic": f"Missing expected output field: '{key}'.",
                }

            passed = cls.is_close(actual, expected, rtol=rtol, atol=atol)
            return {
                "check_id": check_id,
                "name": name,
                "passed": passed,
                "status": "pass" if passed else "fail",
                "actual": actual,
                "expected": expected,
                "diagnostic": (
                    f"Passed: {actual} is within tolerance of {expected}."
                    if passed
                    else f"Failed: got {actual}, expected {expected} (margin: ±{atol + rtol * abs(expected):.4f})."
                ),
            }

        elif check_type == "array_tolerance":
            key = check_spec.get("payload_key", check_id)
            actual_arr = evaluation_payload.get(key, [])
            expected_arr = check_spec.get("expected", [])
            rtol = float(check_spec.get("rtol", 1e-3))
            atol = float(check_spec.get("atol", 1e-4))

            res = cls.verify_numerical_arrays(actual_arr, expected_arr, rtol=rtol, atol=atol)
            if res["passed"]:
                diag_msg = f"Passed: all {len(actual_arr)} values matched reference within tolerance."
            else:
                reason = res.get("reason")
                max_err = res.get("max_error")
                diag_msg = f"Failed: {reason}." if reason else f"Failed: Max error was {max_err}."
            return {
                "check_id": check_id,
                "name": name,
                "passed": res["passed"],
                "status": "pass" if res["passed"] else "fail",
                "diagnostic": diag_msg,
                "details": res,
            }

        elif check_type == "energy_conservation":
            e0 = evaluation_payload.get("initial_energy")
            ef = evaluation_payload.get("final_energy")
            tol = float(check_spec.get("tolerance", 0.05))

            res = cls.verify_energy_conservation(e0, ef, tolerance=tol)
            return {
                "check_id": check_id,
                "name": name,
                "passed": res["passed"],
                "status": "pass" if res["passed"] else "fail",
                "diagnostic": res.get("reason"),
                "details": res,
            }

        elif check_type == "loss_convergence":
            loss_hist = evaluation_payload.get("loss_history", [])
            min_red = float(check_spec.get("min_reduction_pct", 50.0))
            res = cls.verify_loss_convergence(loss_hist, min_reduction_pct=min_red)
            return {
                "check_id": check_id,
                "name": name,
                "passed": res["passed"],
                "status": "pass" if res["passed"] else "fail",
                "diagnostic": res.get("reason"),
                "details": res,
            }

        elif check_type == "boolean_assertion":
            key = check_spec.get("payload_key", check_id)
            if key not in evaluation_payload:
                return {
                    "check_id": check_id,
                    "name": name,
                    "passed": False,
                    "status": "fail",
                    "diagnostic": f"Missing required payload field: '{key}'.",
                }
            actual = evaluation_payload.get(key)
            expected = bool(check_spec.get("expected", True))
            passed = (actual is not None) and (actual == expected)
            return {
                "check_id": check_id,
                "name": name,
                "passed": passed,
                "status": "pass" if passed else "fail",
                "diagnostic": (
                    f"Passed: {name} satisfied."
                    if passed
                    else f"Failed: condition '{name}' not satisfied (got {actual}, expected {expected})."
                ),
            }

        elif check_type in ("unverified_placeholder", "unverified_specification", "none"):
            return {
                "check_id": check_id,
                "name": name,
                "passed": False,
                "status": "unable_to_verify",
                "diagnostic": "Check cannot be verified: no deterministic verification criteria exist.",
            }

        return {
            "check_id": check_id,
            "name": name,
            "passed": False,
            "status": "unable_to_verify",
            "diagnostic": f"Unknown verification check type: '{check_type}'.",
        }
