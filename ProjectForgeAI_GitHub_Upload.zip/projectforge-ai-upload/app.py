"""
app.py
======
Main Flask Application for ProjectForge AI.
Establishes hardened, predictable API contracts, centralized correlation tracking,
strict input validation, security headers, and domain service coordination.
"""

import os
import uuid
import time
import logging
from typing import Dict, Any, Tuple
from flask import Flask, request, jsonify, render_template, send_file, Response, stream_with_context

from difficulty_engine import DifficultyEngine
from quantitative_verifier import QuantitativeVerifier
from llm_gateway import LLMGateway
from curriculum_generator import CurriculumGenerator
from persistence_manager import PersistenceManager
import templates_registry
from blueprint_engine import BlueprintEngine, KnowledgeRetrievalContract
from knowledge_retriever import KnowledgeRetriever
from project_generator import (
    GenerationOrchestrator,
    ProjectRepairEngine,
    VerificationIntegrator,
    VerificationStatus,
    QualityStatus
)

# Configure logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("projectforge")

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 2 * 1024 * 1024  # 2 MB request limit
app.config["SECRET_KEY"] = os.getenv("SECRET_KEY") or os.urandom(32)

# Initialize Domain Services
llm_gateway = LLMGateway()
curriculum_gen = CurriculumGenerator(llm_gateway=llm_gateway)


# ---------------------------------------------------------
# Request Correlation & Security Middleware
# ---------------------------------------------------------
@app.before_request
def before_request_hook():
    req_id = request.headers.get("X-Request-ID")
    if not req_id:
        req_id = f"req_{uuid.uuid4().hex[:12]}"
    request.request_id = req_id


@app.after_request
def apply_security_headers(response):
    response.headers["X-Request-ID"] = getattr(request, "request_id", "unknown")
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "SAMEORIGIN"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    return response


# ---------------------------------------------------------
# Standard Error Normalization Helper
# ---------------------------------------------------------
def error_response(code: str, message: str, status_code: int = 400, details: Dict[str, Any] = None) -> Tuple[Response, int]:
    req_id = getattr(request, "request_id", f"req_{uuid.uuid4().hex[:12]}")
    payload = {
        "error": {
            "code": code,
            "message": message,
            "details": details or {},
            "request_id": req_id,
        }
    }
    return jsonify(payload), status_code


@app.errorhandler(400)
def handle_bad_request(e):
    return error_response("BAD_REQUEST", "The request body was malformed or could not be decoded.", 400)


@app.errorhandler(404)
def handle_not_found(e):
    return error_response("NOT_FOUND", "The requested resource could not be found.", 404)


@app.errorhandler(405)
def handle_method_not_allowed(e):
    return error_response("METHOD_NOT_ALLOWED", "HTTP method is not allowed for this route.", 405)


@app.errorhandler(413)
def handle_payload_too_large(e):
    return error_response("PAYLOAD_TOO_LARGE", "The request payload exceeds the 2 MB limit.", 413)


@app.errorhandler(500)
def handle_internal_error(e):
    logger.error(f"Internal unhandled error: {str(e)}")
    return error_response("INTERNAL_ERROR", "An unexpected server error occurred. Please try again later.", 500)


# ---------------------------------------------------------
# Web Routes
# ---------------------------------------------------------
@app.route("/")
def index():
    """Serves the single-page client workspace application."""
    return render_template("index.html")


# ---------------------------------------------------------
# API Endpoints
# ---------------------------------------------------------
@app.route("/api/config", methods=["GET"])
def get_config():
    """Returns client-safe configuration without leaking API keys or secrets."""
    config = llm_gateway.get_public_config()
    return jsonify({
        "status": "success",
        "config": config,
        "request_id": request.request_id,
    })


@app.route("/api/templates", methods=["GET"])
def list_templates():
    """Returns curated educational templates with testable criteria."""
    templates = templates_registry.get_all_templates()
    return jsonify({
        "status": "success",
        "templates": templates,
        "request_id": request.request_id,
    })


@app.route("/api/project/generate", methods=["POST"])
def generate_project():
    """
    Generates a structured educational project curriculum from prompt and 4D difficulty.
    Enforces validation and returns clarification when prompts are ambiguous.
    """
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return error_response("INVALID_JSON", "Request body must be a valid JSON object.", 400)

    prompt = data.get("prompt")
    if not prompt or not isinstance(prompt, str) or len(prompt.strip()) < 3:
        return error_response("VALIDATION_ERROR", "The 'prompt' field is required and must be at least 3 characters.", 422)

    difficulty = data.get("difficulty", 5)
    try:
        difficulty = int(difficulty)
        if not (1 <= difficulty <= 10):
            return error_response("VALIDATION_ERROR", "The 'difficulty' must be an integer between 1 and 10.", 422)
    except (ValueError, TypeError):
        return error_response("VALIDATION_ERROR", "The 'difficulty' must be an integer between 1 and 10.", 422)

    persona = data.get("persona", "student")
    if persona not in ("student", "educator"):
        return error_response("VALIDATION_ERROR", "Persona must be 'student' or 'educator'.", 422)

    domain = data.get("domain", "auto")
    valid_domains = ("auto", "python", "data_science", "simulation", "web", "algorithms")
    if domain not in valid_domains:
        return error_response("VALIDATION_ERROR", f"Domain must be one of {valid_domains}.", 422)

    custom_profile = data.get("profile")

    try:
        result = curriculum_gen.generate_project(
            prompt=prompt,
            difficulty=difficulty,
            persona=persona,
            domain=domain,
            custom_profile=custom_profile,
        )

        # If generation succeeded, persist project to server storage
        if result.get("status") == "success":
            proj = result["project"]
            PersistenceManager.save_project(proj)

        result["request_id"] = request.request_id
        return jsonify(result), 200

    except ValueError as ve:
        return error_response("VALIDATION_ERROR", str(ve), 422)
    except Exception as e:
        logger.error(f"Project generation failed: {str(e)}")
        return error_response("GENERATION_FAILED", "Failed to generate project curriculum.", 500)


@app.route("/api/project/blueprint", methods=["POST"])
def inspect_blueprint():
    """
    Constructs, inspects, and validates the 20-field Project Blueprint
    prior to artifact generation.
    Returns the complete blueprint with explicit provenance and validation checks.
    """
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return error_response("INVALID_JSON", "Request body must be a valid JSON object.", 400)

    prompt = data.get("prompt")
    if not prompt or not isinstance(prompt, str) or len(prompt.strip()) < 3:
        return error_response("VALIDATION_ERROR", "The 'prompt' field is required and must be at least 3 characters.", 422)

    difficulty = data.get("difficulty", 5)
    try:
        difficulty = int(difficulty)
        if not (1 <= difficulty <= 10):
            return error_response("VALIDATION_ERROR", "The 'difficulty' must be an integer between 1 and 10.", 422)
    except (ValueError, TypeError):
        return error_response("VALIDATION_ERROR", "The 'difficulty' must be an integer between 1 and 10.", 422)

    persona = data.get("persona", "student")
    domain = data.get("domain", "auto")
    enforce_clarification = bool(data.get("enforce_clarification", False))

    try:
        from blueprint_engine import BlueprintEngine, AmbiguityStateMachine

        if enforce_clarification:
            session = AmbiguityStateMachine.start_session(
                prompt=prompt,
                difficulty=difficulty,
                persona=persona,
                domain=domain,
                enforce_clarification=True,
            )
            if session.state == "REQUIRES_CLARIFICATION":
                return jsonify({
                    "status": "requires_clarification",
                    "session_id": session.session_id,
                    "unresolved_ambiguities": session.unresolved_ambiguities,
                    "clarification_question": session.clarification_question,
                    "request_id": request.request_id,
                }), 200

            blueprint = session.blueprint
            validation_dict = session.validation_result
        else:
            blueprint = BlueprintEngine.create_blueprint(
                prompt=prompt,
                difficulty=difficulty,
                persona=persona,
                domain=domain,
            )
            validation = BlueprintEngine.validate_blueprint(blueprint)
            validation_dict = validation.to_dict()

        return jsonify({
            "status": "success",
            "blueprint": blueprint,
            "validation": validation_dict,
            "request_id": request.request_id,
        }), 200
    except ValueError as ve:
        return error_response("VALIDATION_ERROR", str(ve), 422)
    except Exception as e:
        logger.error(f"Blueprint inspection failed: {str(e)}")
        return error_response("INTERNAL_ERROR", f"Blueprint inspection failed: {str(e)}", 500)


@app.route("/api/clarification/start", methods=["POST"])
def start_clarification():
    """
    Evaluates prompt for ambiguous / polysemic terms.
    If ambiguous: transitions to REQUIRES_CLARIFICATION and returns alternatives.
    If unambiguous: transitions to READY_FOR_BLUEPRINT and synthesizes blueprint.
    """
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return error_response("INVALID_JSON", "Request body must be a valid JSON object.", 400)

    prompt = data.get("prompt")
    if not prompt or not isinstance(prompt, str) or len(prompt.strip()) < 3:
        return error_response("VALIDATION_ERROR", "The 'prompt' field is required and must be at least 3 characters.", 422)

    difficulty = int(data.get("difficulty", 5))
    persona = data.get("persona", "student")
    domain = data.get("domain", "auto")

    try:
        from blueprint_engine import AmbiguityStateMachine
        session = AmbiguityStateMachine.start_session(
            prompt=prompt,
            difficulty=difficulty,
            persona=persona,
            domain=domain,
            enforce_clarification=True,
        )
        return jsonify({
            "status": "success",
            "session": session.to_dict(),
            "request_id": request.request_id,
        }), 200
    except Exception as e:
        logger.error(f"Clarification start failed: {str(e)}")
        return error_response("INTERNAL_ERROR", str(e), 500)


@app.route("/api/clarification/respond", methods=["POST"])
def respond_clarification():
    """
    Submits learner's direct choices to resolve material ambiguities.
    Resumes workflow to READY_FOR_BLUEPRINT -> BLUEPRINT_VALIDATED.
    """
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return error_response("INVALID_JSON", "Request body must be a valid JSON object.", 400)

    session_id = data.get("session_id")
    responses = data.get("responses")

    if not session_id or not isinstance(responses, dict):
        return error_response("VALIDATION_ERROR", "Fields 'session_id' and 'responses' (dict) are required.", 422)

    try:
        from blueprint_engine import AmbiguityStateMachine
        session = AmbiguityStateMachine.resolve_clarification(session_id, responses)
        return jsonify({
            "status": "success",
            "session": session.to_dict(),
            "request_id": request.request_id,
        }), 200
    except KeyError as ke:
        return error_response("NOT_FOUND", str(ke), 404)
    except ValueError as ve:
        return error_response("VALIDATION_ERROR", str(ve), 422)
    except Exception as e:
        logger.error(f"Clarification resolution failed: {str(e)}")
        return error_response("INTERNAL_ERROR", str(e), 500)


@app.route("/api/knowledge/retrieve", methods=["POST"])
def retrieve_knowledge():
    """
    Executes blueprint-driven knowledge retrieval and evidence processing.
    Accepts either a full blueprint or a prompt + difficulty to construct the blueprint.
    Returns the complete structured Stage 4 EvidencePackage.
    """
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return error_response("INVALID_JSON", "Request body must be a valid JSON object.", 400)

    try:
        from blueprint_engine import BlueprintEngine
        from knowledge_retriever import KnowledgeRetriever
        from dataclasses import asdict

        blueprint = data.get("blueprint")
        if not blueprint:
            prompt = data.get("prompt")
            if not prompt or not isinstance(prompt, str) or len(prompt.strip()) < 3:
                return error_response("VALIDATION_ERROR", "Either 'blueprint' or 'prompt' (>= 3 chars) is required.", 422)

            difficulty = int(data.get("difficulty", 5))
            persona = data.get("persona", "student")
            domain = data.get("domain", "auto")

            blueprint = BlueprintEngine.create_blueprint(
                prompt=prompt,
                difficulty=difficulty,
                persona=persona,
                domain=domain,
            )

        retriever = KnowledgeRetriever()
        evidence_package = retriever.retrieve_for_blueprint(blueprint)

        return jsonify({
            "status": "success",
            "evidence_package": asdict(evidence_package),
            "request_id": request.request_id,
        }), 200

    except ValueError as ve:
        return error_response("VALIDATION_ERROR", str(ve), 422)
    except Exception as e:
        logger.error(f"Knowledge retrieval failed: {str(e)}")
        return error_response("INTERNAL_ERROR", f"Knowledge retrieval failed: {str(e)}", 500)


@app.route("/api/project/adapt", methods=["POST"])
def adapt_project():
    """
    In-flight adaptive scaffolding:
    Decomposes difficult milestones or offers stretch challenges without corrupting milestones.
    """
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return error_response("INVALID_JSON", "Request body must be a valid JSON object.", 400)

    project_id = data.get("project_id")
    milestone_id = data.get("milestone_id")
    adaptation_type = data.get("adaptation_type")
    context = data.get("context", {})

    if not project_id or not milestone_id or not adaptation_type:
        return error_response(
            "VALIDATION_ERROR",
            "Fields 'project_id', 'milestone_id', and 'adaptation_type' are required.",
            422,
        )

    valid_types = ("remediation", "conceptual_support", "stretch_challenge")
    if adaptation_type not in valid_types:
        return error_response("VALIDATION_ERROR", f"adaptation_type must be one of {valid_types}.", 422)

    project = PersistenceManager.get_project(project_id)
    if not project:
        return error_response("NOT_FOUND", f"Project '{project_id}' not found.", 404)

    try:
        adaptation = curriculum_gen.adapt_project(
            project_data=project,
            milestone_id=milestone_id,
            adaptation_type=adaptation_type,
            context=context,
        )

        # Record adaptation in project state
        if "adaptations" not in project:
            project["adaptations"] = []
        project["adaptations"].append(adaptation)
        PersistenceManager.save_project(project)

        return jsonify({
            "status": "success",
            "adaptation": adaptation,
            "request_id": request.request_id,
        })
    except ValueError as ve:
        return error_response("ADAPTATION_ERROR", str(ve), 422)
    except Exception as e:
        logger.error(f"Adaptation failed: {str(e)}")
        return error_response("ADAPTATION_FAILED", "Failed to construct adaptation task.", 500)


@app.route("/api/tutor/message", methods=["POST"])
def tutor_message():
    """
    Context-aware Socratic AI Tutor endpoint.
    Enforces 3-tier hints, untrusted input sanitization, and contextual assistance.
    """
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return error_response("INVALID_JSON", "Request body must be a valid JSON object.", 400)

    project_id = data.get("project_id")
    milestone_id = data.get("milestone_id")
    message = data.get("message", "")
    hint_tier = data.get("hint_tier", 1)
    code_context = data.get("code_context", "")
    error_context = data.get("error_context", "")

    if not project_id or not milestone_id:
        return error_response("VALIDATION_ERROR", "'project_id' and 'milestone_id' are required.", 422)

    try:
        hint_tier = int(hint_tier)
        if hint_tier not in (1, 2, 3):
            hint_tier = 1
    except (ValueError, TypeError):
        hint_tier = 1

    project = PersistenceManager.get_project(project_id)
    if not project:
        return error_response("NOT_FOUND", f"Project '{project_id}' not found.", 404)

    target_milestone = next((m for m in project.get("milestones", []) if m["id"] == milestone_id), None)
    if not target_milestone:
        target_milestone = {"title": "General Context", "objective": "Building project"}

    # Generate response
    tutor_reply = llm_gateway.generate_chat_response(
        project_context=project,
        milestone_context=target_milestone,
        student_message=message,
        hint_tier=hint_tier,
        code_excerpt=code_context,
        error_excerpt=error_context,
    )

    return jsonify({
        "status": "success",
        "response": tutor_reply,
        "request_id": request.request_id,
    })


@app.route("/api/verify/layer2", methods=["POST"])
def verify_layer2():
    """
    Layer 2: Deterministic Correctness & Quantitative Verification.
    Evaluates computed numerical arrays, losses, or invariants against the milestone's
    layer2_spec WITHOUT executing arbitrary code on the server.
    """
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return error_response("INVALID_JSON", "Request body must be a valid JSON object.", 400)

    project_id = data.get("project_id")
    milestone_id = data.get("milestone_id")
    evaluation_payload = data.get("evaluation_payload", {})

    if not project_id or not milestone_id:
        return error_response("VALIDATION_ERROR", "'project_id' and 'milestone_id' are required.", 422)

    project = PersistenceManager.get_project(project_id)
    if not project:
        return error_response("NOT_FOUND", f"Project '{project_id}' not found.", 404)

    milestone = next((m for m in project.get("milestones", []) if m["id"] == milestone_id), None)
    if not milestone:
        return error_response("NOT_FOUND", f"Milestone '{milestone_id}' not found in project.", 404)

    layer2_spec = milestone.get("layer2_spec", {})
    checks = layer2_spec.get("checks", [])

    if not checks:
        verification_record = {
            "milestone_id": milestone_id,
            "timestamp": time.time(),
            "passed": False,
            "status": "unverified",
            "checks": [],
            "diagnostics": "No quantitative verification criteria are defined for this milestone. Correctness cannot be determined.",
            "recommendation": "This milestone lacks deterministic verification criteria and cannot be validated automatically.",
        }
        PersistenceManager.update_learner_progress(
            project_id=project_id,
            verification_update=verification_record,
        )
        return jsonify({
            "status": "success",
            "verification": verification_record,
            "request_id": request.request_id,
        })

    results = []
    all_passed = True
    any_unable = False

    for check_spec in checks:
        eval_result = QuantitativeVerifier.evaluate_check(check_spec, evaluation_payload)
        results.append(eval_result)
        if eval_result.get("status") == "unable_to_verify":
            any_unable = True
            all_passed = False
        elif not eval_result.get("passed", False):
            all_passed = False

    overall_status = "pass" if all_passed else ("unable_to_verify" if any_unable and not any(r.get("passed") for r in results) else "fail")

    verification_record = {
        "milestone_id": milestone_id,
        "timestamp": time.time(),
        "passed": all_passed,
        "status": overall_status,
        "checks": results,
        "diagnostics": (
            "All quantitative correctness and boundary criteria verified."
            if all_passed
            else ("Verification could not be performed due to unverified or missing criteria." if any_unable else "One or more correctness checks failed. Inspect diagnostics.")
        ),
        "recommendation": (
            "Proceed to Layer 3 Understanding Probe."
            if all_passed
            else "Review the failed mathematical/invariant checks or request a Socratic hint from the tutor."
        ),
    }

    # Persist verification attempt
    PersistenceManager.update_learner_progress(
        project_id=project_id,
        verification_update=verification_record,
    )

    return jsonify({
        "status": "success",
        "verification": verification_record,
        "request_id": request.request_id,
    })


@app.route("/api/verify/layer3", methods=["POST"])
def verify_layer3():
    """
    Layer 3: Understanding Verification & Conceptual Mastery.
    Evaluates learner's conceptual explanation or transfer prediction against
    the milestone rubric elements.
    """
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return error_response("INVALID_JSON", "Request body must be a valid JSON object.", 400)

    project_id = data.get("project_id")
    milestone_id = data.get("milestone_id")
    learner_response = data.get("learner_response", "")

    if not project_id or not milestone_id:
        return error_response("VALIDATION_ERROR", "'project_id' and 'milestone_id' are required.", 422)

    if not learner_response or len(learner_response.strip()) < 8:
        return error_response(
            "VALIDATION_ERROR",
            "Learner explanation is too brief. Please explain your conceptual reasoning in detail.",
            422,
        )

    project = PersistenceManager.get_project(project_id)
    if not project:
        return error_response("NOT_FOUND", f"Project '{project_id}' not found.", 404)

    milestone = next((m for m in project.get("milestones", []) if m["id"] == milestone_id), None)
    if not milestone:
        return error_response("NOT_FOUND", f"Milestone '{milestone_id}' not found.", 404)

    layer3_spec = milestone.get("layer3_spec", {})
    rubric = layer3_spec.get("rubric", {})
    required_concepts = rubric.get("required_concepts", [])
    acceptable_alt = rubric.get("acceptable_alternative")

    clean_resp = learner_response.lower()
    matched_concepts = []
    missing_concepts = []

    for concept in required_concepts:
        # Check presence of key terms
        words = concept.lower().split()
        if any(w in clean_resp for w in words if len(w) > 3):
            matched_concepts.append(concept)
        else:
            missing_concepts.append(concept)

    # Check acceptable alternative if defined in rubric
    alt_matched = False
    if acceptable_alt:
        alt_words = acceptable_alt.lower().split()
        if sum(1 for w in alt_words if len(w) > 3 and w in clean_resp) >= max(1, len(alt_words) // 2):
            alt_matched = True

    # Learner passes if they mention at least 50% of the required concepts or matched acceptable alternative
    # NOTE: Mere word count / length without conceptual substance does NOT pass
    passed = (len(matched_concepts) >= max(1, len(required_concepts) // 2)) or alt_matched

    assessment_record = {
        "milestone_id": milestone_id,
        "passed": passed,
        "outcome": "mastered" if passed else "gap_identified",
        "feedback": (
            "Outstanding! Your conceptual understanding and domain reasoning are sound."
            if passed
            else "You provided good effort, but some core conceptual mechanisms were missing."
        ),
        "matched_concepts": matched_concepts,
        "conceptual_gaps": missing_concepts if not passed else [],
        "can_retry": not passed,
    }

    # Persist mastery assessment
    PersistenceManager.update_learner_progress(
        project_id=project_id,
        layer3_update=assessment_record,
    )

    return jsonify({
        "status": "success",
        "assessment": assessment_record,
        "request_id": request.request_id,
    })


@app.route("/api/project/<project_id>", methods=["GET"])
def get_saved_project(project_id: str):
    """Retrieves saved project state and learner progress."""
    project = PersistenceManager.get_project(project_id)
    if not project:
        return error_response("NOT_FOUND", f"Project '{project_id}' was not found.", 404)

    return jsonify({
        "status": "success",
        "project": project,
        "request_id": request.request_id,
    })


@app.route("/api/project/<project_id>/save", methods=["POST"])
def save_project_progress(project_id: str):
    """Saves learner's working code files, active milestone, and progress."""
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return error_response("INVALID_JSON", "Request body must be a valid JSON object.", 400)

    files = data.get("files")
    active_m_id = data.get("active_milestone_id")

    try:
        updated = PersistenceManager.update_learner_progress(
            project_id=project_id,
            files=files,
            active_milestone_id=active_m_id,
        )
        return jsonify({
            "status": "success",
            "message": "Project saved successfully.",
            "project_id": project_id,
            "request_id": request.request_id,
        })
    except ValueError as ve:
        return error_response("SAVE_ERROR", str(ve), 422)
    except Exception as e:
        logger.error(f"Save failed: {str(e)}")
        return error_response("SAVE_FAILED", "Failed to save project progress.", 500)


@app.route("/api/project/<project_id>/export", methods=["GET"])
def export_project(project_id: str):
    """Packages project code and mastery reflection report into a clean ZIP download."""
    try:
        zip_buffer = PersistenceManager.export_project_zip(project_id)
        filename = f"{project_id}_projectforge.zip"
        return send_file(
            zip_buffer,
            mimetype="application/zip",
            as_attachment=True,
            download_name=filename,
        )
    except ValueError as ve:
        return error_response("EXPORT_ERROR", str(ve), 404)
    except Exception as e:
        logger.error(f"Export failed: {str(e)}")
    
# ---------------------------------------------------------
# Stage 4 General-Purpose Project Generation & Verification API
# ---------------------------------------------------------
V4_PROJECT_REGISTRY: Dict[str, Dict[str, Any]] = {}


@app.route("/api/project/generate_v4", methods=["POST"])
def generate_project_v4():
    """Generates a complete, mathematically verified, multi-file learning project."""
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return error_response("INVALID_JSON", "Request body must be a valid JSON object.", 400)

    prompt = data.get("prompt")
    difficulty = data.get("difficulty", 5)
    domain = data.get("domain", "auto")
    persona = data.get("persona", "student")
    user_bp = data.get("blueprint")

    try:
        difficulty = int(difficulty)
    except (TypeError, ValueError):
        return error_response("INVALID_DIFFICULTY", "Difficulty must be an integer between 1 and 10.", 400)

    # 1. Blueprint creation and validation
    try:
        if user_bp:
            val_res = BlueprintEngine.validate_blueprint(user_bp)
            if not val_res.is_valid:
                return error_response("INVALID_BLUEPRINT", "Blueprint failed validation.", 422, {"errors": val_res.errors})
            blueprint = user_bp
        else:
            if not prompt or not isinstance(prompt, str) or len(prompt.strip()) < 3:
                return error_response("INVALID_PROMPT", "Prompt must be a string with at least 3 characters.", 400)
            blueprint = BlueprintEngine.create_blueprint(
                prompt=prompt,
                difficulty=difficulty,
                persona=persona,
                domain=domain
            )
            val_res = BlueprintEngine.validate_blueprint(blueprint)
            if not val_res.is_valid:
                return error_response("BLUEPRINT_VALIDATION_ERROR", "Generated blueprint failed validation.", 422, {"errors": val_res.errors})

        # 2. Knowledge Retrieval & Evidence Grounding
        retriever = KnowledgeRetriever()
        evidence_pkg = retriever.retrieve_for_blueprint(blueprint)
        evidence_dict = evidence_pkg.to_dict()

        # 3. Project Generation & Dual-Mode Structuring
        orchestrator = GenerationOrchestrator()
        project = orchestrator.generate(
            blueprint=blueprint,
            evidence=evidence_dict,
            difficulty=difficulty
        )

        # 4. Registry Persistence
        V4_PROJECT_REGISTRY[project["id"]] = project

        return jsonify({
            "status": "success",
            "project_id": project["id"],
            "project": project,
            "quality_report": project.get("quality_report", {}),
            "request_id": request.request_id,
        })
    except ValueError as ve:
        return error_response("GENERATION_INPUT_ERROR", str(ve), 422)
    except Exception as e:
        logger.error(f"Stage 4 Generation failed: {str(e)}", exc_info=True)
        return error_response("GENERATION_FAILED", f"Project generation failed: {str(e)}", 500)


@app.route("/api/project/repair", methods=["POST"])
def repair_project():
    """Diagnoses and applies targeted patches to failing project milestones."""
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return error_response("INVALID_JSON", "Request body must be a valid JSON object.", 400)

    milestone_id = data.get("milestone_id")
    if not milestone_id:
        return error_response("MISSING_MILESTONE_ID", "Field 'milestone_id' is required.", 400)

    project_id = data.get("project_id")
    project_data = data.get("project_data")

    if not project_data and project_id in V4_PROJECT_REGISTRY:
        project_data = V4_PROJECT_REGISTRY[project_id]

    if not project_data:
        return error_response("PROJECT_NOT_FOUND", "Project data not found in registry or request.", 404)

    repair_res = ProjectRepairEngine.diagnose_and_repair(project_data, failing_milestone_id=milestone_id)

    # If project is registered, update artifacts
    if project_id and project_id in V4_PROJECT_REGISTRY:
        V4_PROJECT_REGISTRY[project_id]["artifacts"] = repair_res["repaired_artifacts"]

    return jsonify({
        "status": "success",
        "repair_result": repair_res,
        "request_id": request.request_id,
    })


@app.route("/api/project/verify_milestone", methods=["POST"])
def verify_milestone_endpoint():
    """Executes sandboxed verification for a specific project milestone."""
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return error_response("INVALID_JSON", "Request body must be a valid JSON object.", 400)

    milestone_id = data.get("milestone_id")
    if not milestone_id:
        return error_response("MISSING_MILESTONE_ID", "Field 'milestone_id' is required.", 400)

    project_id = data.get("project_id")
    code_files = data.get("code_files")
    criteria = data.get("criteria")

    if project_id and project_id in V4_PROJECT_REGISTRY:
        proj = V4_PROJECT_REGISTRY[project_id]
        if not code_files:
            code_files = {f: art["reference"] for f, art in proj.get("artifacts", {}).items()}
        if not criteria:
            criteria = proj.get("verification_criteria", {})

    if not code_files:
        return error_response("MISSING_CODE", "No code files provided or found for project.", 400)

    ver_res = VerificationIntegrator.verify_milestone(
        milestone_id=milestone_id,
        code_files=code_files,
        criteria=criteria or {}
    )

    return jsonify({
        "status": "success",
        "verification": ver_res,
        "request_id": request.request_id,
    })


@app.route("/api/project/v4/<project_id>", methods=["GET"])
def get_v4_project(project_id: str):
    """Retrieves a generated Stage 4 project from registry."""
    project = V4_PROJECT_REGISTRY.get(project_id)
    if not project:
        return error_response("NOT_FOUND", f"Stage 4 Project '{project_id}' not found.", 404)

    return jsonify({
        "status": "success",
        "project": project,
        "request_id": request.request_id,
    })


if __name__ == "__main__":
    port = int(os.getenv("PORT", 5000))
    debug = os.getenv("FLASK_ENV") == "development"
    logger.info(f"Starting ProjectForge AI on port {port} (debug={debug})")
    app.run(host="0.0.0.0", port=port, debug=debug)
