"""
curriculum_generator.py
=======================
Generates and validates structured project curricula for ProjectForge AI.
Coordinates 4D difficulty calibration, prompt ambiguity detection, starter code
scaffolding, and 3-layer verification specifications (Execution, Correctness, Understanding).
"""

import uuid
import re
from typing import Dict, Any, List, Optional, Tuple
from difficulty_engine import DifficultyEngine
from llm_gateway import LLMGateway
from blueprint_engine import BlueprintEngine


class CurriculumGenerator:
    def __init__(self, llm_gateway: Optional[LLMGateway] = None):
        self.gateway = llm_gateway or LLMGateway()
        self.blueprint_engine = BlueprintEngine

    def generate_project(
        self,
        prompt: str,
        difficulty: int = 5,
        persona: str = "student",
        domain: str = "auto",
        custom_profile: Optional[Dict[str, Any]] = None,
        allow_unverified_draft: bool = False,
    ) -> Dict[str, Any]:
        """
        Main entry point for project generation.
        Returns:
          - If valid curated topic: {"status": "success", "project": {...}}
          - If uncurated in offline mode: {"status": "unsupported_offline", ...}
          - If uncurated draft requested: {"status": "partial", "project": {...}}
          - If ambiguous: {"status": "needs_clarification", "clarification": {...}}
          - If invalid: raises ValueError
        """
        # 1. Validate inputs
        if not prompt or not isinstance(prompt, str) or len(prompt.strip()) < 3:
            raise ValueError("Prompt must be a non-empty string with at least 3 characters.")
        if len(prompt) > 2000:
            raise ValueError("Prompt exceeds the maximum allowed length of 2000 characters.")

        if not (1 <= int(difficulty) <= 10):
            raise ValueError("Difficulty must be an integer between 1 and 10.")

        valid_personas = ("student", "educator")
        if persona not in valid_personas:
            raise ValueError(f"Invalid persona '{persona}'. Supported personas: {valid_personas}")

        # 2. Check ambiguity
        needs_clarification, clarification_data = self.gateway.check_prompt_ambiguity(prompt)
        if needs_clarification and clarification_data:
            return {
                "status": "needs_clarification",
                "clarification": clarification_data,
            }

        # 3. Determine 4D difficulty profile
        if custom_profile:
            is_valid, err_msg, profile = DifficultyEngine.validate_profile(custom_profile)
            if not is_valid:
                raise ValueError(f"Invalid difficulty profile: {err_msg}")
        else:
            profile = DifficultyEngine.calculate_preset(difficulty)

        pedagogy = DifficultyEngine.get_pedagogical_parameters(profile)

        # 4. Detect or normalize domain
        detected_domain = self._resolve_domain(prompt, domain)

        # 5. Check if prompt matches curated exemplar
        clean_prompt = prompt.lower()
        is_curated = (
            "regression" in clean_prompt
            or "gradient descent" in clean_prompt
            or "orbit" in clean_prompt
            or "gravity" in clean_prompt
        )

        project_id = f"proj_{uuid.uuid4().hex[:10]}"

        # Construct structured 20-field blueprint
        blueprint = self.blueprint_engine.create_blueprint(
            prompt=prompt,
            difficulty=profile["master_difficulty"],
            persona=persona,
            domain=detected_domain,
        )
        bp_validation = self.blueprint_engine.validate_blueprint(blueprint)

        if is_curated:
            if "regression" in clean_prompt or "gradient descent" in clean_prompt:
                project = self._build_linear_regression_project(project_id, prompt, profile, pedagogy, persona)
            else:
                project = self._build_orbital_simulation_project(project_id, prompt, profile, pedagogy, persona)

            project["verification_level"] = "verified"
            project["generation_status"] = "complete"
            project["is_curated"] = True
            project["blueprint"] = blueprint
            project["blueprint_validation"] = bp_validation.to_dict()
            project = self._ensure_dual_mode_metadata(project)

            return {
                "status": "success",
                "project": project,
                "blueprint": blueprint,
            }

        # 6. Uncurated topic handling
        # In offline mode without cloud LLM, do NOT return a fake placeholder project claiming success
        if not self.gateway.is_cloud_available() and not allow_unverified_draft:
            return {
                "status": "unsupported_offline",
                "message": f"Curriculum generation for '{prompt}' is not available in offline heuristic mode.",
                "reason": "unsupported_domain_offline",
                "unsupported_topic": prompt,
                "verification_status": "unable_to_verify",
                "blueprint": blueprint,
                "blueprint_validation": bp_validation.to_dict(),
                "limitations": [
                    "Offline heuristic mode only supports curated, quantitatively verified project curricula.",
                    "Uncurated topics require an active model provider (Gemini, OpenAI, Claude, or Ollama) to synthesize valid domain code and verification criteria.",
                    "Placeholder stubs are disallowed to prevent false claims of project completion.",
                ],
                "suggested_curated_topics": [
                    {
                        "title": "Linear Regression with Gradient Descent from Scratch",
                        "prompt": "Build a linear regression model from scratch using gradient descent.",
                        "domain": "data_science",
                    },
                    {
                        "title": "Planetary Orbit & Gravitational Physics Simulation",
                        "prompt": "Build a planetary orbit gravitational physics simulation with canvas and energy conservation.",
                        "domain": "simulation",
                    },
                ],
            }

        # Uncurated draft (when explicitly requested or when model provider is connected)
        project = self._build_generalized_project(project_id, prompt, profile, pedagogy, persona, detected_domain)
        project["verification_level"] = "unverified_draft"
        project["generation_status"] = "partial"
        project["is_curated"] = False
        project["blueprint"] = blueprint
        project["blueprint_validation"] = bp_validation.to_dict()
        project["limitations"] = [
            "Unverified draft curriculum. No automated quantitative correctness checks are defined for this project."
        ]
        project = self._ensure_dual_mode_metadata(project)

        return {
            "status": "partial",
            "project": project,
            "blueprint": blueprint,
            "message": "Draft project outline generated without verified quantitative checks.",
        }

    def _resolve_domain(self, prompt: str, user_domain: str) -> str:
        if user_domain in ("python", "data_science", "simulation", "web", "algorithms"):
            return user_domain

        clean = prompt.lower()
        if any(w in clean for w in ("regression", "machine learning", "gradient", "loss", "dataset", "stats")):
            return "data_science"
        if any(w in clean for w in ("orbit", "gravity", "physics", "simulation", "euler", "verlet", "particle")):
            return "simulation"
        if any(w in clean for w in ("sort", "tree", "graph", "search", "dijkstra", "a*", "algorithm")):
            return "algorithms"
        if any(w in clean for w in ("website", "portfolio", "canvas", "html", "css", "chat", "dashboard")):
            return "web"
        return "python"

    def _construct_project(
        self,
        prompt: str,
        profile: Dict[str, int],
        pedagogy: Dict[str, Any],
        persona: str,
        domain: str,
    ) -> Dict[str, Any]:
        """Constructs a project model for testing or internal generation."""
        clean_prompt = prompt.lower()
        project_id = f"proj_{uuid.uuid4().hex[:10]}"

        if "regression" in clean_prompt or "gradient descent" in clean_prompt:
            project = self._build_linear_regression_project(project_id, prompt, profile, pedagogy, persona)
            project["verification_level"] = "verified"
            project["generation_status"] = "complete"
            project["is_curated"] = True
        elif "orbit" in clean_prompt or "gravity" in clean_prompt:
            project = self._build_orbital_simulation_project(project_id, prompt, profile, pedagogy, persona)
            project["verification_level"] = "verified"
            project["generation_status"] = "complete"
            project["is_curated"] = True
        else:
            project = self._build_generalized_project(project_id, prompt, profile, pedagogy, persona, domain)
            project["verification_level"] = "unverified_draft"
            project["generation_status"] = "partial"
            project["is_curated"] = False

        return self._ensure_dual_mode_metadata(project)

    def _ensure_dual_mode_metadata(self, project: Dict[str, Any]) -> Dict[str, Any]:
        """Ensures that project and milestone models contain required dual-mode learning metadata."""
        if not project or not isinstance(project, dict):
            return project

        if "overview" not in project:
            title = project.get("title", "Interactive Project")
            desc = project.get("description", "A hands-on learning project.")
            project["overview"] = {
                "what_building": f"You will build and verify {title}.",
                "why_matters": desc,
                "what_you_will_learn": [
                    "Core architectural and computational concepts",
                    "Modular function design and algorithmic invariants",
                    "Iterative testing and verification"
                ],
                "what_you_will_build": [
                    "Complete source implementation with validated edge cases",
                    "Unit and regression verification tests",
                    "Self-contained executable model"
                ],
                "prerequisites": {
                    "essential": ["Basic programming fundamentals", "Function declarations and variables"],
                    "helpful": ["Familiarity with loops and mathematical operators"],
                    "taught_here": ["Algorithmic decomposition", "Multi-stage verification", "Socratic debugging"]
                }
            }

        for i, m in enumerate(project.get("milestones", [])):
            m_title = m.get("title", f"Milestone {i+1}")
            m_obj = m.get("objective", "Implement milestone requirements.")
            m_tasks = m.get("tasks", [])

            if "task_brief" not in m:
                m["task_brief"] = {
                    "goal": m_obj,
                    "why_matters": f"Completing {m_title} establishes the foundation for subsequent project milestones.",
                    "concepts": [m_title.split(":")[-1].strip()] if ":" in m_title else [m_title],
                    "instructions": m_tasks if m_tasks else ["Implement the required functions in the editor", "Run the code to verify execution"],
                    "success_criteria": f"Pass all automated tests and verification checks specified for {m_title}."
                }

            if "concept_layers" not in m:
                m["concept_layers"] = [
                    {"level": 1, "name": "Intuition", "content": f"High-level conceptual overview of {m_title} and how it fits into the broader project."},
                    {"level": 2, "name": "Mathematical Foundation", "content": f"Theoretical models, formulas, and domain rules governing {m_title}."},
                    {"level": 3, "name": "Derivation & Worked Example", "content": "Step-by-step walk-through of the mechanics with sample inputs and expected outputs."},
                    {"level": 4, "name": "Implementation Link", "content": "Detailed mapping showing how each formula translates directly into executable functions."},
                    {"level": 5, "name": "Advanced Investigation", "content": "Edge cases, performance characteristics, complexity analysis, and potential optimizations."}
                ]

            if "code_context" not in m:
                req_funcs = m.get("layer1_spec", {}).get("required_functions", [])
                m["code_context"] = [
                    {"name": fn, "purpose": f"Executes logic for {fn}", "inputs": "Domain inputs", "outputs": "Processed result", "math_link": "Implements core algorithm"}
                    for fn in req_funcs
                ] if req_funcs else [
                    {"name": "main", "purpose": "Entry point for milestone execution", "inputs": "N/A", "outputs": "Milestone results", "math_link": "Coordinates milestone pipeline"}
                ]

            if "developer_notes" not in m:
                req_funcs = m.get("layer1_spec", {}).get("required_functions", [])
                m["developer_notes"] = {
                    "summary": m_obj,
                    "incomplete_sections": [
                        {"function": fn, "status": "Pending Implementation", "requirement": f"Implement {fn} to satisfy verification checks.", "inputs": "See docstrings", "output": "Validated output"}
                        for fn in req_funcs
                    ] if req_funcs else [
                        {"function": "core_logic", "status": "Pending", "requirement": "Implement milestone logic", "inputs": "Standard inputs", "output": "Validated output"}
                    ]
                }

        return project

    def _build_linear_regression_project(
        self, project_id: str, prompt: str, profile: Dict[str, int], pedagogy: Dict[str, Any], persona: str
    ) -> Dict[str, Any]:
        """Constructs quantitative Linear Regression project with numerical checks."""
        scaffolding = pedagogy["scaffolding_ratio_pct"]
        tolerance = pedagogy["numerical_tolerance"]

        # Starter code calibrated to independence & scaffolding ratio
        if scaffolding > 60:
            starter_code = (
                "# Linear Regression from Scratch via Gradient Descent\n"
                "# Level: Foundations (Heavy Scaffolding)\n\n"
                "def compute_predictions(X, weight, bias):\n"
                "    # TODO: compute predicted y_hat = weight * x + bias for each x in X\n"
                "    return [weight * x + bias for x in X]\n\n"
                "def compute_mse_loss(y_true, y_pred):\n"
                "    # TODO: compute (1/N) * sum((y_pred - y_true)^2)\n"
                "    N = len(y_true)\n"
                "    squared_errors = [(y_pred[i] - y_true[i]) ** 2 for i in range(N)]\n"
                "    return sum(squared_errors) / N\n\n"
                "def compute_gradients(X, y_true, y_pred):\n"
                "    # TODO: compute partial derivatives of MSE w.r.t weight and bias\n"
                "    N = len(y_true)\n"
                "    errors = [y_pred[i] - y_true[i] for i in range(N)]\n"
                "    dw = (2.0 / N) * sum(errors[i] * X[i] for i in range(N))\n"
                "    db = (2.0 / N) * sum(errors[i] for i in range(N))\n"
                "    return dw, db\n\n"
                "def train(X, y_true, epochs=100, learning_rate=0.01):\n"
                "    weight = 0.0\n"
                "    bias = 0.0\n"
                "    loss_history = []\n"
                "    for _ in range(epochs):\n"
                "        y_pred = compute_predictions(X, weight, bias)\n"
                "        loss = compute_mse_loss(y_true, y_pred)\n"
                "        loss_history.append(loss)\n"
                "        dw, db = compute_gradients(X, y_true, y_pred)\n"
                "        # TODO: update weight and bias using gradient descent\n"
                "        weight = weight - learning_rate * dw\n"
                "        bias = bias - learning_rate * db\n"
                "    return weight, bias, loss_history\n"
            )
        else:
            starter_code = (
                "# Linear Regression from Scratch via Gradient Descent\n"
                "# Level: Moderate/Advanced (Minimal Scaffolding)\n\n"
                "class LinearRegressionGD:\n"
                "    def __init__(self, learning_rate=0.01, epochs=100):\n"
                "        self.lr = learning_rate\n"
                "        self.epochs = epochs\n"
                "        self.weight = 0.0\n"
                "        self.bias = 0.0\n"
                "        self.loss_history = []\n\n"
                "    def fit(self, X, y):\n"
                "        # TODO: Implement analytical gradient updates\n"
                "        pass\n\n"
                "    def predict(self, X):\n"
                "        # TODO: Compute predictions\n"
                "        pass\n"
            )

        overview = {
            "what_building": "A custom linear regression optimizer built in pure Python from first principles, training model parameters via analytical gradient descent without third-party ML packages.",
            "why_matters": "Linear regression is the foundational model of predictive modeling, empirical economics, and machine learning. Deriving gradients by hand explains the core mechanics governing how neural networks update weights.",
            "what_learn": [
                "Formulate hypothesis predictions and Mean Squared Error (MSE) loss",
                "Derive partial derivatives analytically using calculus chain rule",
                "Implement iterative gradient descent parameter updates",
                "Analyze loss convergence and tune learning rate parameters"
            ],
            "what_you_will_learn": [
                "Formulate hypothesis predictions and Mean Squared Error (MSE) loss",
                "Derive partial derivatives analytically using calculus chain rule",
                "Implement iterative gradient descent parameter updates",
                "Analyze loss convergence and tune learning rate parameters"
            ],
            "what_build": "An optimization engine that fits slope and intercept parameters to data with verified numerical precision and zero mathematical drift.",
            "what_you_will_build": [
                "Hypothesis prediction function: y_hat = w * x + b",
                "Mean Squared Error loss calculator with numerical safeguards",
                "Analytical gradient calculation (dL/dw and dL/db)",
                "Iterative gradient descent training loop with loss tracking"
            ],
            "prerequisites": {
                "essential": [
                    "Basic Python syntax (functions, loops, list comprehensions)",
                    "Elementary algebra (slope-intercept line equation: y = mx + b)"
                ],
                "helpful": [
                    "Intuition of derivatives as rates of change",
                    "Summation notation (Sigma)"
                ],
                "taught_here": [
                    "Loss surface convexity of Mean Squared Error",
                    "Analytical partial derivatives (dL/dw and dL/db)",
                    "Gradient descent step updates and convergence monitoring"
                ]
            },
            "prerequisites_breakdown": {
                "essential": [
                    "Basic Python syntax (functions, loops, list comprehensions)",
                    "Elementary algebra (slope-intercept line equation: y = mx + b)"
                ],
                "helpful": [
                    "Intuition of derivatives as rates of change",
                    "Summation notation (Sigma)"
                ],
                "taught_here": [
                    "Loss surface convexity of Mean Squared Error",
                    "Analytical partial derivatives (dL/dw and dL/db)",
                    "Gradient descent step updates and convergence monitoring"
                ]
            }
        }

        milestones = [
            {
                "id": "m1",
                "title": "Milestone 1: Mathematical Foundations & Loss Function",
                "objective": "Implement hypothesis prediction and Mean Squared Error (MSE) loss with numerical stability.",
                "tasks": [
                    "Calculate hypothesis predictions: y_hat = w * x + b",
                    "Compute Mean Squared Error loss between ground truth and predictions",
                    "Handle zero and negative coordinate edge cases",
                ],
                "task_brief": {
                    "goal": "Implement hypothesis prediction (y_hat = w * x + b) and compute Mean Squared Error (MSE) loss.",
                    "why_matters": "Before an optimization algorithm can improve, it must make predictions and quantify total prediction error using a convex, differentiable loss function.",
                    "concepts": ["Linear Hypothesis", "Residuals", "Mean Squared Error (MSE)"],
                    "instructions": [
                        "Open regression.py and inspect compute_predictions(X, weight, bias).",
                        "Compute predicted y_hat = weight * x + bias for every x in feature list X.",
                        "Complete compute_mse_loss(y_true, y_pred) to sum squared residuals and divide by sample count N.",
                        "Run code in the sandbox to verify that reference data produces expected MSE loss."
                    ],
                    "success_criteria": "Given inputs X=[1,2,3], w=2, b=0 against ground-truth y=[0,2,4], computed MSE loss must strictly match 4.0 within tolerance."
                },
                "concept_layers": [
                    {"level": 1, "name": "Intuition", "content": "Imagine aiming an adjustable line through scattered points. For every point, measure the vertical gap between your line and the point. Squaring each gap ensures negative and positive errors do not cancel, while penalizing wild misses."},
                    {"level": 2, "name": "Mathematical Foundation", "content": "Hypothesis equation:\n$$\\hat{y}_i = w x_i + b$$\nMSE Loss formulation:\n$$L(w, b) = \\frac{1}{N} \\sum_{i=1}^N (\\hat{y}_i - y_i)^2$$\nSymbols:\n- $N$: number of training instances\n- $w$: weight (slope parameter)\n- $b$: bias (y-intercept)\n- $y_i$: true target observation\n- $\\hat{y}_i$: model prediction"},
                    {"level": 3, "name": "Derivation & Worked Example", "content": "Why square the residuals $(e_i = \\hat{y}_i - y_i)$? Squaring makes the loss function continuously differentiable everywhere and strictly convex, guaranteeing that gradient descent will find a unique global minimum rather than getting stuck in local valleys."},
                    {"level": 4, "name": "Implementation Link", "content": "In regression.py:\n- compute_predictions implements the linear hypothesis mapping: [weight * x + bias for x in X].\n- compute_mse_loss computes the average squared residual: sum((yp - yt)**2 for yp, yt in zip(y_pred, y_true)) / len(y_true)."},
                    {"level": 5, "name": "Advanced Investigation", "content": "Numerical stability & Outliers: MSE squares errors, which means outliers have a quadratic pull on the fitted line. In datasets with heavy noise, L1 loss (Mean Absolute Error) or Huber loss provides greater robustness."}
                ],
                "code_context": [
                    {"name": "compute_predictions", "purpose": "Generates model predictions for input features using current slope and intercept.", "inputs": "X (list of floats), weight (float), bias (float)", "outputs": "y_hat (list of floats)", "math_link": "y_hat = w * x + b"},
                    {"name": "compute_mse_loss", "purpose": "Computes the average squared prediction error across all samples.", "inputs": "y_true (list of floats), y_pred (list of floats)", "outputs": "loss (float)", "math_link": "L = (1/N) * sum((y_pred - y_true)^2)"}
                ],
                "developer_notes": {
                    "summary": "Implements linear hypothesis and scalar loss calculation.",
                    "incomplete_sections": [
                        {"function": "compute_predictions", "status": "Incomplete Scaffold", "requirement": "Return list of predictions: weight * x + bias for each x in X.", "inputs": "X, weight, bias", "output": "List of floats"},
                        {"function": "compute_mse_loss", "status": "Incomplete Scaffold", "requirement": "Compute mean of squared differences between y_pred and y_true.", "inputs": "y_true, y_pred", "output": "Scalar float"}
                    ]
                },
                "layer1_spec": {"type": "syntax_and_execution", "required_functions": ["compute_predictions", "compute_mse_loss"]},
                "layer2_spec": {
                    "checks": [
                        {"id": "mse_eval", "type": "scalar_match", "name": "MSE Evaluation on Reference Data", "expected": 4.0, "rtol": tolerance, "atol": 1e-4, "payload_key": "test_mse"},
                        {"id": "predictions_vector", "type": "array_tolerance", "name": "Prediction Vector Tolerance", "expected": [2.0, 4.0, 6.0], "rtol": tolerance, "payload_key": "test_preds"},
                    ]
                },
                "layer3_spec": {
                    "question_id": "q_m1",
                    "prompt": "Why do we square the prediction errors in MSE rather than taking the absolute value or leaving them signed?",
                    "rubric": {
                        "required_concepts": ["penalizes larger errors", "differentiable", "cancels negative signs"],
                        "acceptable_alternative": "convex optimization quadratic properties",
                    },
                },
            },
            {
                "id": "m2",
                "title": "Milestone 2: Gradient Derivation & Analytical Updates",
                "objective": "Derive partial derivatives of MSE w.r.t weight and bias, and formulate negative gradient updates.",
                "tasks": [
                    "Compute partial derivative dL/dw = (2/N) * sum((y_pred - y) * x)",
                    "Compute partial derivative dL/db = (2/N) * sum(y_pred - y)",
                    "Apply step updates: w = w - alpha * dw, b = b - alpha * db",
                ],
                "task_brief": {
                    "goal": "Derive partial derivatives (dL/dw and dL/db) and apply negative gradient updates.",
                    "why_matters": "The gradient vector indicates the direction of steepest loss increase. Subtracting the gradient steps downhill towards the minimal loss.",
                    "concepts": ["Partial Derivatives", "Chain Rule", "Steepest Gradient Descent"],
                    "instructions": [
                        "Implement compute_gradients(X, y_true, y_pred).",
                        "Compute partial derivative w.r.t weight: dw = (2/N) * sum((y_pred - y) * x).",
                        "Compute partial derivative w.r.t bias: db = (2/N) * sum(y_pred - y).",
                        "Return tuple (dw, db)."
                    ],
                    "success_criteria": "Gradient calculation on test data must yield dw = -14.6667 and db = -6.0 within 1% error tolerance."
                },
                "concept_layers": [
                    {"level": 1, "name": "Intuition", "content": "If making the slope steeper increases error, the derivative is positive, so we reduce the slope. If making it steeper decreases error, the derivative is negative, so we increase the slope."},
                    {"level": 2, "name": "Mathematical Foundation", "content": "Loss function: $L = \\frac{1}{N} \\sum_{i=1}^N (w x_i + b - y_i)^2$.\nPartial derivatives:\n$$\\frac{\\partial L}{\\partial w} = \\frac{2}{N} \\sum_{i=1}^N (\\hat{y}_i - y_i) x_i$$\n$$\\frac{\\partial L}{\\partial b} = \\frac{2}{N} \\sum_{i=1}^N (\\hat{y}_i - y_i)$$"},
                    {"level": 3, "name": "Derivation & Worked Example", "content": "Applying the calculus chain rule:\nLet $u_i = \\hat{y}_i - y_i = w x_i + b - y_i$.\n$\\frac{\\partial L}{\\partial w} = \\frac{1}{N} \\sum 2 u_i \\frac{\\partial u_i}{\\partial w}$.\nSince $\\frac{\\partial u_i}{\\partial w} = x_i$, we obtain $\\frac{2}{N} \\sum (\\hat{y}_i - y_i) x_i$."},
                    {"level": 4, "name": "Implementation Link", "content": "In compute_gradients(X, y_true, y_pred), accumulate errors[i] * X[i] and errors[i] across all samples and multiply by 2.0 / N."},
                    {"level": 5, "name": "Advanced Investigation", "content": "Learning rate bounds: if the learning rate alpha is set larger than 2 / lambda_max (spectral radius of Hessian), updates overshoot the valley and explode to NaN."}
                ],
                "code_context": [
                    {"name": "compute_gradients", "purpose": "Computes analytical partial derivatives dL/dw and dL/db.", "inputs": "X, y_true, y_pred", "outputs": "(dw, db)", "math_link": "dw = (2/N)*sum(err*x), db = (2/N)*sum(err)"}
                ],
                "developer_notes": {
                    "summary": "Computes gradient updates analytically without autograd.",
                    "incomplete_sections": [
                        {"function": "compute_gradients", "status": "Incomplete Scaffold", "requirement": "Compute both dw and db. Ensure the factor of 2.0 / N is preserved.", "inputs": "X, y_true, y_pred", "output": "Tuple (dw, db)"}
                    ]
                },
                "layer1_spec": {"type": "syntax_and_execution", "required_functions": ["compute_gradients"]},
                "layer2_spec": {
                    "checks": [
                        {"id": "grad_w", "type": "scalar_match", "name": "Weight Gradient Check", "expected": -14.6667, "rtol": 0.01, "atol": 1e-3, "payload_key": "dw"},
                        {"id": "grad_b", "type": "scalar_match", "name": "Bias Gradient Check", "expected": -6.0, "rtol": 0.01, "atol": 1e-3, "payload_key": "db"},
                    ]
                },
                "layer3_spec": {
                    "question_id": "q_m2",
                    "prompt": "What occurs to the parameter updates if the learning rate alpha is set too large (e.g. alpha = 10.0)? Explain mathematically.",
                    "rubric": {
                        "required_concepts": ["overshooting minimum", "divergence", "loss explosion / NaN"],
                    },
                },
            },
            {
                "id": "m3",
                "title": "Milestone 3: Training Loop Convergence & Evaluation",
                "objective": "Execute multi-epoch gradient descent and verify that training loss strictly converges towards the optimal parameter plane.",
                "tasks": [
                    "Iterate gradient descent over 100 epochs",
                    "Track training loss history array across all epochs",
                    "Verify final fitted parameters approximate the target slope and intercept",
                ],
                "task_brief": {
                    "goal": "Construct the iterative training loop and verify loss convergence across epochs.",
                    "why_matters": "Iterating gradient updates over multiple epochs allows parameters to converge from random initialization to the optimal regression line.",
                    "concepts": ["Training Loop", "Epochs", "Monotonic Convergence", "Learning Rate Sensitivity"],
                    "instructions": [
                        "In train(), loop over the specified number of epochs.",
                        "At each epoch: compute predictions, record current MSE loss in loss_history, compute gradients, and update weight and bias.",
                        "Return final fitted weight, bias, and loss_history."
                    ],
                    "success_criteria": "Loss must drop by at least 75% over 100 epochs, and fitted slope must approximate target slope 2.0."
                },
                "concept_layers": [
                    {"level": 1, "name": "Intuition", "content": "Each step adjusts the line slightly closer to the data cloud. Over 100 small downhill steps, the line settles into the best possible fit."},
                    {"level": 2, "name": "Mathematical Foundation", "content": "Parameter updates:\n$$w^{(t+1)} = w^{(t)} - \\alpha \\frac{\\partial L}{\\partial w}$$\n$$b^{(t+1)} = b^{(t)} - \\alpha \\frac{\\partial L}{\\partial b}$$\nwhere $\\alpha$ is the learning rate."},
                    {"level": 3, "name": "Derivation & Worked Example", "content": "Convergence rate: For convex quadratic functions, gradient descent with step size alpha < 1/L exhibits linear convergence O(1/t) towards the global minimum."},
                    {"level": 4, "name": "Implementation Link", "content": "In train(): initialize weight = 0.0, bias = 0.0. In the epoch loop: w -= lr * dw, b -= lr * db."},
                    {"level": 5, "name": "Advanced Investigation", "content": "Feature scaling: if X values are large, gradient updates oscillate. Feature standardization creates circular contours for faster, more stable convergence."}
                ],
                "code_context": [
                    {"name": "train", "purpose": "Executes gradient descent optimization over multiple epochs.", "inputs": "X, y_true, epochs=100, learning_rate=0.01", "outputs": "(weight, bias, loss_history)", "math_link": "w = w - alpha * dw, b = b - alpha * db"}
                ],
                "developer_notes": {
                    "summary": "Orchestrates multi-epoch gradient descent.",
                    "incomplete_sections": [
                        {"function": "train", "status": "Incomplete Scaffold", "requirement": "Loop over epochs, record losses, update weights and bias using gradient descent.", "inputs": "X, y_true, epochs, learning_rate", "output": "(weight, bias, loss_history)"}
                    ]
                },
                "layer1_spec": {"type": "syntax_and_execution", "required_functions": ["train"]},
                "layer2_spec": {
                    "checks": [
                        {"id": "loss_converge", "type": "loss_convergence", "name": "Loss Convergence Check", "min_reduction_pct": 75.0},
                        {"id": "fitted_w", "type": "scalar_match", "name": "Optimal Slope Convergence", "expected": 2.0, "rtol": 0.05, "payload_key": "final_w"},
                    ]
                },
                "layer3_spec": {
                    "question_id": "q_m3",
                    "prompt": "If a strong outlier is introduced into the dataset, how does it affect the fitted line compared to Mean Absolute Error (L1 loss)?",
                    "rubric": {
                        "required_concepts": ["squared penalty disproportionately pulls line", "L1 is more robust to outliers"],
                    },
                },
            },
        ]

        return {
            "id": project_id,
            "title": "Linear Regression with Gradient Descent from Scratch",
            "description": "Build an analytical regression optimizer from first principles, verifying loss convergence and mathematical gradient correctness.",
            "domain": "data_science",
            "execution_mode": "browser_pyodide",
            "persona": persona,
            "difficulty_profile": profile,
            "pedagogical_params": pedagogy,
            "overview": overview,
            "prerequisites": ["Basic Python", "High School Algebra / Derivatives", "Summation Notation"],
            "learning_objectives": [
                "Understand the loss surface of Mean Squared Error",
                "Derive and compute analytical gradients without autograd libraries",
                "Observe convergence dynamics and learning rate sensitivity",
            ],
            "estimated_effort_minutes": 45,
            "files": [
                {"name": "regression.py", "language": "python", "content": starter_code, "is_entry": True}
            ],
            "milestones": milestones,
            "educator_rubric": (
                {
                    "grading_criteria": [
                        {"criterion": "Loss function formulation", "max_points": 25},
                        {"criterion": "Analytical gradient derivation", "max_points": 35},
                        {"criterion": "Convergence stability & tolerance", "max_points": 25},
                        {"criterion": "Conceptual understanding response", "max_points": 15},
                    ],
                    "solution_notes": "Look out for common learner bugs: forgetting the factor of 2 in gradient derivation, or adding the gradient instead of subtracting it.",
                }
                if persona == "educator"
                else None
            ),
        }

    def _build_orbital_simulation_project(
        self, project_id: str, prompt: str, profile: Dict[str, int], pedagogy: Dict[str, Any], persona: str
    ) -> Dict[str, Any]:
        """Constructs quantitative gravitational simulation with energy conservation checks."""
        starter_html = (
            "<!DOCTYPE html>\n"
            "<html>\n"
            "<head>\n"
            "  <style>\n"
            "    body { margin: 0; background: #0b0f19; color: #fff; font-family: sans-serif; overflow: hidden; }\n"
            "    canvas { display: block; }\n"
            "    #stats { position: absolute; top: 10px; left: 10px; background: rgba(0,0,0,0.7); padding: 8px 12px; border-radius: 6px; font-size: 13px; font-family: monospace; }\n"
            "  </style>\n"
            "</head>\n"
            "<body>\n"
            "  <div id='stats'>Energy: <span id='energy-val'>0.00</span> | Drift: <span id='drift-val'>0.0%</span></div>\n"
            "  <canvas id='simCanvas'></canvas>\n"
            "  <script src='orbit.js'></script>\n"
            "</body>\n"
            "</html>\n"
        )

        starter_js = (
            "// Gravitational Orbit Simulation\n"
            "const canvas = document.getElementById('simCanvas');\n"
            "const ctx = canvas.getContext('2d');\n"
            "canvas.width = window.innerWidth;\n"
            "canvas.height = window.innerHeight;\n\n"
            "const G = 1000;\n"
            "const dt = 0.016;\n\n"
            "const sun = { x: canvas.width / 2, y: canvas.height / 2, vx: 0, vy: 0, mass: 1000, radius: 16, color: '#f59e0b' };\n"
            "const planet = { x: canvas.width / 2, y: canvas.height / 2 - 180, vx: 2.35, vy: 0, mass: 1, radius: 6, color: '#38bdf8' };\n\n"
            "function computeGravitationalForce(b1, b2) {\n"
            "    const dx = b2.x - b1.x;\n"
            "    const dy = b2.y - b1.y;\n"
            "    const dist = Math.sqrt(dx * dx + dy * dy + 1e-4);\n"
            "    const F = (G * b1.mass * b2.mass) / (dist * dist);\n"
            "    return { fx: F * (dx / dist), fy: F * (dy / dist) };\n"
            "}\n\n"
            "function updatePhysics() {\n"
            "    // TODO: Update planet position and velocity using numerical integration\n"
            "    const force = computeGravitationalForce(planet, sun);\n"
            "    planet.vx += (force.fx / planet.mass) * dt;\n"
            "    planet.vy += (force.fy / planet.mass) * dt;\n"
            "    planet.x += planet.vx * dt;\n"
            "    planet.y += planet.vy * dt;\n"
            "}\n\n"
            "function render() {\n"
            "    ctx.fillStyle = 'rgba(11, 15, 25, 0.2)';\n"
            "    ctx.fillRect(0, 0, canvas.width, canvas.height);\n"
            "    // Draw Sun\n"
            "    ctx.fillStyle = sun.color;\n"
            "    ctx.beginPath(); ctx.arc(sun.x, sun.y, sun.radius, 0, Math.PI * 2); ctx.fill();\n"
            "    // Draw Planet\n"
            "    ctx.fillStyle = planet.color;\n"
            "    ctx.beginPath(); ctx.arc(planet.x, planet.y, planet.radius, 0, Math.PI * 2); ctx.fill();\n"
            "    updatePhysics();\n"
            "    requestAnimationFrame(render);\n"
            "}\n"
            "render();\n"
        )

        milestones = [
            {
                "id": "m1",
                "title": "Milestone 1: Gravitational Vector Math & Distance Clamping",
                "objective": "Implement Newton's law of universal gravitation with vector decomposition and softening.",
                "tasks": [
                    "Calculate displacement vector dx and dy",
                    "Compute Euclidean distance with epsilon softening to avoid division by zero",
                    "Decompose total force magnitude into Cartesian fx and fy components",
                ],
                "layer1_spec": {"type": "syntax_and_execution", "required_functions": ["computeGravitationalForce"]},
                "layer2_spec": {
                    "checks": [
                        {"id": "force_mag", "type": "scalar_match", "name": "Force Vector Magnitude Check", "expected": 30.86, "rtol": 0.05, "payload_key": "force_magnitude"},
                    ]
                },
                "layer3_spec": {
                    "question_id": "q_m1",
                    "prompt": "Why is a softening parameter (e.g. + 1e-4) added inside the distance formula in numerical simulations?",
                    "rubric": {
                        "required_concepts": ["prevents singularity", "avoids division by zero when bodies collide", "numerical stability"],
                    },
                },
            },
            {
                "id": "m2",
                "title": "Milestone 2: Numerical Integration & Energy Conservation",
                "objective": "Integrate equations of motion and analyze mechanical energy conservation (Kinetic + Potential).",
                "tasks": [
                    "Compute total mechanical energy E = 0.5 * m * v^2 - G * M * m / r",
                    "Evaluate energy drift over 1,000 steps using Euler integration",
                    "Implement Velocity-Verlet integration to test symplectic energy preservation",
                ],
                "layer1_spec": {"type": "syntax_and_execution", "required_functions": ["updatePhysics"]},
                "layer2_spec": {
                    "checks": [
                        {"id": "energy_drift", "type": "energy_conservation", "name": "Hamiltonian Conservation Invariant", "tolerance": 0.05},
                    ]
                },
                "layer3_spec": {
                    "question_id": "q_m2",
                    "prompt": "Why does standard explicit Euler integration cause planets to slowly spiral outward or gain energy over time?",
                    "rubric": {
                        "required_concepts": ["Euler is not symplectic", "accumulates positive truncation error each step", "energy is not conserved"],
                    },
                },
            },
        ]

        return {
            "id": project_id,
            "title": "Planetary Orbit & Gravitational Physics Simulation",
            "description": "Simulate 2-body and N-body gravitational dynamics in HTML5 Canvas, measuring energy conservation and comparing numerical integrators.",
            "domain": "simulation",
            "execution_mode": "browser_iframe",
            "persona": persona,
            "difficulty_profile": profile,
            "pedagogical_params": pedagogy,
            "prerequisites": ["Vectors & Trigonometry", "Newton's Second Law", "Basic Canvas Rendering"],
            "learning_objectives": [
                "Decompose forces into Cartesian coordinates",
                "Understand mechanical energy (Kinetic + Gravitational Potential)",
                "Identify truncation error and symplectic stability across integrators",
            ],
            "estimated_effort_minutes": 50,
            "files": [
                {"name": "index.html", "language": "html", "content": starter_html, "is_entry": True},
                {"name": "orbit.js", "language": "javascript", "content": starter_js, "is_entry": False},
            ],
            "milestones": milestones,
            "educator_rubric": None,
        }

    def _build_generalized_project(
        self,
        project_id: str,
        prompt: str,
        profile: Dict[str, int],
        pedagogy: Dict[str, Any],
        persona: str,
        domain: str,
    ) -> Dict[str, Any]:
        """Constructs a dynamically generated curriculum for arbitrary topics."""
        # Clean title
        title_words = prompt.strip().split()[:7]
        clean_title = " ".join(title_words).capitalize()

        execution_mode = "browser_iframe" if domain == "web" else "browser_pyodide"

        if execution_mode == "browser_pyodide":
            starter_files = [
                {
                    "name": "main.py",
                    "language": "python",
                    "content": (
                        f"# {clean_title}\n"
                        f"# Difficulty Level: {profile['master_difficulty']} / 10\n"
                        f"# NOTE: This is an unverified draft outline for '{prompt}'.\n"
                        "# Automated quantitative tests are not yet synthesized for this topic.\n\n"
                        "# TODO: Define core domain data structures and functions according to milestone tasks\n"
                        "def main():\n"
                        f"    print('Initializing draft project environment for: {clean_title}')\n\n"
                        "if __name__ == '__main__':\n"
                        "    main()\n"
                    ),
                    "is_entry": True,
                }
            ]
        else:
            starter_files = [
                {
                    "name": "index.html",
                    "language": "html",
                    "content": (
                        "<!DOCTYPE html>\n"
                        "<html>\n"
                        "<head>\n"
                        "  <style>body { font-family: sans-serif; padding: 20px; }</style>\n"
                        "</head>\n"
                        "<body>\n"
                        f"  <h2>{clean_title}</h2>\n"
                        "  <div id='app'>Draft project outline. Implement components according to milestone tasks.</div>\n"
                        "  <script src='app.js'></script>\n"
                        "</body>\n"
                        "</html>\n"
                    ),
                    "is_entry": True,
                },
                {
                    "name": "app.js",
                    "language": "javascript",
                    "content": "// Draft outline logic\nconsole.log('Draft app initialized.');\n",
                    "is_entry": False,
                },
            ]

        milestones = [
            {
                "id": "m1",
                "title": "Milestone 1: Core Architecture & Data Modeling",
                "objective": f"Establish the essential model structures and data pipeline for {clean_title}.",
                "tasks": [
                    "Define core state data structures",
                    "Implement primary input transformation function",
                    "Verify baseline output validity",
                ],
                "layer1_spec": {"type": "syntax_and_execution"},
                "layer2_spec": {
                    "checks": [],
                    "verification_status": "unable_to_verify",
                    "reason": "No automated quantitative correctness criteria defined."
                },
                "layer3_spec": {
                    "question_id": "q_m1",
                    "prompt": "What key architectural trade-off was made in choosing this data structure or algorithm?",
                    "rubric": {
                        "required_concepts": ["time complexity", "space complexity", "maintainability"],
                    },
                },
            },
            {
                "id": "m2",
                "title": "Milestone 2: Execution Logic & Algorithmic Refinement",
                "objective": "Implement operational processing rules and verify system behavior under test constraints.",
                "tasks": [
                    "Implement core algorithmic routines",
                    "Handle boundary and edge case inputs",
                    "Optimize execution performance",
                ],
                "layer1_spec": {"type": "syntax_and_execution"},
                "layer2_spec": {
                    "checks": [],
                    "verification_status": "unable_to_verify",
                    "reason": "No automated quantitative correctness criteria defined."
                },
                "layer3_spec": {
                    "question_id": "q_m2",
                    "prompt": "How does the system handle extreme boundary cases or invalid input formats?",
                    "rubric": {
                        "required_concepts": ["validation", "exception handling", "graceful degradation"],
                    },
                },
            },
        ]

        return {
            "id": project_id,
            "title": clean_title,
            "description": f"Hands-on project exploring {prompt}.",
            "domain": domain,
            "execution_mode": execution_mode,
            "persona": persona,
            "difficulty_profile": profile,
            "pedagogical_params": pedagogy,
            "prerequisites": ["Fundamental Programming Concepts"],
            "learning_objectives": [
                f"Master key concepts of {clean_title}",
                "Build and test working implementation from scratch",
                "Evaluate design tradeoffs and verify correctness",
            ],
            "estimated_effort_minutes": 40,
            "files": starter_files,
            "milestones": milestones,
            "educator_rubric": None,
        }

    def adapt_project(
        self,
        project_data: Dict[str, Any],
        milestone_id: str,
        adaptation_type: str,
        context: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        In-flight adaptive scaffolding:
        - remediation: decomposes difficult milestone into a smaller prerequisite task
        - conceptual_support: generates an intuition-building explanation / sub-widget
        - stretch_challenge: introduces a harder extension after verified success
        """
        milestones = project_data.get("milestones", [])
        target_m = next((m for m in milestones if m["id"] == milestone_id), None)
        if not target_m:
            raise ValueError(f"Milestone '{milestone_id}' not found in active project.")

        m_title = target_m.get("title", "Milestone")
        sub_id = f"{milestone_id}_sub_{uuid.uuid4().hex[:4]}"

        if adaptation_type == "remediation":
            return {
                "type": "remediation",
                "sub_id": sub_id,
                "parent_milestone_id": milestone_id,
                "title": f"Bridge Task: Deconstructing {m_title}",
                "objective": "Solve this smaller isolated subproblem before tackling the full milestone.",
                "instructions": (
                    "It looks like you encountered multiple verification errors. "
                    "Let's step down complexity: write and verify an isolated helper function with fixed inputs first."
                ),
                "tasks": [
                    "Isolate the single mathematical formula into an independent helper function",
                    "Test with single scalar input (x=1.0) before running on the full array",
                ],
                "layer1_spec": {"type": "syntax_and_execution"},
                "layer2_spec": {
                    "checks": [
                        {"id": "remed_scalar", "type": "scalar_match", "name": "Helper Function Verification", "expected": 1.0, "payload_key": "helper_val"}
                    ]
                },
            }

        elif adaptation_type == "conceptual_support":
            return {
                "type": "conceptual_support",
                "sub_id": sub_id,
                "parent_milestone_id": milestone_id,
                "title": f"Conceptual Deep-Dive: {m_title}",
                "explanation": (
                    f"Let's build visual intuition for {m_title}.\n\n"
                    "Remember that each step in this algorithm corresponds to a physical or mathematical transformation. "
                    "Notice how the inputs map directly to the target output space."
                ),
                "recommended_action": "Review the concept analogy before updating code.",
            }

        elif adaptation_type == "stretch_challenge":
            return {
                "type": "stretch_challenge",
                "sub_id": sub_id,
                "parent_milestone_id": milestone_id,
                "title": f"Stretch Challenge: Advanced Extension for {m_title}",
                "objective": "Take your working solution to production-grade performance.",
                "instructions": (
                    "Excellent work mastering this milestone on your first attempt! "
                    "Challenge: Can you optimize the algorithmic complexity or implement adaptive step-size?"
                ),
                "tasks": [
                    "Vectorize loops into matrix operations",
                    "Add automated assertion checks for numerical stability",
                ],
                "layer1_spec": {"type": "syntax_and_execution"},
                "layer2_spec": {
                    "checks": [
                        {"id": "stretch_perf", "type": "boolean_assertion", "name": "Stretch Invariant Check", "expected": True, "payload_key": "stretch_pass"}
                    ]
                },
            }

        else:
            raise ValueError(f"Unsupported adaptation type: '{adaptation_type}'")
