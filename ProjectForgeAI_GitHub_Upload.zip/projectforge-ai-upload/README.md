# ProjectForge AI — Dynamic Text-to-Project Learning Engine

ProjectForge AI is an adaptive, project-first B2C EdTech platform that converts natural language problem statements or educational objectives into interactive, hands-on projects scaled across a 4-dimensional difficulty spectrum (1–10).

---

## Core System Architecture & Pillars

1. **Cloud LLM-First with Honest Boundary Disclosure**:
   Server-side multi-provider gateway (Google Gemini, OpenAI, Anthropic Claude, Ollama) with an offline pedagogical heuristic engine. When a prompt is ambiguous or outside reliable boundaries, the system discloses its limits or asks clarifying questions rather than hallucinating superficial code.
2. **4-Dimensional Difficulty Calibration**:
   Disentangles challenge into:
   - **Conceptual Depth ($D_c$)**: Mathematical abstractions, theory, mental models.
   - **Implementation Complexity ($D_i$)**: Architecture, plumbing, lines of code.
   - **Prerequisite Depth ($D_p$)**: Required foundational knowledge.
   - **Independence ($D_a$)**: Autonomy vs. step-by-step guidance.
3. **In-Flight Adaptive Scaffolding**:
   Detects repeated struggle ($\ge 2$ verification failures) to offer decomposed **Bridge Tasks**, and offers **Stretch Challenges** upon immediate mastery.
4. **Three-Layer Verification Architecture**:
   - **Layer 1 (Execution)**: Zero-crash runtime execution in sandboxed client environments.
   - **Layer 2 (Correctness & Rigor)**: Deterministic unit tests, numerical tolerance bounds ($|y - \hat{y}| \le \text{atol} + \text{rtol} \cdot |\hat{y}|$), Hamiltonian energy conservation, loss convergence monotonicity.
   - **Layer 3 (Understanding Probes)**: Socratic conceptual questions evaluating student reasoning against rubrics to confirm true topic mastery.
5. **Browser Preview and Code Execution Boundaries**:
   - HTML/CSS/JS preview uses a restricted `<iframe>` with `sandbox="allow-scripts"` (omitting `allow-same-origin`).
   - The frontend includes a Pyodide-based browser Python runner.
   - **Important limitation:** the backend also contains an in-process Python execution/verification path (`ExecutionEnvironmentManager.execute_in_memory`). Its AST checks are not a security sandbox, and the `timeout_seconds` argument does not enforce a timeout. Do not expose this backend path to arbitrary untrusted learner code in a public deployment. A separate OS/container-level sandbox with resource limits is required before doing so.
   - Provider API keys are read from server-side environment variables; never commit `.env` or real credentials.

---

## Getting Started

### 1. Requirements
- Python 3.10+ (Tested on Python 3.13)
- Modern web browser (Chrome, Edge, Firefox, Safari)

### 2. Environment Setup (Optional Cloud Providers)
ProjectForge AI functions out of the box with its built-in pedagogical heuristic engine. To connect live cloud LLMs, configure environment variables in `.env`:

```env
# Optional Cloud LLM Keys
GEMINI_API_KEY=your_gemini_api_key_here
OPENAI_API_KEY=your_openai_key_here
ANTHROPIC_API_KEY=your_anthropic_key_here
OLLAMA_HOST=http://localhost:11434
```

### 3. Launching the Application
Run the Flask server:
```powershell
python app.py
```
Open your browser at:
```
http://127.0.0.1:5000
```

---

## Running the Automated Test Suite

Run pytest to verify all API contracts, validation edge cases, numerical verifications, Socratic tiers, and security safeguards:

```powershell
python -m pytest tests/ -v
```

---

## API Contract Reference

| Method | Endpoint | Description |
| :--- | :--- | :--- |
| `GET` | `/api/config` | Client-safe provider and sandbox configuration (zero secrets leaked). |
| `GET` | `/api/templates` | Curated educational template catalogue with verified criteria. |
| `POST` | `/api/project/generate` | Generates structured project model or returns `needs_clarification`. |
| `POST` | `/api/project/adapt` | In-flight adaptation (`remediation`, `conceptual_support`, `stretch_challenge`). |
| `POST` | `/api/tutor/message` | Contextual Socratic tutor chat supporting Tiers 1, 2, and 3. |
| `POST` | `/api/verify/layer2` | Deterministic and quantitative correctness evaluation. |
| `POST` | `/api/verify/layer3` | Socratic conceptual understanding and transfer assessment. |
| `GET` | `/api/project/<id>` | Retrieves saved project state. |
| `POST` | `/api/project/<id>/save` | Persists learner code, active milestone, and progress. |
| `GET` | `/api/project/<id>/export` | Packages project code and mastery reflection report into a ZIP. |


## Security and deployment notes

- Set `SECRET_KEY` to a strong random value in the deployment environment. If it is not set, the app generates a process-local random key; sessions will not survive a server restart.
- Set provider keys (`GEMINI_API_KEY`, `OPENAI_API_KEY`, `ANTHROPIC_API_KEY`) only as environment variables.
- Runtime learner project data and retrieval caches are intentionally excluded from this repository by `.gitignore`.
- The backend in-process code execution path is for trusted/reference code only until replaced with an isolated execution service. Do not describe the current implementation as a secure server-side sandbox.
