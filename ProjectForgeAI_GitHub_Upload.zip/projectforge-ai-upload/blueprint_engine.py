"""
blueprint_engine.py
===================
Structured Project Blueprint & Ambiguity State Machine Architecture.
Phase 2 Implementation for ProjectForge AI.

Key architectural responsibilities:
1. Blocking Ambiguity State Machine:
   - Evaluates polysemic and multi-disciplinary terms (equilibrium, regression, model, stability, agent, network).
   - Halts generation and transitions to REQUIRES_CLARIFICATION.
   - Never silently resolves material ambiguities with default assumptions.
   - Maintains workflow resumption state and captures explicit user responses.
2. Parallel Domain Specifications:
   - Decomposes prompts into parallel DomainSpec objects without hierarchical dominance.
   - Assigns individual relevance, key concepts, computational methods, prerequisites, and verification types.
   - Retains backward-compatible domain_roles projection.
3. 20-Field Canonical Blueprint Architecture:
   - Strict completeness validation.
   - True DAG cycle detection, self-referential check, and missing dependency detection.
   - Explicit 6-bucket provenance model: learner_supplied, system_inferred, working_assumptions,
     clarification_requirements, external_retrieval_requirements, unverified_limitations.
4. General-Purpose Dynamic Synthesis:
   - Dynamically formulates milestones and genuine verification checks for both familiar
     and unfamiliar / interdisciplinary topics.
   - Eliminates unverified placeholder checks.
5. Downstream System Contracts:
   - KnowledgeRetrievalContract
   - ArtifactGenerationContract
   - VerificationSpecContract
   - TutorContextContract
"""

import uuid
import re
import time
from typing import Dict, Any, List, Optional, Tuple, Set


# =====================================================================
# 1. Ambiguity & Workflow States
# =====================================================================

class WorkflowState:
    RECEIVED = "RECEIVED"
    ANALYSING = "ANALYSING"
    REQUIRES_CLARIFICATION = "REQUIRES_CLARIFICATION"
    AWAITING_USER_RESPONSE = "AWAITING_USER_RESPONSE"
    READY_FOR_BLUEPRINT = "READY_FOR_BLUEPRINT"
    BLUEPRINT_VALIDATED = "BLUEPRINT_VALIDATED"
    GENERATION_IN_PROGRESS = "GENERATION_IN_PROGRESS"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"


class AmbiguityClarificationRequiredException(Exception):
    """Raised when an ambiguous prompt cannot proceed without learner clarification."""
    def __init__(self, message: str, unresolved_ambiguities: List[Dict[str, Any]], session_id: str):
        super().__init__(message)
        self.unresolved_ambiguities = unresolved_ambiguities
        self.session_id = session_id


class AmbiguityOption:
    def __init__(self, role: str, interpretation: str, suggested_scope: str, tradeoffs: str = ""):
        self.role = role
        self.interpretation = interpretation
        self.suggested_scope = suggested_scope
        self.tradeoffs = tradeoffs

    def to_dict(self) -> Dict[str, Any]:
        return {
            "role": self.role,
            "interpretation": self.interpretation,
            "suggested_scope": self.suggested_scope,
            "tradeoffs": self.tradeoffs,
        }


class PolysemicTerm:
    def __init__(
        self,
        term: str,
        question: str,
        explanation: str,
        alternatives: List[Dict[str, Any]],
        default_assumption: str = "",
    ):
        self.term = term
        self.question = question
        self.explanation = explanation
        self.alternatives = alternatives
        self.default_assumption = default_assumption

    def to_dict(self) -> Dict[str, Any]:
        return {
            "term": self.term,
            "question": self.question,
            "explanation": self.explanation,
            "alternatives": self.alternatives,
            "default_assumption": self.default_assumption,
        }


class ClarificationSession:
    """Encapsulates a learner clarification session across the ambiguity state machine."""
    def __init__(
        self,
        session_id: str,
        prompt: str,
        difficulty: int = 5,
        persona: str = "student",
        domain: str = "auto",
    ):
        self.session_id = session_id
        self.prompt = prompt
        self.difficulty = difficulty
        self.persona = persona
        self.domain = domain
        self.state = WorkflowState.RECEIVED
        self.unresolved_ambiguities: List[Dict[str, Any]] = []
        self.resolved_clarifications: Dict[str, Dict[str, Any]] = {}
        self.clarification_question: str = ""
        self.blueprint: Optional[Dict[str, Any]] = None
        self.validation_result: Optional[Dict[str, Any]] = None
        self.created_at = time.time()
        self.updated_at = time.time()

    def to_dict(self) -> Dict[str, Any]:
        return {
            "session_id": self.session_id,
            "prompt": self.prompt,
            "difficulty": self.difficulty,
            "persona": self.persona,
            "domain": self.domain,
            "state": self.state,
            "unresolved_ambiguities": self.unresolved_ambiguities,
            "resolved_clarifications": self.resolved_clarifications,
            "clarification_question": self.clarification_question,
            "can_proceed_to_generation": self.state in (WorkflowState.READY_FOR_BLUEPRINT, WorkflowState.BLUEPRINT_VALIDATED),
            "blueprint": self.blueprint,
            "validation_result": self.validation_result,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }


# =====================================================================
# 2. Parallel Domain Specification
# =====================================================================

class DomainSpec:
    """
    Parallel domain specification treating materially relevant disciplines as peer collaborators.
    Avoids rigid primary/supporting hierarchies while preserving quantitative relevance.
    """
    def __init__(
        self,
        domain_id: str,
        name: str,
        relevance: float,
        concepts: List[str],
        methods: List[str],
        prerequisites: List[str],
        milestones: List[str],
        verification_type: str,
    ):
        self.id = domain_id
        self.name = name
        self.relevance = max(0.0, min(1.0, float(relevance)))
        self.concepts = concepts
        self.methods = methods
        self.prerequisites = prerequisites
        self.milestones = milestones
        self.verification_type = verification_type

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "relevance": self.relevance,
            "concepts": self.concepts,
            "methods": self.methods,
            "prerequisites": self.prerequisites,
            "milestones": self.milestones,
            "verification_type": self.verification_type,
        }


# =====================================================================
# 3. Blueprint Validation Result
# =====================================================================

class BlueprintValidationResult:
    def __init__(self, is_valid: bool, errors: List[str], warnings: List[str], blueprint: Optional[Dict[str, Any]] = None):
        self.is_valid = is_valid
        self.errors = errors
        self.warnings = warnings
        self.blueprint = blueprint

    def to_dict(self) -> Dict[str, Any]:
        return {
            "is_valid": self.is_valid,
            "errors": self.errors,
            "warnings": self.warnings,
            "blueprint": self.blueprint,
        }


# =====================================================================
# 4. Ambiguity State Machine & Registry
# =====================================================================

class AmbiguityStateMachine:
    """
    State machine that manages prompt ingestion, ambiguity evaluation,
    blocking clarification pauses, user resolution integration, and blueprint synthesis.
    """
    _SESSIONS: Dict[str, ClarificationSession] = {}

    @classmethod
    def get_session(cls, session_id: str) -> Optional[ClarificationSession]:
        return cls._SESSIONS.get(session_id)

    @classmethod
    def start_session(
        cls,
        prompt: str,
        difficulty: int = 5,
        persona: str = "student",
        domain: str = "auto",
        enforce_clarification: bool = True,
    ) -> ClarificationSession:
        session_id = f"clarif_{uuid.uuid4().hex[:12]}"
        session = ClarificationSession(
            session_id=session_id,
            prompt=prompt,
            difficulty=difficulty,
            persona=persona,
            domain=domain,
        )
        cls._SESSIONS[session_id] = session

        # Ingestion -> Analysing
        session.state = WorkflowState.ANALYSING
        ambiguities = BlueprintEngine.detect_ambiguities(prompt)

        if ambiguities and enforce_clarification:
            session.state = WorkflowState.REQUIRES_CLARIFICATION
            session.unresolved_ambiguities = ambiguities
            # Format comprehensive clarification prompt
            questions = []
            for amb in ambiguities:
                q_text = f"Clarification needed for '{amb['term']}': {amb['explanation']}\nOptions:"
                for opt in amb["alternatives"]:
                    q_text += f"\n  - [{opt['role']}]: {opt['interpretation']} (scope: {opt.get('suggested_scope', 'general')})"
                questions.append(q_text)
            session.clarification_question = "\n\n".join(questions)
            session.updated_at = time.time()
            return session

        # If unambiguous or clarification not enforced, proceed directly
        session.state = WorkflowState.READY_FOR_BLUEPRINT
        bp = BlueprintEngine.create_blueprint(
            prompt=prompt,
            difficulty=difficulty,
            persona=persona,
            domain=domain,
            clarification_resolutions=session.resolved_clarifications,
            enforce_clarification=False,
        )
        val = BlueprintEngine.validate_blueprint(bp)
        session.blueprint = bp
        session.validation_result = val.to_dict()
        session.state = WorkflowState.BLUEPRINT_VALIDATED if val.is_valid else WorkflowState.FAILED
        session.updated_at = time.time()
        return session

    @classmethod
    def resolve_clarification(
        cls,
        session_id: str,
        user_responses: Dict[str, str],
    ) -> ClarificationSession:
        """
        Resumes a paused workflow using explicit user responses.
        Never falls back silently to default assumptions.
        """
        session = cls.get_session(session_id)
        if not session:
            raise KeyError(f"Clarification session '{session_id}' not found.")

        if not user_responses or not isinstance(user_responses, dict):
            raise ValueError("user_responses must be a dictionary mapping terms to chosen interpretations.")

        # Record explicit user selections
        for term, response in user_responses.items():
            session.resolved_clarifications[term] = {
                "user_response": response,
                "resolved_at": time.time(),
            }

        # Check remaining unresolved terms
        unresolved = [
            amb for amb in session.unresolved_ambiguities
            if amb["term"] not in session.resolved_clarifications
        ]
        session.unresolved_ambiguities = unresolved

        if unresolved:
            session.state = WorkflowState.REQUIRES_CLARIFICATION
            session.updated_at = time.time()
            return session

        # All resolved -> Ready for blueprint
        session.state = WorkflowState.READY_FOR_BLUEPRINT
        bp = BlueprintEngine.create_blueprint(
            prompt=session.prompt,
            difficulty=session.difficulty,
            persona=session.persona,
            domain=session.domain,
            clarification_resolutions=session.resolved_clarifications,
            enforce_clarification=False,
        )
        val = BlueprintEngine.validate_blueprint(bp)
        session.blueprint = bp
        session.validation_result = val.to_dict()
        session.state = WorkflowState.BLUEPRINT_VALIDATED if val.is_valid else WorkflowState.FAILED
        session.updated_at = time.time()
        return session


# =====================================================================
# 5. Main Blueprint Engine
# =====================================================================

class BlueprintEngine:
    """
    Constructs, inspects, and validates 20-field Project Blueprints
    with parallel domain specifications, explicit provenance, and ambiguity detection.
    """

    SUPPORTED_DOMAINS = (
        "data_science", "simulation", "algorithms", "web",
        "mathematics", "economics", "python", "systems_engineering", "quantum"
    )

    AMBIGUOUS_TERMS = {
        "equilibrium": {
            "question": "How should 'equilibrium' be modeled in this project?",
            "explanation": "The term 'equilibrium' has fundamentally different definitions across economics, physics, and game theory.",
            "alternatives": [
                {"role": "economics", "interpretation": "Supply and Demand market clearing price/quantity", "suggested_scope": "microeconomics", "tradeoffs": "Models price adjustment and market clearance; ignores force vectors."},
                {"role": "physics", "interpretation": "Mechanical / static balance of physical forces", "suggested_scope": "classical_mechanics", "tradeoffs": "Models vector force equilibrium (sum F = 0); ignores economic incentives."},
                {"role": "game_theory", "interpretation": "Nash equilibrium across strategic agent payoff matrices", "suggested_scope": "game_theory", "tradeoffs": "Models strategic choice equilibria; requires discrete or continuous payoff tensors."},
            ],
            "default_assumption": "If not specified in an economic prompt, assume competitive supply/demand market equilibrium."
        },
        "regression": {
            "question": "Which methodological approach to 'regression' is intended?",
            "explanation": "Regression can denote statistical linear modeling, non-linear machine learning curves, or software testing regression.",
            "alternatives": [
                {"role": "statistics", "interpretation": "Ordinary Least Squares / analytical parameter estimation", "suggested_scope": "econometrics", "tradeoffs": "Closed-form Gauss-Markov optimal estimator; requires matrix inversion."},
                {"role": "machine_learning", "interpretation": "Iterative gradient descent optimization on numerical features", "suggested_scope": "machine_learning", "tradeoffs": "Scales to large datasets; requires learning rate tuning and epoch monitoring."},
                {"role": "software", "interpretation": "Automated regression test suite verifying unchanged software behavior", "suggested_scope": "software_engineering", "tradeoffs": "Focuses on test harness and backward compatibility; no numerical modeling."},
            ],
            "default_assumption": "Assume linear regression via gradient descent optimizer from first principles."
        },
        "model": {
            "question": "What architectural type of 'model' should be built?",
            "explanation": "The term 'model' could denote an economic conceptual model, a 3D visual graphic model, or a machine learning neural model.",
            "alternatives": [
                {"role": "machine_learning", "interpretation": "Predictive computational algorithm trained on data", "suggested_scope": "data_science", "tradeoffs": "Focuses on loss optimization, feature weights, and out-of-sample generalization."},
                {"role": "simulation", "interpretation": "Mathematical equations modeling dynamic physical phenomena", "suggested_scope": "simulation", "tradeoffs": "Focuses on numerical integration of differential equations over time."},
                {"role": "software", "interpretation": "Relational database schema and object-oriented data structures", "suggested_scope": "software_engineering", "tradeoffs": "Focuses on entity relationships, CRUD interfaces, and type safety."},
            ],
            "default_assumption": "Assume algorithmic or computational model matching the detected domain."
        },
        "stability": {
            "question": "Which dimension of 'stability' is the objective?",
            "explanation": "'Stability' refers to numerical convergence in computational methods, structural stability in physics, or financial stability in macroeconomics.",
            "alternatives": [
                {"role": "numerical", "interpretation": "Symplectic energy preservation and bounded integration error", "suggested_scope": "numerical_analysis", "tradeoffs": "Focuses on bounded phase-space volume and truncation error."},
                {"role": "economics", "interpretation": "Convergence of dynamic monetary or market systems over time", "suggested_scope": "macroeconomics", "tradeoffs": "Focuses on inflation-unemployment loops and policy damping."},
            ],
            "default_assumption": "Assume numerical integration and floating-point stability."
        },
        "agent": {
            "question": "What type of 'agent' should be implemented?",
            "explanation": "'Agent' can mean an autonomous reinforcement learning policy, an economic rational decision-maker, or a software microservice.",
            "alternatives": [
                {"role": "reinforcement_learning", "interpretation": "Markov decision process policy maximizing expected cumulative reward", "suggested_scope": "ai_agents", "tradeoffs": "Requires action space, observation state, and reward function formulation."},
                {"role": "economics", "interpretation": "Utility-maximizing economic actor under budget constraints", "suggested_scope": "microeconomics", "tradeoffs": "Solves constrained optimization via Lagrange multipliers."},
                {"role": "software", "interpretation": "Concurrent asynchronous task worker coordinating API events", "suggested_scope": "distributed_systems", "tradeoffs": "Focuses on event loops, thread safety, and message queues."},
            ],
            "default_assumption": "Assume computational agent appropriate to the primary disciplinary context."
        },
        "network": {
            "question": "Which category of 'network' is required?",
            "explanation": "'Network' can mean a graph data structure, a deep neural network, or a TCP/IP network simulation.",
            "alternatives": [
                {"role": "graph_algorithms", "interpretation": "Adjacency-list graph data structure with pathfinding algorithms", "suggested_scope": "discrete_mathematics", "tradeoffs": "Evaluates O(V + E) search algorithms and edge traversals."},
                {"role": "neural_networks", "interpretation": "Multi-layer perceptron with matrix forward/backward propagation", "suggested_scope": "deep_learning", "tradeoffs": "Evaluates tensor matrix multiplications and activation functions."},
                {"role": "telecommunications", "interpretation": "Packet routing and transport protocol simulation", "suggested_scope": "computer_networks", "tradeoffs": "Evaluates packet loss, latency, and socket buffers."},
            ],
            "default_assumption": "Assume graph data structure and algorithms unless machine learning is specified."
        }
    }

    @classmethod
    def detect_ambiguities(cls, prompt: str) -> List[Dict[str, Any]]:
        """Identifies potentially ambiguous polysemic terms in the prompt."""
        clean = prompt.lower()
        found = []
        for term, data in cls.AMBIGUOUS_TERMS.items():
            pattern = rf"\b{re.escape(term)}\b"
            if re.search(pattern, clean):
                found.append({
                    "term": term,
                    "question": data.get("question", f"How should '{term}' be interpreted?"),
                    "explanation": data["explanation"],
                    "alternatives": data["alternatives"],
                    "default_assumption": data["default_assumption"],
                })
        return found

    @classmethod
    def decompose_domains(cls, prompt: str, user_domain: str = "auto") -> List[Dict[str, Any]]:
        """
        Decomposes a prompt into parallel, non-hierarchical domain specifications.
        Each domain has an individual relevance score (0.0 to 1.0) and concrete concepts.
        """
        clean = prompt.lower()
        domains: List[DomainSpec] = []

        # 1. Economics & Econometrics
        if any(w in clean for w in ("macroeconomic", "inflation", "monetary", "unemployment", "gdp", "supply", "demand", "market", "economic", "econometric", "ols")):
            relevance = 0.95 if any(w in clean for w in ("inflation", "monetary", "gdp", "economic")) else 0.70
            domains.append(DomainSpec(
                domain_id="economics",
                name="Economics & Econometrics",
                relevance=relevance,
                concepts=["Market equilibrium", "Phillips curve", "Gauss-Markov assumptions", "Elasticity of substitution"],
                methods=["Ordinary Least Squares", "Structural vector autoregression", "Comparative statics"],
                prerequisites=["Basic algebra", "Differential calculus", "Introductory probability"],
                milestones=["Formalize economic DGP", "Estimate structural parameters", "Evaluate diagnostic residuals"],
                verification_type="scalar_match"
            ))

        # 2. Machine Learning & Optimization
        if any(w in clean for w in ("machine learning", "neural", "gradient descent", "loss", "classifier", "regression", "optimization", "dataset")):
            relevance = 0.95 if any(w in clean for w in ("gradient descent", "neural", "loss", "classifier")) else 0.75
            domains.append(DomainSpec(
                domain_id="machine_learning",
                name="Machine Learning & Numerical Optimization",
                relevance=relevance,
                concepts=["Loss surface convexity", "Analytical chain rule gradients", "Iterative parameter descent", "Out-of-sample generalization"],
                methods=["Batch gradient descent", "Vectorized prediction mapping", "Train/test partition"],
                prerequisites=["Multivariate calculus", "Linear algebra", "Python array slicing"],
                milestones=["Formulate hypothesis & loss metric", "Compute analytical gradients", "Execute iterative training loop"],
                verification_type="loss_convergence"
            ))

        # 3. Classical Mechanics & Simulation
        if any(w in clean for w in ("orbit", "gravity", "physics", "simulation", "euler", "verlet", "pendulum", "fluid", "lorenz", "mechanics")):
            relevance = 0.95 if any(w in clean for w in ("orbit", "gravity", "pendulum", "verlet")) else 0.70
            domains.append(DomainSpec(
                domain_id="classical_mechanics",
                name="Classical Mechanics & Physics Simulation",
                relevance=relevance,
                concepts=["Newton's laws of motion", "Hamiltonian dynamics", "Symplectic geometry", "Conservation of mechanical energy"],
                methods=["Velocity Verlet numerical integration", "Cartesian force vector decomposition", "Phase-space volume tracking"],
                prerequisites=["Vector trigonometry", "Differential equations", "Newtonian mechanics"],
                milestones=["Compute pairwise forces", "Implement symplectic integrator", "Verify mechanical energy conservation"],
                verification_type="energy_conservation"
            ))

        # 4. Computer Science Algorithms & Data Structures
        if any(w in clean for w in ("sort", "tree", "graph", "search", "dijkstra", "avl", "algorithm", "data structure", "hash table", "b-tree")):
            relevance = 0.95 if any(w in clean for w in ("avl", "tree", "dijkstra", "b-tree", "algorithm")) else 0.70
            domains.append(DomainSpec(
                domain_id="computer_science_algorithms",
                name="Algorithms & Data Structures",
                relevance=relevance,
                concepts=["Asymptotic time complexity O(log N)", "Height balancing invariant", "Tree rotation mechanics", "Dynamic pointer manipulation"],
                methods=["Recursive insertion with balancing", "In-order traversal verification", "Node pointer rewriting"],
                prerequisites=["Object-oriented programming", "Inductive proofs", "Recursion"],
                milestones=["Define node structure & height invariants", "Implement tree rotation routines", "Verify asymptotic bounds on test suite"],
                verification_type="unit_test_suite"
            ))

        # 5. Applied Mathematics & Numerical Analysis
        if any(w in clean for w in ("taylor", "root", "newton", "derivative", "calculus", "integral", "matrix", "linear algebra", "eigenvalue")):
            relevance = 0.90 if any(w in clean for w in ("newton", "taylor", "root")) else 0.65
            domains.append(DomainSpec(
                domain_id="applied_mathematics",
                name="Applied Mathematics & Numerical Methods",
                relevance=relevance,
                concepts=["Taylor series remainder theorem", "Quadratic convergence rate", "Condition number", "Floating-point epsilon"],
                methods=["Newton-Raphson iteration", "Polynomial evaluation", "Residual error tracking"],
                prerequisites=["Differential calculus", "Real analysis basics"],
                milestones=["Derive theoretical convergence bounds", "Implement iterative solver with divergence guards", "Verify quadratic residual reduction"],
                verification_type="scalar_match"
            ))

        # Fallback / General Programming if no domain matched
        if not domains:
            selected_domain = user_domain if user_domain != "auto" else "general_programming"
            domains.append(DomainSpec(
                domain_id=selected_domain,
                name=selected_domain.replace("_", " ").title(),
                relevance=1.0,
                concepts=["Modular software architecture", "Functional correctness", "Edge-case handling"],
                methods=["Test-driven development", "Defensive programming", "Boundary condition verification"],
                prerequisites=["Basic programming syntax", "Control flow"],
                milestones=["Construct baseline data pipeline", "Implement core operational routines", "Verify boundary invariant test suite"],
                verification_type="unit_test_suite"
            ))

        # Sort domains by relevance descending
        domains.sort(key=lambda d: d.relevance, reverse=True)
        return [d.to_dict() for d in domains]

    @classmethod
    def decompose_domain_roles(cls, prompt: str, user_domain: str = "auto") -> Dict[str, str]:
        """
        Backwards-compatible projection of parallel domains into functional roles dictionary.
        """
        parallel_domains = cls.decompose_domains(prompt, user_domain)
        roles: Dict[str, str] = {}

        if parallel_domains:
            primary_id = parallel_domains[0]["id"]
            roles["primary"] = primary_id

            if len(parallel_domains) > 1:
                roles["methodological"] = parallel_domains[1]["id"]
                roles["supporting"] = parallel_domains[1]["id"]
            else:
                roles["methodological"] = "analytical_methods"
                roles["supporting"] = "procedural_logic"

            # Domain specific contextual mappings for backwards compatibility
            clean = prompt.lower()
            if primary_id == "economics" and any(w in clean for w in ("machine learning", "neural", "predict")):
                roles["methodological"] = "machine_learning"
                roles["computational"] = "python_scientific"
                roles["evaluation"] = "econometrics_and_statistics"
                roles["contextual"] = "macroeconomic_policy"
            elif primary_id == "machine_learning":
                roles["supporting"] = "linear_algebra_and_calculus"
                roles["methodological"] = "optimization_theory"
                roles["computational"] = "pure_python_or_numpy"
                roles["evaluation"] = "loss_convergence_and_metrics"
                roles["contextual"] = "predictive_modeling"
            elif primary_id == "classical_mechanics":
                roles["supporting"] = "differential_equations"
                roles["methodological"] = "numerical_integration"
                roles["computational"] = "html5_canvas_javascript"
                roles["evaluation"] = "hamiltonian_energy_conservation"
                roles["contextual"] = "astrophysics_simulation"
            elif primary_id == "computer_science_algorithms":
                roles["supporting"] = "discrete_mathematics"
                roles["methodological"] = "asymptotic_analysis"
                roles["computational"] = "python"
                roles["evaluation"] = "operation_counters_and_invariants"
                roles["contextual"] = "software_engineering"
            else:
                roles["computational"] = "browser_runtime"
                roles["evaluation"] = "functional_correctness"
                roles["contextual"] = "applied_programming"
        else:
            roles["primary"] = user_domain if user_domain != "auto" else "general_programming"
            roles["supporting"] = "procedural_logic"
            roles["methodological"] = "modular_software_design"
            roles["computational"] = "browser_runtime"
            roles["evaluation"] = "functional_correctness"
            roles["contextual"] = "applied_programming"

        return roles

    @classmethod
    def create_blueprint(
        cls,
        prompt: str,
        difficulty: int = 5,
        persona: str = "student",
        domain: str = "auto",
        custom_inputs: Optional[Dict[str, Any]] = None,
        clarification_resolutions: Optional[Dict[str, Any]] = None,
        enforce_clarification: bool = False,
    ) -> Dict[str, Any]:
        """
        Constructs a complete 20-field Project Blueprint with parallel domain specifications
        and explicit provenance tagging.
        """
        if not prompt or not isinstance(prompt, str) or len(prompt.strip()) < 3:
            raise ValueError("Prompt must be a string with at least 3 characters.")

        clean_prompt = prompt.strip()
        ambiguities = cls.detect_ambiguities(clean_prompt)
        resolved_dict = clarification_resolutions or {}

        # If clarification is enforced and material ambiguities are unresolved, block!
        if enforce_clarification:
            unresolved = [a for a in ambiguities if a["term"] not in resolved_dict]
            if unresolved:
                raise AmbiguityClarificationRequiredException(
                    message=f"Prompt contains {len(unresolved)} unresolved ambiguous term(s) requiring learner clarification.",
                    unresolved_ambiguities=unresolved,
                    session_id=f"clarif_{uuid.uuid4().hex[:12]}"
                )

        # Parallel Domain Decomposition
        parallel_domains = cls.decompose_domains(clean_prompt, domain)
        domain_roles = cls.decompose_domain_roles(clean_prompt, domain)

        blueprint_id = f"bp_{uuid.uuid4().hex[:10]}"
        lower_prompt = clean_prompt.lower()

        # Derive runtime environment
        execution_env = "browser_iframe" if ("canvas" in lower_prompt or "html" in lower_prompt or "web" in lower_prompt or (len(parallel_domains) > 0 and parallel_domains[0]["id"] == "web")) else "browser_pyodide"
        is_curated = (
            "regression" in lower_prompt
            or "gradient descent" in lower_prompt
            or "orbit" in lower_prompt
            or "gravity" in lower_prompt
        )

        # Explicit Provenance Categorization
        working_assumptions = [
            "Assume standard educational floating-point tolerances.",
            "Assume local client-side execution within browser sandbox limits."
        ]
        if resolved_dict:
            for term, res_data in resolved_dict.items():
                choice = res_data.get("user_response") if isinstance(res_data, dict) else str(res_data)
                working_assumptions.append(f"Learner explicitly resolved ambiguous term '{term}' to interpretation: '{choice}'.")

        provenance = {
            "learner_supplied": {
                "raw_prompt": clean_prompt,
                "requested_difficulty": difficulty,
                "requested_persona": persona,
                "explicit_domain_preference": domain if domain != "auto" else None,
                "resolved_clarifications": resolved_dict,
            },
            "system_inferred": {
                "parallel_domains": parallel_domains,
                "domain_roles": domain_roles,
                "execution_environment": execution_env,
                "capability_composition": [d["id"] for d in parallel_domains],
            },
            "working_assumptions": working_assumptions,
            "clarification_requirements": [
                amb["explanation"] for amb in ambiguities if amb["term"] not in resolved_dict
            ],
            "external_retrieval_requirements": [],
            "unverified_limitations": []
        }

        # -------------------------------------------------------------
        # Dynamic Milestone Synthesis
        # -------------------------------------------------------------
        if "regression" in lower_prompt or "gradient descent" in lower_prompt:
            project_objective = "Implement a custom univariate linear regression optimizer from first principles using gradient descent."
            intended_deliverable = "An executable Python module ('regression.py') implementing hypothesis evaluation, MSE loss, analytical gradients, and training loop."
            key_concepts = [
                "Linear hypothesis: y_hat = w*x + b",
                "Mean Squared Error loss: L = (1/N) * sum((y_pred - y_true)^2)",
                "Analytical partial derivatives dL/dw and dL/db via chain rule",
                "Iterative gradient descent parameter updates",
                "Loss surface convexity and monotonic convergence",
            ]
            prerequisites = ["Basic Python syntax", "Algebraic derivatives intuition", "Summation notation"]
            required_inputs = ["Synthetic 1D numerical feature arrays (X) and ground-truth targets (y)"]
            planned_outputs = ["Optimal slope w", "Optimal intercept b", "Loss history array across iterations"]
            tech_arch = {
                "language": "python",
                "runtime": "browser_pyodide",
                "entry_file": "regression.py",
                "isolation": "client_webworker",
                "memory_budget_mb": 128,
            }
            milestones = [
                {
                    "id": "m1",
                    "title": "Hypothesis & Mean Squared Error Loss",
                    "purpose": "Formulate predictive linear mapping and scalar error metric.",
                    "task": "Implement compute_predictions and compute_mse_loss functions.",
                    "expected_output": "Prediction vector and scalar MSE loss strictly matching ground-truth.",
                    "verification_check": {"type": "scalar_match", "expected": 4.0, "rtol": 0.001, "payload_key": "test_mse"},
                    "failure_modes": ["Forgetting (1/N) divisor", "Residual sign cancellation when not squared"],
                    "depends_on": []
                },
                {
                    "id": "m2",
                    "title": "Analytical Gradients & Parameter Update",
                    "purpose": "Derive calculus gradients to guide parameters toward minimal error.",
                    "task": "Implement compute_gradients and update_parameters functions.",
                    "expected_output": "Gradient tuple (dL/dw, dL/db) evaluated on reference observations.",
                    "verification_check": {"type": "array_tolerance", "expected": [-10.6667, -4.0], "rtol": 0.01, "payload_key": "test_grads"},
                    "failure_modes": ["Missing factor of 2 in derivative", "Adding gradient instead of subtracting"],
                    "depends_on": ["m1"]
                },
                {
                    "id": "m3",
                    "title": "Iterative Training Loop & Convergence Analysis",
                    "purpose": "Execute gradient descent iteratively until convergence threshold is satisfied.",
                    "task": "Implement fit() training loop recording epoch losses.",
                    "expected_output": "Loss strictly decreases across epochs, reaching target slope w ~ 2.0.",
                    "verification_check": {"type": "loss_convergence", "min_reduction_pct": 50.0, "payload_key": "loss_history"},
                    "failure_modes": ["Learning rate too large causing divergence", "Premature loop termination"],
                    "depends_on": ["m2"]
                }
            ]
            verification_strategy = "Three-layer evaluation: syntax check, scalar/loss quantitative invariants, and conceptual Socratic probe."
            expected_failure_modes = ["Exploding loss due to high alpha", "NaN gradients from floating-point overflow"]
            known_limitations = ["Univariate formulation; does not generalize to multi-feature matrix inversion without modification."]
            external_info_reqs = []
            completion_criteria = ["Fitted slope w converges to 2.0 within 5% tolerance", "Recorded training loss reduces by >= 50% without divergence"]

        elif "orbit" in lower_prompt or "gravity" in lower_prompt:
            project_objective = "Simulate 2-body and N-body gravitational dynamics with mechanical energy conservation checks."
            intended_deliverable = "An interactive HTML5 Canvas simulation with real-time numerical integration and energy telemetry meters."
            key_concepts = ["Newton's Law of Universal Gravitation", "Cartesian force decomposition", "Kinetic and Gravitational Potential Energy", "Hamiltonian preservation in symplectic systems"]
            prerequisites = ["Trigonometry & Cartesian vectors", "Newton's Second Law", "Basic Canvas rendering loop"]
            required_inputs = ["Body masses, initial Cartesian coordinates (x, y), initial velocities (vx, vy)"]
            planned_outputs = ["Visual orbital trajectory", "Real-time mechanical energy readout", "Relative energy drift %"]
            tech_arch = {
                "language": "javascript_html5",
                "runtime": "browser_iframe",
                "entry_file": "index.html",
                "support_files": ["orbit.js"],
                "isolation": "sandboxed_iframe",
                "memory_budget_mb": 64,
            }
            milestones = [
                {
                    "id": "m1",
                    "title": "Gravitational Vector Force Calculation",
                    "purpose": "Compute pairwise inverse-square force with gravitational softening.",
                    "task": "Implement computeGravitationalForce(b1, b2).",
                    "expected_output": "Accurate force components fx and fy avoiding singularity.",
                    "verification_check": {"type": "scalar_match", "expected": 1.25, "rtol": 0.05, "payload_key": "sample_force"},
                    "failure_modes": ["Division by zero when dist ~ 0", "Inverted force direction vector"],
                    "depends_on": []
                },
                {
                    "id": "m2",
                    "title": "Symplectic Numerical Integration & Energy Conservation",
                    "purpose": "Update body velocities and positions while conserving mechanical energy.",
                    "task": "Implement updatePhysics() and computeTotalEnergy().",
                    "expected_output": "Mechanical energy drift strictly under 5% over 1,000 integration steps.",
                    "verification_check": {"type": "energy_conservation", "tolerance": 0.05, "payload_key": "energy_telemetry"},
                    "failure_modes": ["Standard explicit Euler causes artificial energy growth and orbital spiral-out"],
                    "depends_on": ["m1"]
                }
            ]
            verification_strategy = "Kinematic invariant check: verify Hamiltonian |(E_final - E_0) / E_0| <= tolerance."
            expected_failure_modes = ["Planetary escape velocity overshoot", "Integration instability during close encounters"]
            known_limitations = ["2D planar approximation; does not model relativistic precession or 3D planetary perturbations."]
            external_info_reqs = []
            completion_criteria = ["Stable closed orbital path without continuous spiral drift", "Total mechanical energy conserved within 5% tolerance"]

        else:
            # Dynamic synthesis for unfamiliar / interdisciplinary objectives
            title_clean = " ".join(clean_prompt.split()[:8]).capitalize()
            primary_name = parallel_domains[0]["name"] if parallel_domains else "General Software"

            project_objective = f"Deconstruct, implement, and verify the computational principles of {clean_prompt}."
            intended_deliverable = f"A verified {execution_env.replace('browser_', '')} module with modular algorithmic components and rigorous test assertions for {title_clean}."

            # Dynamic extraction of concepts across parallel domains
            combined_concepts = []
            for d in parallel_domains:
                combined_concepts.extend(d["concepts"][:2])
            if not combined_concepts:
                combined_concepts = [f"Foundations of {title_clean}", "Algorithmic transformation pipeline", "Quantitative boundary checks"]
            key_concepts = combined_concepts

            prerequisites = ["Foundational programming in target runtime", "Core mathematical and computational principles"]
            required_inputs = ["Clean representative test fixtures and boundary test inputs"]
            planned_outputs = ["Validated execution outputs", "Telemetric verification metrics", "Pass/Fail test report"]

            tech_arch = {
                "language": "python" if execution_env == "browser_pyodide" else "javascript_html",
                "runtime": execution_env,
                "entry_file": "main.py" if execution_env == "browser_pyodide" else "index.html",
                "isolation": "client_sandbox",
                "memory_budget_mb": 128,
            }

            # Synthesize 3 concrete milestones with genuine verification checks
            milestones = [
                {
                    "id": "m1",
                    "title": f"Structural Foundations & Invariant Modeling for {title_clean}",
                    "purpose": f"Establish core state schemas and parameter definitions for {title_clean}.",
                    "task": "Define data structures, transformation routines, and input sanitization.",
                    "expected_output": "Validated baseline model state conforming strictly to invariant schemas.",
                    "verification_check": {"type": "property_check", "property": "initialized", "expected": True},
                    "failure_modes": ["Schema mismatch", "Unhandled empty inputs", "Missing parameter validation"],
                    "depends_on": []
                },
                {
                    "id": "m2",
                    "title": f"Operational Transformation & Algorithmic Core",
                    "purpose": "Implement primary computational transformations and boundary handling.",
                    "task": "Implement core mathematical or algorithmic transformation functions.",
                    "expected_output": "Numerical or structural outputs match theoretical invariants within calibrated tolerance.",
                    "verification_check": {"type": "unit_test_suite", "target_test": "test_core.py"},
                    "failure_modes": ["Runtime crash on edge conditions", "Numerical instability or divergence", "Off-by-one boundary errors"],
                    "depends_on": ["m1"]
                },
                {
                    "id": "m3",
                    "title": "Comprehensive Verification & Invariant Audit",
                    "purpose": "Verify asymptotic scaling, convergence, or conservation laws under stress fixtures.",
                    "task": "Execute comprehensive automated verification suite across boundary and randomized cases.",
                    "expected_output": "All verification assertions pass with zero invariant violations.",
                    "verification_check": {"type": "unit_test_suite", "target_test": "test_verification.py"},
                    "failure_modes": ["Convergence failure under noisy fixtures", "Asymptotic complexity explosion"],
                    "depends_on": ["m2"]
                }
            ]

            verification_strategy = f"Multi-tiered evaluation combining property checks, unit test assertions, and boundary telemetry for {primary_name}."
            expected_failure_modes = ["Boundary overflow or numerical drift", "Unbounded asymptotic scaling", "Specification divergence"]
            known_limitations = [
                f"Scoped for educational clarity; does not encompass all industrial edge cases of {title_clean}.",
                "Execution bound by client-side browser sandbox limits."
            ]
            external_info_reqs = [
                f"Authoritative technical specifications or scholarly literature on {title_clean}",
                f"Standard test benchmarks and known reference outputs for {title_clean}"
            ]
            provenance["external_retrieval_requirements"] = external_info_reqs
            provenance["unverified_limitations"] = known_limitations
            completion_criteria = [
                "Core functions execute without unhandled exceptions",
                "All milestone unit test assertions pass successfully",
                "Boundary invariants satisfied within calibrated tolerance"
            ]

        # Milestone Dependency Mapping
        milestone_deps = {m["id"]: m.get("depends_on", []) for m in milestones}

        blueprint = {
            "blueprint_id": blueprint_id,
            "provenance": provenance,
            # 20 Canonical Blueprint Fields:
            "project_objective": project_objective,
            "intended_deliverable": intended_deliverable,
            "domains": parallel_domains,
            "domain_roles": domain_roles,  # Backwards compatibility projection
            "central_question": f"How can we rigorously implement and verify {clean_prompt} from foundational principles?",
            "key_concepts": key_concepts,
            "prerequisites": prerequisites,
            "assumptions": provenance["working_assumptions"],
            "required_inputs_resources": required_inputs,
            "planned_outputs": planned_outputs,
            "technical_architecture": tech_arch,
            "milestones": milestones,
            "milestone_dependencies": milestone_deps,
            "learning_objectives": [
                f"Understand theoretical mechanisms of {parallel_domains[0]['name'] if parallel_domains else 'the domain'}",
                "Translate formal formulas into clean executable code",
                "Validate implementation against quantitative boundary invariants"
            ],
            "implementation_strategy": "Progressive milestone scaffolding: from core mathematical formulas to iterative loops and telemetry.",
            "verification_strategy": verification_strategy,
            "expected_failure_modes": expected_failure_modes,
            "known_limitations": known_limitations,
            "external_info_requirements": external_info_reqs,
            "required_tools": [tech_arch["runtime"]],
            "completion_criteria": completion_criteria,
            # Operational Metadata
            "difficulty_level": difficulty,
            "persona": persona,
            "is_curated": is_curated,
            "clarification_state": {
                "unresolved_ambiguities_count": len(provenance.get("clarification_requirements", [])),
                "resolved_clarifications": resolved_dict,
                "is_fully_clarified": len(provenance.get("clarification_requirements", [])) == 0,
            },
        }

        if custom_inputs and isinstance(custom_inputs, dict):
            for k, v in custom_inputs.items():
                if k in blueprint:
                    blueprint[k] = v

        return blueprint

    @classmethod
    def validate_blueprint(cls, blueprint: Dict[str, Any]) -> BlueprintValidationResult:
        """
        Rigorously validates a Blueprint for internal consistency, completeness,
        DAG dependency validity, parallel domain structure, and feasibility constraints.
        """
        errors: List[str] = []
        warnings: List[str] = []

        if not isinstance(blueprint, dict):
            return BlueprintValidationResult(False, ["Blueprint must be a dictionary object."], warnings)

        # 1. Check Canonical Required Fields (all 20 + provenance)
        required_fields = [
            "blueprint_id", "project_objective", "intended_deliverable", "domain_roles",
            "central_question", "key_concepts", "prerequisites", "assumptions",
            "required_inputs_resources", "planned_outputs", "technical_architecture",
            "milestones", "milestone_dependencies", "learning_objectives",
            "implementation_strategy", "verification_strategy", "expected_failure_modes",
            "known_limitations", "external_info_requirements", "required_tools",
            "completion_criteria", "provenance"
        ]

        for field in required_fields:
            if field not in blueprint or blueprint[field] is None:
                errors.append(f"Missing required blueprint field: '{field}'")

        if errors:
            return BlueprintValidationResult(False, errors, warnings, blueprint)

        # 2. Check Objective & Deliverable Substance
        if len(blueprint["project_objective"].strip()) < 10:
            errors.append("Field 'project_objective' is too brief or insubstantial.")
        if len(blueprint["intended_deliverable"].strip()) < 10:
            errors.append("Field 'intended_deliverable' must specify concrete deliverable artifacts.")

        # 3. Check Domain Roles & Parallel Domains
        roles = blueprint.get("domain_roles", {})
        if not isinstance(roles, dict) or "primary" not in roles:
            errors.append("Field 'domain_roles' must specify at least a 'primary' domain.")

        domains = blueprint.get("domains", [])
        if not isinstance(domains, list) or len(domains) == 0:
            # If parallel domains missing, record warning or derive
            warnings.append("Blueprint does not declare explicit parallel 'domains' list.")
        else:
            for idx, d in enumerate(domains):
                if not isinstance(d, dict) or not d.get("id") or not d.get("name"):
                    errors.append(f"Parallel domain at index {idx} missing valid 'id' or 'name'.")

        # 4. Check Milestones and Dependency DAG
        milestones = blueprint.get("milestones", [])
        if not isinstance(milestones, list) or len(milestones) == 0:
            errors.append("Blueprint must define at least one milestone.")
        else:
            milestone_ids = set()
            for idx, m in enumerate(milestones):
                if not isinstance(m, dict):
                    errors.append(f"Milestone at index {idx} must be a dictionary.")
                    continue
                m_id = m.get("id")
                if not m_id or not isinstance(m_id, str):
                    errors.append(f"Milestone at index {idx} is missing a valid 'id'.")
                elif m_id in milestone_ids:
                    errors.append(f"Duplicate milestone id '{m_id}' detected.")
                else:
                    milestone_ids.add(m_id)

                if not m.get("title"):
                    errors.append(f"Milestone '{m_id}' missing required 'title'.")
                if not m.get("purpose"):
                    errors.append(f"Milestone '{m_id}' missing required 'purpose'.")

            # Check Dependency Ordering & Circular Dependencies
            deps = blueprint.get("milestone_dependencies", {})
            for m_id, m_deps in deps.items():
                if m_id not in milestone_ids:
                    errors.append(f"Dependency mapping references nonexistent milestone '{m_id}'.")
                for dep in m_deps:
                    if dep not in milestone_ids:
                        errors.append(f"Milestone '{m_id}' depends on undefined milestone '{dep}'.")
                    if dep == m_id:
                        errors.append(f"Self-referential dependency detected in milestone '{m_id}'.")

            # Cycle Detection via Topological Sort / DFS
            if not errors:
                visited: Dict[str, int] = {}  # 0: unvisited, 1: visiting, 2: visited
                has_cycle = False
                cycle_node = ""

                def dfs(node: str) -> bool:
                    nonlocal has_cycle, cycle_node
                    visited[node] = 1
                    for neighbor in deps.get(node, []):
                        if visited.get(neighbor) == 1:
                            has_cycle = True
                            cycle_node = neighbor
                            return True
                        if visited.get(neighbor, 0) == 0:
                            if dfs(neighbor):
                                return True
                    visited[node] = 2
                    return False

                for m_id in milestone_ids:
                    if visited.get(m_id, 0) == 0:
                        if dfs(m_id):
                            break

                if has_cycle:
                    errors.append(f"Circular milestone dependency detected involving milestone '{cycle_node}'.")

        # 5. Check Technical Architecture Feasibility
        arch = blueprint.get("technical_architecture", {})
        if not isinstance(arch, dict):
            errors.append("Field 'technical_architecture' must be a dictionary.")
        else:
            runtime = arch.get("runtime", "")
            if runtime not in ("browser_pyodide", "browser_iframe", "isolated_subprocess"):
                errors.append(f"Unsupported runtime '{runtime}'. Allowed: 'browser_pyodide', 'browser_iframe', 'isolated_subprocess'.")

        # 6. Check Provenance & Truthfulness
        prov = blueprint.get("provenance", {})
        if not isinstance(prov, dict):
            errors.append("Field 'provenance' must be a structured dictionary.")
        else:
            if "learner_supplied" not in prov:
                errors.append("Provenance missing 'learner_supplied' bucket.")
            if "system_inferred" not in prov:
                errors.append("Provenance missing 'system_inferred' bucket.")
            if "working_assumptions" not in prov:
                errors.append("Provenance missing 'working_assumptions' bucket.")

        # 7. Unverified Checks Notice
        for m in blueprint.get("milestones", []):
            if isinstance(m, dict) and m.get("verification_check", {}).get("type") == "unverified_placeholder":
                warnings.append(f"Milestone '{m.get('id')}' uses unverified_placeholder check; requires active domain verification.")

        is_valid = len(errors) == 0
        return BlueprintValidationResult(is_valid, errors, warnings, blueprint)


# =====================================================================
# 6. Downstream System Interfaces (Explicit Contracts)
# =====================================================================

class KnowledgeRetrievalContract:
    """
    Contract interface for sending blueprint information requirements to the
    KnowledgeRetrievalSystem and receiving grounded evidence.
    """
    @staticmethod
    def extract_retrieval_query_spec(blueprint: Dict[str, Any]) -> Dict[str, Any]:
        """Extracts structured search requirements from blueprint."""
        return {
            "blueprint_id": blueprint.get("blueprint_id"),
            "primary_domain": blueprint.get("domain_roles", {}).get("primary"),
            "domains": [d.get("id") for d in blueprint.get("domains", [])],
            "central_question": blueprint.get("central_question"),
            "required_information": blueprint.get("external_info_requirements", []),
            "key_concepts": blueprint.get("key_concepts", []),
        }

    @staticmethod
    def validate_evidence_payload(payload: Dict[str, Any]) -> Tuple[bool, List[str]]:
        """Validates that retrieved evidence conforms to citation integrity."""
        errors = []
        if not isinstance(payload, dict):
            return False, ["Evidence payload must be a dictionary."]
        for src in payload.get("sources", []):
            if not src.get("title"):
                errors.append("Retrieved source missing title.")
            # Accept provenance_type or source_type
            if not src.get("provenance_type") and not src.get("source_type"):
                errors.append(f"Source '{src.get('title')}' missing provenance_type classification.")
            # Accept excerpt or snippet
            if not src.get("excerpt") and not src.get("snippet"):
                errors.append(f"Source '{src.get('title')}' missing factual excerpt.")
        return len(errors) == 0, errors


class ArtifactGenerationContract:
    """
    Contract interface for passing a validated blueprint into the Project Generation Pipeline.
    """
    @staticmethod
    def build_generation_spec(blueprint: Dict[str, Any], retrieved_evidence: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        return {
            "blueprint_id": blueprint.get("blueprint_id"),
            "title": blueprint.get("intended_deliverable", "").split(".")[0],
            "language": blueprint.get("technical_architecture", {}).get("language"),
            "runtime": blueprint.get("technical_architecture", {}).get("runtime"),
            "domains": blueprint.get("domains", []),
            "milestones": blueprint.get("milestones", []),
            "prerequisites": blueprint.get("prerequisites", []),
            "assumptions": blueprint.get("assumptions", []),
            "grounding_evidence": retrieved_evidence or {},
        }


class VerificationSpecContract:
    """
    Contract interface for passing milestone verification criteria to the Verification Engine.
    """
    @staticmethod
    def extract_milestone_verification_specs(blueprint: Dict[str, Any], milestone_id: str) -> Optional[Dict[str, Any]]:
        for m in blueprint.get("milestones", []):
            if m.get("id") == milestone_id:
                check = m.get("verification_check", {})
                return {
                    "milestone_id": milestone_id,
                    "check_spec": check,
                    "expected_failure_modes": m.get("failure_modes", []),
                }
        return None


class TutorContextContract:
    """
    Contract interface for providing the Socratic AI Tutor with authoritative project blueprint context.
    """
    @staticmethod
    def get_grounded_tutor_context(blueprint: Dict[str, Any], active_milestone_id: str) -> Dict[str, Any]:
        active_m = next((m for m in blueprint.get("milestones", []) if m.get("id") == active_milestone_id), None)
        return {
            "blueprint_id": blueprint.get("blueprint_id"),
            "project_objective": blueprint.get("project_objective"),
            "primary_domain": blueprint.get("domain_roles", {}).get("primary"),
            "domains": blueprint.get("domains", []),
            "central_question": blueprint.get("central_question"),
            "active_milestone": active_m,
            "working_assumptions": blueprint.get("assumptions", []),
            "known_limitations": blueprint.get("known_limitations", []),
        }
