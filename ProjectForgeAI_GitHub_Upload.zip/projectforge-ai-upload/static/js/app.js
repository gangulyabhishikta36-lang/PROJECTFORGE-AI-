/**
 * app.js
 * ======
 * Main application coordinator for ProjectForge AI.
 * Implements the Dual-Mode Learning Workspace:
 *   1. Guided Learning (Concept Explorer, 5-question briefs, contextual guidance, plain-English results)
 *   2. Developer Workspace (Multi-file editor, technical TODO notes, multi-tab console, Socratic co-pilot)
 * Both modes share the same underlying project state, code buffers, and execution sandboxes.
 */

document.addEventListener('DOMContentLoaded', async () => {
  const api = window.apiClient;
  const sandbox = window.sandboxRunner;
  const adaptive = new window.AdaptiveController(api, sandbox);

  // Application State
  let currentProject = null;
  let activeFileIndex = 0;
  let activePersona = 'student';
  let currentMode = localStorage.getItem('projectforge_preferred_mode') || 'guided';
  let activeGuidedView = 'overview'; // 'overview' | 'milestone'

  // DOM Elements - Navigation & Modes
  const headerModeSwitcher = document.getElementById('header-mode-switcher');
  const btnModeGuided = document.getElementById('btn-mode-guided');
  const btnModeDev = document.getElementById('btn-mode-dev');
  const modalModeSelect = document.getElementById('modal-mode-select');
  const modalSelectGuided = document.getElementById('modal-select-guided');
  const modalSelectDev = document.getElementById('modal-select-dev');
  const modalChkRemember = document.getElementById('modal-chk-remember');
  const modalBtnDismiss = document.getElementById('modal-btn-dismiss');

  // Views
  const viewStudio = document.getElementById('view-studio');
  const viewWorkspace = document.getElementById('view-workspace');
  const workspaceGuidedView = document.getElementById('workspace-guided-view');
  const workspaceDevView = document.getElementById('workspace-dev-view');

  // Header Elements
  const providerBadge = document.getElementById('provider-badge');
  const providerText = document.getElementById('provider-text');
  const btnPersonaStudent = document.getElementById('btn-persona-student');
  const btnPersonaEducator = document.getElementById('btn-persona-educator');
  const btnSwitchStudio = document.getElementById('btn-switch-studio');
  const btnExportProject = document.getElementById('btn-export-project');

  // Studio Elements
  const inputPrompt = document.getElementById('input-prompt');
  const templateChips = document.getElementById('template-chips');
  const sliderDifficulty = document.getElementById('slider-difficulty');
  const labelDiffNum = document.getElementById('label-diff-num');
  const labelDiffTier = document.getElementById('label-diff-tier');
  const metricConceptual = document.getElementById('metric-conceptual');
  const metricImplementation = document.getElementById('metric-implementation');
  const metricPrereq = document.getElementById('metric-prereq');
  const metricIndependence = document.getElementById('metric-independence');
  const metricScaffold = document.getElementById('metric-scaffold');
  const metricMilestones = document.getElementById('metric-milestones');
  const metricTolerance = document.getElementById('metric-tolerance');
  const btnGenerate = document.getElementById('btn-generate-project');
  const clarificationBanner = document.getElementById('clarification-banner');
  const clarificationMsg = document.getElementById('clarification-msg');
  const clarificationQuestions = document.getElementById('clarification-questions');

  // Guided Mode Elements
  const guidedProjectTitle = document.getElementById('guided-project-title');
  const guidedProjectDomain = document.getElementById('guided-project-domain');
  const btnSaveProjectGuided = document.getElementById('btn-save-project-guided');
  const guidedStepperContainer = document.getElementById('guided-stepper-container');
  const btnGuidedRemediation = document.getElementById('btn-guided-remediation');
  const btnGuidedStretch = document.getElementById('btn-guided-stretch');
  const guidedTutorForm = document.getElementById('guided-tutor-form');
  const guidedTutorInput = document.getElementById('guided-tutor-input');
  const guidedTutorRecentMsg = document.getElementById('guided-tutor-recent-msg');

  // Guided Overview Panel Elements
  const guidedOverviewPanel = document.getElementById('guided-overview-panel');
  const guidedOverviewTitle = document.getElementById('guided-overview-title');
  const guidedOverviewDesc = document.getElementById('guided-overview-desc');
  const guidedOverviewDiffBadge = document.getElementById('guided-overview-difficulty-badge');
  const guidedOverviewBuilding = document.getElementById('guided-overview-building');
  const guidedOverviewMatters = document.getElementById('guided-overview-matters');
  const guidedOverviewLearn = document.getElementById('guided-overview-learn');
  const guidedOverviewBuild = document.getElementById('guided-overview-build');
  const guidedPrereqEssential = document.getElementById('guided-prereq-essential');
  const guidedPrereqHelpful = document.getElementById('guided-prereq-helpful');
  const guidedPrereqTaught = document.getElementById('guided-prereq-taught');
  const btnGuidedStartM1 = document.getElementById('btn-guided-start-m1');

  // Guided Active Milestone Panel Elements
  const guidedActivePanel = document.getElementById('guided-active-panel');
  const guidedStepBadge = document.getElementById('guided-step-badge');
  const guidedActiveTitle = document.getElementById('guided-active-title');
  const guidedActiveObj = document.getElementById('guided-active-obj');
  const guidedMilestoneStatusBadge = document.getElementById('guided-milestone-status-badge');
  const briefGoal = document.getElementById('brief-goal');
  const briefWhy = document.getElementById('brief-why');
  const briefConcepts = document.getElementById('brief-concepts');
  const briefInstructions = document.getElementById('brief-instructions');
  const briefSuccess = document.getElementById('brief-success');
  const conceptLayersContainer = document.getElementById('concept-layers-container');
  const guidedCodeContextList = document.getElementById('guided-code-context-list');
  const guidedEditorFilename = document.getElementById('guided-editor-filename');
  const codeEditorGuided = document.getElementById('code-editor-guided');
  const btnGuidedRunSandbox = document.getElementById('btn-guided-run-sandbox');
  const guidedExecTimer = document.getElementById('guided-exec-timer');
  const guidedOutputInterpreted = document.getElementById('guided-output-interpreted');
  const guidedRawOutput = document.getElementById('guided-raw-output');
  const btnGuidedVerify = document.getElementById('btn-guided-verify');
  const guidedStatusL1 = document.getElementById('guided-status-l1');
  const guidedStatusL2 = document.getElementById('guided-status-l2');
  const guidedStatusL3 = document.getElementById('guided-status-l3');
  const guidedVerificationDiag = document.getElementById('guided-verification-diag');
  const guidedLayer3Card = document.getElementById('guided-layer3-card');
  const guidedLayer3Prompt = document.getElementById('guided-layer3-prompt');
  const guidedLayer3Input = document.getElementById('guided-layer3-input');
  const btnGuidedSubmitLayer3 = document.getElementById('btn-guided-submit-layer3');

  // Developer Workspace Elements
  const wsProjectTitle = document.getElementById('ws-project-title');
  const wsProjectDomain = document.getElementById('ws-project-domain');
  const btnSaveProject = document.getElementById('btn-save-project');
  const milestonesContainer = document.getElementById('milestones-container');
  const devTodoList = document.getElementById('dev-todo-list');
  const devTodoCount = document.getElementById('dev-todo-count');
  const activeMilestoneTitle = document.getElementById('active-milestone-title');
  const activeMilestoneObj = document.getElementById('active-milestone-obj');
  const activeMilestoneTasks = document.getElementById('active-milestone-tasks');
  const btnRunVerification = document.getElementById('btn-run-verification');
  const verificationBadge = document.getElementById('verification-badge');
  const statusL1 = document.getElementById('status-l1');
  const statusL2 = document.getElementById('status-l2');
  const statusL3 = document.getElementById('status-l3');
  const verificationDiag = document.getElementById('verification-diag');
  const adaptationCard = document.getElementById('adaptation-card');
  const btnRequestRemediation = document.getElementById('btn-request-remediation');
  const btnRequestStretch = document.getElementById('btn-request-stretch');
  const layer3Card = document.getElementById('layer3-card');
  const layer3Prompt = document.getElementById('layer3-prompt');
  const layer3Input = document.getElementById('layer3-input');
  const btnSubmitLayer3 = document.getElementById('btn-submit-layer3');

  // Dev Editor & Console Elements
  const editorTabs = document.getElementById('editor-tabs');
  const codeEditorDev = document.getElementById('code-editor');
  const btnRunSandbox = document.getElementById('btn-run-sandbox');
  const tabBtnConsole = document.getElementById('tab-btn-console');
  const tabBtnPreview = document.getElementById('tab-btn-preview');
  const tabBtnTests = document.getElementById('tab-btn-tests');
  const tabBtnInquiries = document.getElementById('tab-btn-inquiries');
  const consoleView = document.getElementById('console-view');
  const previewContainer = document.getElementById('preview-container');
  const testsView = document.getElementById('tests-view');
  const inquiriesView = document.getElementById('inquiries-view');
  const execTimer = document.getElementById('exec-timer');

  // Dev Tutor Elements
  const tutorChatMessages = document.getElementById('tutor-chat-messages');
  const selectHintTier = document.getElementById('select-hint-tier');
  const tutorForm = document.getElementById('tutor-form');
  const tutorInput = document.getElementById('tutor-input');

  // -------------------------------------------------------------
  // 1. Initialization: Config, Templates, Math Renderer
  // -------------------------------------------------------------
  try {
    const configResp = await api.getConfig();
    const cfg = configResp.config;
    if (cfg.is_cloud_configured) {
      providerText.textContent = `Cloud: ${cfg.active_provider.toUpperCase()}`;
      providerBadge.querySelector('span').className = 'w-2 h-2 rounded-full bg-emerald-400';
    } else {
      providerText.textContent = 'Mode: Offline Heuristic';
      providerBadge.querySelector('span').className = 'w-2 h-2 rounded-full bg-cyan-400';
    }
  } catch (e) {
    providerText.textContent = 'Server Disconnected';
    providerBadge.querySelector('span').className = 'w-2 h-2 rounded-full bg-rose-500';
  }

  try {
    const tplResp = await api.getTemplates();
    templateChips.innerHTML = '';
    (tplResp.templates || []).forEach(tpl => {
      const chip = document.createElement('button');
      chip.className = 'px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs border border-slate-700/80 transition flex items-center space-x-1.5';
      chip.innerHTML = `<i class="fa-solid fa-code text-[10px] text-cyan-400"></i><span>${tpl.title}</span>`;
      chip.onclick = () => {
        inputPrompt.value = tpl.prompt;
        sliderDifficulty.value = tpl.difficulty_range ? tpl.difficulty_range[0] : 5;
        updateDifficultyDisplay();
      };
      templateChips.appendChild(chip);
    });
  } catch (_) {}

  function renderMathIfAvailable(element) {
    if (window.renderMathInElement && element) {
      try {
        window.renderMathInElement(element, {
          delimiters: [
            { left: '$$', right: '$$', display: true },
            { left: '$', right: '$', display: false },
            { left: '\\[', right: '\\]', display: true },
            { left: '\\(', right: '\\)', display: false }
          ],
          throwOnError: false
        });
      } catch (_) {}
    }
  }

  // -------------------------------------------------------------
  // 2. 4D Difficulty Slider Calibration
  // -------------------------------------------------------------
  const tierLabels = {
    1: 'Foundations', 2: 'Introductory', 3: 'Apprentice', 4: 'Developing',
    5: 'Moderate', 6: 'Applied', 7: 'Advanced', 8: 'Rigorous',
    9: 'Production', 10: 'Mastery'
  };

  function updateDifficultyDisplay() {
    const d = parseInt(sliderDifficulty.value, 10);
    labelDiffNum.textContent = d;
    labelDiffTier.textContent = tierLabels[d] || 'Moderate';

    const conceptual = d;
    const implementation = Math.min(10, Math.max(1, Math.round(d * 0.95)));
    const prereq = Math.max(1, Math.round((d - 1) * 0.9 + 1));
    const independence = d;

    metricConceptual.textContent = `Level ${conceptual} / 10`;
    metricImplementation.textContent = `Level ${implementation} / 10`;
    metricPrereq.textContent = `Level ${prereq} / 10`;
    metricIndependence.textContent = `Level ${independence} / 10`;

    const scaffoldRatio = Math.max(5, Math.min(85, Math.round(95 - (independence * 5.5 + implementation * 3.5))));
    const milestones = independence <= 3 ? 3 : independence <= 7 ? 4 : 5;
    const tolerance = Math.max(0.0005, 0.05 * (1.1 - (conceptual / 10.0)));

    metricScaffold.textContent = `${scaffoldRatio}%`;
    metricMilestones.textContent = `${milestones} Steps`;
    metricTolerance.textContent = `±${tolerance.toFixed(4)}`;
  }

  sliderDifficulty.addEventListener('input', updateDifficultyDisplay);
  updateDifficultyDisplay();

  // Persona Toggle
  btnPersonaStudent.addEventListener('click', () => {
    activePersona = 'student';
    btnPersonaStudent.className = 'px-2.5 py-1 rounded-md bg-indigo-600 text-white font-medium transition';
    btnPersonaEducator.className = 'px-2.5 py-1 rounded-md text-slate-400 hover:text-white transition';
  });

  btnPersonaEducator.addEventListener('click', () => {
    activePersona = 'educator';
    btnPersonaEducator.className = 'px-2.5 py-1 rounded-md bg-indigo-600 text-white font-medium transition';
    btnPersonaStudent.className = 'px-2.5 py-1 rounded-md text-slate-400 hover:text-white transition';
  });

  // Switch between Studio and Workspace
  btnSwitchStudio.addEventListener('click', () => {
    saveCurrentEditorContent();
    viewWorkspace.classList.add('hidden');
    headerModeSwitcher.classList.add('hidden');
    headerModeSwitcher.classList.remove('flex');
    viewStudio.classList.remove('hidden');
  });

  // -------------------------------------------------------------
  // 3. Project Generation & Mode Selection Modal
  // -------------------------------------------------------------
  btnGenerate.addEventListener('click', async () => {
    const prompt = inputPrompt.value.trim();
    if (prompt.length < 3) {
      alert('Please enter a learning objective or prompt (at least 3 characters).');
      return;
    }

    clarificationBanner.classList.add('hidden');
    btnGenerate.disabled = true;
    btnGenerate.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i><span>Architecting Project...</span>';

    try {
      const resp = await api.generateProject({
        prompt: prompt,
        difficulty: parseInt(sliderDifficulty.value, 10),
        persona: activePersona,
        domain: 'auto'
      });

      if (resp.status === 'needs_clarification') {
        const c = resp.clarification;
        clarificationMsg.textContent = c.explanation;
        clarificationQuestions.innerHTML = '';
        (c.clarifying_questions || []).forEach(q => {
          const item = document.createElement('div');
          item.className = 'flex items-center space-x-1.5';
          item.innerHTML = `<i class="fa-solid fa-circle-question text-amber-400 text-[10px]"></i><span>${q}</span>`;
          clarificationQuestions.appendChild(item);
        });
        clarificationBanner.classList.remove('hidden');
        clarificationBanner.scrollIntoView({ behavior: 'smooth' });
        return;
      }

      if (resp.status === 'unsupported_offline') {
        clarificationMsg.textContent = resp.message || 'Topic generation is unavailable in offline mode.';
        clarificationQuestions.innerHTML = '';
        if (resp.limitations && resp.limitations.length) {
          resp.limitations.forEach(lim => {
            const item = document.createElement('div');
            item.className = 'flex items-start space-x-1.5 text-slate-300';
            item.innerHTML = `<i class="fa-solid fa-circle-exclamation text-amber-400 text-[10px] mt-0.5"></i><span>${lim}</span>`;
            clarificationQuestions.appendChild(item);
          });
        }
        if (resp.suggested_curated_topics && resp.suggested_curated_topics.length) {
          const sugHeader = document.createElement('div');
          sugHeader.className = 'pt-2 font-medium text-amber-300 text-xs';
          sugHeader.textContent = 'Verified Curated Alternatives:';
          clarificationQuestions.appendChild(sugHeader);
          resp.suggested_curated_topics.forEach(sug => {
            const btn = document.createElement('button');
            btn.className = 'mt-1 mr-2 px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-cyan-300 text-xs border border-slate-700 transition inline-flex items-center space-x-1';
            btn.innerHTML = `<i class="fa-solid fa-arrow-right text-[10px]"></i><span>${sug.title}</span>`;
            btn.onclick = () => {
              inputPrompt.value = sug.prompt;
              btnGenerate.click();
            };
            clarificationQuestions.appendChild(btn);
          });
        }
        clarificationBanner.classList.remove('hidden');
        clarificationBanner.scrollIntoView({ behavior: 'smooth' });
        return;
      }

      // Check if user has a remembered mode preference
      const remembered = localStorage.getItem('projectforge_dont_ask_mode') === 'true';
      const savedMode = localStorage.getItem('projectforge_preferred_mode');

      currentProject = resp.project;

      if (remembered && savedMode) {
        currentMode = savedMode;
        loadProjectIntoWorkspace(resp.project);
      } else {
        // Show Mode Selection Modal
        modalModeSelect.classList.remove('hidden');
      }

    } catch (err) {
      alert(`Generation Failed: ${err.message || 'Unknown error'}`);
    } finally {
      btnGenerate.disabled = false;
      btnGenerate.innerHTML = '<i class="fa-solid fa-sparkles"></i><span>Generate Project Workspace</span>';
    }
  });

  // Modal handlers
  modalSelectGuided.onclick = () => {
    handleModeChoice('guided');
  };

  modalSelectDev.onclick = () => {
    handleModeChoice('developer');
  };

  modalBtnDismiss.onclick = () => {
    modalModeSelect.classList.add('hidden');
    loadProjectIntoWorkspace(currentProject);
  };

  function handleModeChoice(selectedMode) {
    if (modalChkRemember.checked) {
      localStorage.setItem('projectforge_dont_ask_mode', 'true');
    }
    currentMode = selectedMode;
    localStorage.setItem('projectforge_preferred_mode', selectedMode);
    modalModeSelect.classList.add('hidden');
    loadProjectIntoWorkspace(currentProject);
  }

  // Top Bar Mode Switch Buttons
  btnModeGuided.addEventListener('click', () => {
    if (currentMode !== 'guided') {
      switchWorkspaceMode('guided');
    }
  });

  btnModeDev.addEventListener('click', () => {
    if (currentMode !== 'developer') {
      switchWorkspaceMode('developer');
    }
  });

  function switchWorkspaceMode(newMode) {
    saveCurrentEditorContent();
    currentMode = newMode;
    localStorage.setItem('projectforge_preferred_mode', newMode);
    updateModeSwitcherUI();
    renderCurrentWorkspace();
    loadActiveFileContent();
  }

  function updateModeSwitcherUI() {
    if (currentMode === 'guided') {
      btnModeGuided.className = 'px-3 py-1 rounded-lg text-xs font-semibold transition flex items-center space-x-1.5 bg-indigo-600 text-white shadow-sm';
      btnModeDev.className = 'px-3 py-1 rounded-lg text-xs font-semibold text-slate-400 hover:text-white transition flex items-center space-x-1.5';
    } else {
      btnModeDev.className = 'px-3 py-1 rounded-lg text-xs font-semibold transition flex items-center space-x-1.5 bg-cyan-600 text-white shadow-sm';
      btnModeGuided.className = 'px-3 py-1 rounded-lg text-xs font-semibold text-slate-400 hover:text-white transition flex items-center space-x-1.5';
    }
  }

  // -------------------------------------------------------------
  // 4. Workspace Management & State Synchronization
  // -------------------------------------------------------------
  function loadProjectIntoWorkspace(project) {
    currentProject = project;
    activeFileIndex = 0;
    activeGuidedView = 'overview';
    adaptive.initProject(project);

    // Update Header
    headerModeSwitcher.classList.remove('hidden');
    headerModeSwitcher.classList.add('flex');
    btnExportProject.disabled = false;

    // Synchronize mode UI
    updateModeSwitcherUI();

    // Switch views
    viewStudio.classList.add('hidden');
    viewWorkspace.classList.remove('hidden');

    // Render active workspace
    renderCurrentWorkspace();
    loadActiveFileContent();

    appendTutorMessage('tutor', `I have initialized the workspace for **${project.title}**! You can toggle between **Guided Learning** and **Developer Workspace** at any time using the switcher at the top.`);
  }

  function renderCurrentWorkspace() {
    if (!currentProject) return;

    if (currentMode === 'guided') {
      workspaceDevView.classList.add('hidden');
      workspaceGuidedView.classList.remove('hidden');
      renderGuidedView();
    } else {
      workspaceGuidedView.classList.add('hidden');
      workspaceDevView.classList.remove('hidden');
      renderDevView();
    }
  }

  // Single source of truth code synchronization
  function saveCurrentEditorContent() {
    if (!currentProject || !currentProject.files || !currentProject.files[activeFileIndex]) return;

    if (currentMode === 'guided') {
      if (codeEditorGuided) {
        currentProject.files[activeFileIndex].content = codeEditorGuided.value;
        if (codeEditorDev) codeEditorDev.value = codeEditorGuided.value;
      }
    } else {
      if (codeEditorDev) {
        currentProject.files[activeFileIndex].content = codeEditorDev.value;
        if (codeEditorGuided) codeEditorGuided.value = codeEditorDev.value;
      }
    }
  }

  function loadActiveFileContent() {
    if (!currentProject || !currentProject.files || !currentProject.files[activeFileIndex]) return;
    const content = currentProject.files[activeFileIndex].content;
    if (codeEditorDev) codeEditorDev.value = content;
    if (codeEditorGuided) codeEditorGuided.value = content;
    if (guidedEditorFilename) {
      guidedEditorFilename.textContent = currentProject.files[activeFileIndex].name;
    }
  }

  if (codeEditorDev) {
    codeEditorDev.addEventListener('input', () => {
      saveCurrentEditorContent();
    });
  }
  if (codeEditorGuided) {
    codeEditorGuided.addEventListener('input', () => {
      saveCurrentEditorContent();
    });
  }

  // Adaptive controller listener
  adaptive.onChange((state) => {
    if (currentMode === 'guided') {
      renderGuidedStepper(state);
      if (activeGuidedView === 'milestone') {
        renderGuidedActiveMilestone(adaptive.getActiveMilestone(), state);
      }
    } else {
      renderMilestonesList(state);
      renderDevActiveMilestone(adaptive.getActiveMilestone(), state);
    }
  });

  // -------------------------------------------------------------
  // 5. GUIDED LEARNING MODE IMPLEMENTATION
  // -------------------------------------------------------------
  function renderGuidedView() {
    guidedProjectTitle.textContent = currentProject.title;
    guidedProjectDomain.textContent = `Guided Learning | ${currentProject.domain}`;

    const state = adaptive.getState();
    renderGuidedStepper(state);

    if (activeGuidedView === 'overview') {
      guidedOverviewPanel.classList.remove('hidden');
      guidedActivePanel.classList.add('hidden');
      renderGuidedOverviewContent();
    } else {
      guidedOverviewPanel.classList.add('hidden');
      guidedActivePanel.classList.remove('hidden');
      renderGuidedActiveMilestone(adaptive.getActiveMilestone(), state);
    }
  }

  function renderGuidedStepper(state) {
    guidedStepperContainer.innerHTML = '';

    // 1. Overview Nav Item
    const overviewItem = document.createElement('div');
    overviewItem.className = `p-2.5 rounded-lg border text-xs cursor-pointer flex items-center justify-between ${
      activeGuidedView === 'overview' ? 'border-indigo-500 bg-indigo-500/10 text-white font-bold' : 'border-slate-800 bg-slate-950/60 text-slate-300 hover:bg-slate-800/40'
    }`;
    overviewItem.innerHTML = `
      <div class="flex items-center space-x-2">
        <i class="fa-solid fa-book-open text-indigo-400"></i>
        <span>Project Overview</span>
      </div>
      <span class="text-[10px] text-indigo-300 uppercase font-semibold">Intro</span>
    `;
    overviewItem.onclick = () => {
      activeGuidedView = 'overview';
      renderGuidedView();
    };
    guidedStepperContainer.appendChild(overviewItem);

    // 2. Milestone Steppers
    const milestones = currentProject.milestones || [];
    milestones.forEach((m, idx) => {
      const mStatus = state.status[m.id] || {};
      const isActive = (activeGuidedView === 'milestone' && m.id === state.activeMilestoneId);

      const div = document.createElement('div');
      div.className = `p-2.5 rounded-lg border text-xs cursor-pointer flex items-center justify-between ${
        isActive ? 'border-indigo-500 bg-indigo-500/10 text-white' : 'border-slate-800 bg-slate-950/60 text-slate-300 hover:bg-slate-800/40'
      } ${mStatus.locked ? 'opacity-40 pointer-events-none' : ''}`;

      let icon = '<i class="fa-regular fa-circle text-slate-500"></i>';
      if (mStatus.mastered) {
        icon = '<i class="fa-solid fa-crown text-amber-400"></i>';
      } else if (mStatus.l2) {
        icon = '<i class="fa-solid fa-check-double text-cyan-400"></i>';
      } else if (mStatus.l1) {
        icon = '<i class="fa-solid fa-check text-emerald-400"></i>';
      }

      div.innerHTML = `
        <div class="flex items-center space-x-2 truncate">
          <span>${icon}</span>
          <span class="truncate font-medium">${m.title}</span>
        </div>
        <span class="text-[10px] text-slate-500 shrink-0">Step ${idx + 1}</span>
      `;

      div.onclick = () => {
        if (!mStatus.locked) {
          activeGuidedView = 'milestone';
          adaptive.setActiveMilestone(m.id);
          renderGuidedView();
        }
      };

      guidedStepperContainer.appendChild(div);
    });
  }

  function renderGuidedOverviewContent() {
    const p = currentProject;
    const ov = p.overview || {};

    guidedOverviewTitle.textContent = p.title;
    guidedOverviewDesc.textContent = p.description;
    guidedOverviewDiffBadge.textContent = `Level ${p.difficulty_profile.master_difficulty} / 10`;

    guidedOverviewBuilding.textContent = ov.what_building || p.description;
    guidedOverviewMatters.textContent = ov.why_matters || 'Understanding core principles enables adaptive problem solving.';

    // What will you learn?
    guidedOverviewLearn.innerHTML = '';
    const learnList = ov.what_you_will_learn || ov.what_learn || [];
    learnList.forEach(item => {
      const li = document.createElement('li');
      li.className = 'flex items-start space-x-2';
      li.innerHTML = `<i class="fa-solid fa-circle-check text-emerald-400 text-xs mt-0.5"></i><span>${item}</span>`;
      guidedOverviewLearn.appendChild(li);
    });

    // What will you build?
    guidedOverviewBuild.innerHTML = '';
    const buildList = Array.isArray(ov.what_you_will_build) ? ov.what_you_will_build : [ov.what_build || 'Executable model'];
    buildList.forEach(item => {
      const li = document.createElement('li');
      li.className = 'flex items-start space-x-2';
      li.innerHTML = `<i class="fa-solid fa-cube text-amber-400 text-xs mt-0.5"></i><span>${item}</span>`;
      guidedOverviewBuild.appendChild(li);
    });

    // Prerequisites breakdown
    const prereqs = ov.prerequisites || ov.prerequisites_breakdown || {};
    populatePrereqList(guidedPrereqEssential, prereqs.essential || ['Basic programming logic']);
    populatePrereqList(guidedPrereqHelpful, prereqs.helpful || ['Elementary algebra']);
    populatePrereqList(guidedPrereqTaught, prereqs.taught_here || ['Core algorithmic models']);

    btnGuidedStartM1.onclick = () => {
      activeGuidedView = 'milestone';
      if (p.milestones && p.milestones[0]) {
        adaptive.setActiveMilestone(p.milestones[0].id);
      }
      renderGuidedView();
    };
  }

  function populatePrereqList(container, items) {
    container.innerHTML = '';
    items.forEach(it => {
      const li = document.createElement('li');
      li.className = 'flex items-start space-x-1.5';
      li.innerHTML = `<span class="text-slate-500">•</span><span>${it}</span>`;
      container.appendChild(li);
    });
  }

  function renderGuidedActiveMilestone(milestone, state) {
    if (!milestone) return;

    const milestones = currentProject.milestones || [];
    const idx = milestones.findIndex(m => m.id === milestone.id);
    guidedStepBadge.textContent = `Milestone ${idx + 1} of ${milestones.length}`;
    guidedActiveTitle.textContent = milestone.title;
    guidedActiveObj.textContent = milestone.objective;

    const mStatus = state.status[milestone.id] || {};
    if (mStatus.mastered) {
      guidedMilestoneStatusBadge.textContent = 'Mastered';
      guidedMilestoneStatusBadge.className = 'px-3 py-1 rounded-full text-xs font-semibold bg-amber-500/20 text-amber-300 border border-amber-500/30';
    } else if (mStatus.l2) {
      guidedMilestoneStatusBadge.textContent = 'Correctness Verified';
      guidedMilestoneStatusBadge.className = 'px-3 py-1 rounded-full text-xs font-semibold bg-cyan-500/20 text-cyan-300 border border-cyan-500/30';
    } else if (mStatus.l1) {
      guidedMilestoneStatusBadge.textContent = 'Execution Passed';
      guidedMilestoneStatusBadge.className = 'px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30';
    } else {
      guidedMilestoneStatusBadge.textContent = 'In Progress';
      guidedMilestoneStatusBadge.className = 'px-3 py-1 rounded-full text-xs font-semibold bg-slate-800 text-slate-400 border border-slate-700';
    }

    // 1. Task Brief Card (5 Questions)
    const tb = milestone.task_brief || {};
    briefGoal.textContent = tb.goal || milestone.objective;
    briefWhy.textContent = tb.why_matters || 'Completes critical stage in the computational model.';

    briefConcepts.innerHTML = '';
    (tb.concepts || []).forEach(c => {
      const chip = document.createElement('span');
      chip.className = 'px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 text-[11px] font-medium border border-indigo-500/30';
      chip.textContent = c;
      briefConcepts.appendChild(chip);
    });

    briefInstructions.innerHTML = '';
    (tb.instructions || milestone.tasks || []).forEach(inst => {
      const li = document.createElement('li');
      li.textContent = inst;
      briefInstructions.appendChild(li);
    });

    briefSuccess.textContent = tb.success_criteria || 'Pass all mathematical correctness tests and explain core concepts.';

    // 2. 5-Layer Concept Explorer
    conceptLayersContainer.innerHTML = '';
    const layers = milestone.concept_layers || [];
    const layerColors = {
      1: { badge: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/40', icon: 'fa-lightbulb' },
      2: { badge: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40', icon: 'fa-square-root-variable' },
      3: { badge: 'bg-amber-500/20 text-amber-300 border-amber-500/40', icon: 'fa-calculator' },
      4: { badge: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40', icon: 'fa-code-branch' },
      5: { badge: 'bg-purple-500/20 text-purple-300 border-purple-500/40', icon: 'fa-vial-virus' }
    };

    layers.forEach((layer, lIdx) => {
      const col = layerColors[layer.level] || layerColors[1];
      const layerDiv = document.createElement('div');
      layerDiv.className = 'concept-layer';

      // Layer 1 and 2 open by default, others collapsible
      const isOpen = (layer.level <= 2);

      layerDiv.innerHTML = `
        <div class="concept-layer-header" data-layer="${layer.level}">
          <div class="flex items-center space-x-2.5">
            <span class="concept-layer-badge border ${col.badge}">Layer ${layer.level}</span>
            <span class="font-bold text-slate-200 text-xs flex items-center space-x-1.5">
              <i class="fa-solid ${col.icon} text-slate-400 text-[11px]"></i>
              <span>${layer.name}</span>
            </span>
          </div>
          <i class="fa-solid fa-chevron-down text-slate-500 text-xs transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}"></i>
        </div>
        <div class="concept-layer-body ${isOpen ? '' : 'hidden'}">
          <div class="whitespace-pre-wrap">${escapeHtml(layer.content)}</div>
        </div>
      `;

      const header = layerDiv.querySelector('.concept-layer-header');
      const body = layerDiv.querySelector('.concept-layer-body');
      const chevron = layerDiv.querySelector('.fa-chevron-down');

      header.onclick = () => {
        const isHidden = body.classList.toggle('hidden');
        chevron.classList.toggle('rotate-180', !isHidden);
      };

      conceptLayersContainer.appendChild(layerDiv);
    });

    renderMathIfAvailable(conceptLayersContainer);

    // 3. Contextual Code Guidance
    guidedCodeContextList.innerHTML = '';
    const codeContext = milestone.code_context || [];
    codeContext.forEach(ctx => {
      const card = document.createElement('div');
      card.className = 'p-3 rounded-xl bg-slate-950/70 border border-slate-800 space-y-1.5';
      card.innerHTML = `
        <div class="flex items-center justify-between">
          <span class="font-mono font-bold text-cyan-300 text-xs">${ctx.name}()</span>
          <span class="text-[10px] text-slate-500 uppercase">Target Function</span>
        </div>
        <p class="text-[11px] text-slate-300">${ctx.purpose}</p>
        <div class="text-[10px] text-slate-400 space-y-0.5 pt-1 border-t border-slate-800/80">
          <div><span class="text-slate-500">Inputs:</span> ${ctx.inputs}</div>
          <div><span class="text-slate-500">Outputs:</span> ${ctx.outputs}</div>
          <div class="text-indigo-300"><span class="text-slate-500">Math Link:</span> ${ctx.math_link}</div>
        </div>
      `;
      guidedCodeContextList.appendChild(card);
    });

    // 4. Update Verification Progress Indicators
    guidedStatusL1.innerHTML = mStatus.l1 ? '<i class="fa-solid fa-circle-check text-emerald-400"></i>' : '<i class="fa-regular fa-circle text-slate-500"></i>';
    guidedStatusL2.innerHTML = mStatus.l2 ? '<i class="fa-solid fa-circle-check text-cyan-400"></i>' : '<i class="fa-regular fa-circle text-slate-500"></i>';
    guidedStatusL3.innerHTML = mStatus.l3 ? '<i class="fa-solid fa-circle-check text-indigo-400"></i>' : '<i class="fa-regular fa-circle text-slate-500"></i>';

    if (mStatus.l2 && !mStatus.mastered && milestone.layer3_spec) {
      guidedLayer3Prompt.textContent = milestone.layer3_spec.prompt;
      guidedLayer3Card.classList.remove('hidden');
    } else {
      guidedLayer3Card.classList.add('hidden');
    }
  }

  // Guided Run Sandbox Button
  btnGuidedRunSandbox.addEventListener('click', async () => {
    saveCurrentEditorContent();
    btnGuidedRunSandbox.disabled = true;
    btnGuidedRunSandbox.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i><span>Running...</span>';

    guidedOutputInterpreted.innerHTML = '<div class="text-cyan-400">Executing code in WebAssembly sandbox...</div>';

    const isPython = (currentProject.execution_mode === 'browser_pyodide');
    const entryFile = currentProject.files.find(f => f.name.endsWith('.py')) || currentProject.files[0];

    const result = await sandbox.executePython(entryFile ? entryFile.content : '');
    guidedExecTimer.textContent = `${result.durationMs}ms`;

    guidedRawOutput.textContent = result.stdout || result.error || 'No terminal output.';

    if (result.success) {
      // Synthesize plain-English pedagogical interpretation
      let interp = `✓ <strong>Code executed successfully</strong> in ${result.durationMs}ms with exit code 0.<br>`;
      if (result.telemetry && Object.keys(result.telemetry).length > 0) {
        interp += `Model Telemetry captured: ${JSON.stringify(result.telemetry)}.<br>`;
      }
      if (result.stdout.toLowerCase().includes('loss')) {
        interp += `Your optimization training loop ran and tracked loss changes. Notice how loss decreases over successive iterations!`;
      } else {
        interp += `Your functions ran without syntax or runtime exceptions. Click <strong>Check My Work</strong> below to run formal mathematical tests.`;
      }
      guidedOutputInterpreted.innerHTML = `<div class="text-emerald-300 leading-relaxed">${interp}</div>`;
    } else {
      guidedOutputInterpreted.innerHTML = `
        <div class="text-rose-300 leading-relaxed">
          <strong>Runtime Issue Encountered:</strong><br>
          ${escapeHtml(result.error)}<br>
          <span class="text-slate-400 text-[11px] mt-1 block">Check the syntax and function names matching the active milestone requirements.</span>
        </div>
      `;
    }

    btnGuidedRunSandbox.disabled = false;
    btnGuidedRunSandbox.innerHTML = '<i class="fa-solid fa-play"></i><span>Run Code</span>';
  });

  // Guided Verify Button
  btnGuidedVerify.addEventListener('click', async () => {
    saveCurrentEditorContent();
    btnGuidedVerify.disabled = true;
    btnGuidedVerify.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i><span>Checking...</span>';
    guidedVerificationDiag.classList.add('hidden');

    try {
      const outcome = await adaptive.runVerification(currentProject.files);

      if (outcome.step === 'layer1_failed') {
        guidedVerificationDiag.innerHTML = `<span class="text-rose-400 font-semibold">Execution Check Failed:</span> ${escapeHtml(outcome.error)}`;
        guidedVerificationDiag.classList.remove('hidden');
        appendTutorMessage('tutor', `Your code encountered a runtime error: \`${outcome.error}\`. Check the instructions or ask for a hint!`);
      } else if (outcome.step === 'layer2_failed') {
        const v = outcome.verification;
        let checksSummary = (v.checks || []).map(c => `• ${c.name}: ${c.passed ? '✓ Passed' : '✗ Discrepancy (' + c.diagnostic + ')'}`).join('<br>');
        guidedVerificationDiag.innerHTML = `<span class="text-amber-400 font-semibold">Mathematical Discrepancy:</span><br>${checksSummary}`;
        guidedVerificationDiag.classList.remove('hidden');

        let msg = `Layer 2 detected a mathematical check failure: ${v.diagnostics}. Review your formulas in the Concept Explorer!`;
        if (outcome.offerRemediation) {
          msg += "\n\nTip: You can click **Bridge Task** in the sidebar to work through an easier subproblem first!";
        }
        appendTutorMessage('tutor', msg);
      } else if (outcome.step === 'layer2_passed') {
        guidedVerificationDiag.innerHTML = `<span class="text-emerald-400 font-semibold">Layer 2 Rigor Passed!</span> All numerical predictions match reference tolerances. Answer the Conceptual Probe below to complete mastery.`;
        guidedVerificationDiag.classList.remove('hidden');
        appendTutorMessage('tutor', "Fantastic work! Your mathematical calculations are verified. Now answer the conceptual question to achieve topic mastery!");
      }
    } catch (err) {
      alert(`Verification error: ${err.message}`);
    } finally {
      btnGuidedVerify.disabled = false;
      btnGuidedVerify.innerHTML = '<i class="fa-solid fa-check-double"></i><span>Check My Work</span>';
    }
  });

  // Guided Layer 3 Submission
  btnGuidedSubmitLayer3.addEventListener('click', async () => {
    const text = guidedLayer3Input.value.trim();
    if (text.length < 10) {
      alert('Please provide a substantive conceptual explanation (at least 10 characters).');
      return;
    }

    btnGuidedSubmitLayer3.disabled = true;
    btnGuidedSubmitLayer3.textContent = 'Evaluating...';

    try {
      const assessment = await adaptive.submitLayer3Probe(text);
      if (assessment.passed) {
        alert("Milestone Mastered! Next milestone unlocked.");
        appendTutorMessage('tutor', `**Mastery Confirmed!** ${assessment.feedback}`);
        guidedLayer3Input.value = '';
      } else {
        alert(`Conceptual Gap: ${assessment.feedback}`);
        appendTutorMessage('tutor', `Close! But you missed: ${assessment.conceptual_gaps.join(', ')}. Try revising your answer.`);
      }
    } catch (err) {
      alert(`Assessment Error: ${err.message}`);
    } finally {
      btnGuidedSubmitLayer3.disabled = false;
      btnGuidedSubmitLayer3.textContent = 'Submit Conceptual Explanation';
    }
  });

  // Guided Tutor Form in Sidebar
  guidedTutorForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const msg = guidedTutorInput.value.trim();
    if (!msg) return;

    guidedTutorRecentMsg.textContent = `You: ${msg}`;
    guidedTutorInput.value = '';

    await dispatchTutorRequest(msg);
  });

  btnGuidedRemediation.addEventListener('click', async () => {
    try {
      const adapt = await adaptive.requestAdaptation('remediation');
      appendTutorMessage('tutor', `**[Bridge Task Activated]** ${adapt.title}\n\n${adapt.instructions}`);
      alert(`Bridge Task Activated: ${adapt.title}`);
    } catch (e) {
      alert(e.message);
    }
  });

  btnGuidedStretch.addEventListener('click', async () => {
    try {
      const adapt = await adaptive.requestAdaptation('stretch_challenge');
      appendTutorMessage('tutor', `**[Stretch Challenge Activated]** ${adapt.title}\n\n${adapt.instructions}`);
      alert(`Stretch Challenge Activated: ${adapt.title}`);
    } catch (e) {
      alert(e.message);
    }
  });

  btnSaveProjectGuided.onclick = () => {
    btnSaveProject.click();
  };

  // -------------------------------------------------------------
  // 6. DEVELOPER WORKSPACE MODE IMPLEMENTATION
  // -------------------------------------------------------------
  function renderDevView() {
    wsProjectTitle.textContent = currentProject.title;
    wsProjectDomain.textContent = `Domain: ${currentProject.domain} | Difficulty: ${currentProject.difficulty_profile.master_difficulty}/10`;

    const state = adaptive.getState();
    renderMilestonesList(state);
    renderDevActiveMilestone(adaptive.getActiveMilestone(), state);
    renderFileTabs();
  }

  function renderMilestonesList(state) {
    milestonesContainer.innerHTML = '';
    const milestones = currentProject.milestones || [];

    milestones.forEach((m, idx) => {
      const mStatus = state.status[m.id] || {};
      const isActive = (m.id === state.activeMilestoneId);

      const div = document.createElement('div');
      div.className = `milestone-item p-2.5 rounded-lg border text-xs cursor-pointer flex items-center justify-between ${
        isActive ? 'active border-indigo-500 bg-indigo-500/10' : 'border-slate-800 bg-slate-950/60 hover:bg-slate-800/40'
      } ${mStatus.locked ? 'opacity-40 pointer-events-none' : ''}`;

      let icon = '<i class="fa-regular fa-circle text-slate-500"></i>';
      if (mStatus.mastered) {
        icon = '<i class="fa-solid fa-crown text-amber-400"></i>';
      } else if (mStatus.l2) {
        icon = '<i class="fa-solid fa-check-double text-cyan-400"></i>';
      } else if (mStatus.l1) {
        icon = '<i class="fa-solid fa-check text-emerald-400"></i>';
      }

      div.innerHTML = `
        <div class="flex items-center space-x-2 truncate">
          <span>${icon}</span>
          <span class="font-medium text-slate-200 truncate">${m.title}</span>
        </div>
        <span class="text-[10px] text-slate-500 shrink-0">Step ${idx + 1}</span>
      `;

      div.onclick = () => {
        if (!mStatus.locked) {
          adaptive.setActiveMilestone(m.id);
        }
      };

      milestonesContainer.appendChild(div);
    });
  }

  function renderDevActiveMilestone(milestone, state) {
    if (!milestone) return;

    activeMilestoneTitle.textContent = milestone.title;
    activeMilestoneObj.textContent = milestone.objective;

    // Technical Incomplete Code / TODO Notes
    devTodoList.innerHTML = '';
    const devNotes = milestone.developer_notes || {};
    const incompleteSections = devNotes.incomplete_sections || [];
    devTodoCount.textContent = `${incompleteSections.length} items`;

    incompleteSections.forEach(sec => {
      const card = document.createElement('div');
      card.className = 'p-2 rounded bg-slate-900 border border-slate-800/80 space-y-1';
      card.innerHTML = `
        <div class="flex items-center justify-between">
          <span class="font-mono text-cyan-400 font-bold text-[11px]">${sec.function}()</span>
          <span class="px-1.5 py-0.5 rounded text-[9px] font-semibold bg-amber-500/20 text-amber-300 border border-amber-500/30">${sec.status}</span>
        </div>
        <p class="text-[10px] text-slate-300">${sec.requirement}</p>
        <div class="text-[9px] text-slate-500 font-mono">in: ${sec.inputs || 'N/A'} -> out: ${sec.output || 'N/A'}</div>
      `;
      devTodoList.appendChild(card);
    });

    // Render tasks
    activeMilestoneTasks.innerHTML = '';
    (milestone.tasks || []).forEach(task => {
      const li = document.createElement('li');
      li.className = 'flex items-start space-x-2';
      li.innerHTML = `<i class="fa-regular fa-square-check text-slate-500 text-[11px] mt-0.5"></i><span>${task}</span>`;
      activeMilestoneTasks.appendChild(li);
    });

    // Update 3-Layer Status
    const mStatus = state.status[milestone.id] || {};
    statusL1.innerHTML = mStatus.l1 ? '<i class="fa-solid fa-circle-check text-emerald-400"></i>' : '<i class="fa-regular fa-circle text-slate-500"></i>';
    statusL2.innerHTML = mStatus.l2 ? '<i class="fa-solid fa-circle-check text-cyan-400"></i>' : '<i class="fa-regular fa-circle text-slate-500"></i>';
    statusL3.innerHTML = mStatus.l3 ? '<i class="fa-solid fa-circle-check text-indigo-400"></i>' : '<i class="fa-regular fa-circle text-slate-500"></i>';

    if (mStatus.mastered) {
      verificationBadge.textContent = 'Mastered';
      verificationBadge.className = 'text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-semibold';
      layer3Card.classList.add('hidden');
    } else if (mStatus.l2) {
      verificationBadge.textContent = 'Correctness Passed';
      verificationBadge.className = 'text-[10px] px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 font-semibold';
      if (milestone.layer3_spec) {
        layer3Prompt.textContent = milestone.layer3_spec.prompt;
        layer3Card.classList.remove('hidden');
      }
    } else if (mStatus.l1) {
      verificationBadge.textContent = 'Execution Passed';
      verificationBadge.className = 'text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-semibold';
      layer3Card.classList.add('hidden');
    } else {
      verificationBadge.textContent = 'Not Verified';
      verificationBadge.className = 'text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 font-semibold';
      layer3Card.classList.add('hidden');
    }
  }

  // Developer File Tabs
  function renderFileTabs() {
    editorTabs.innerHTML = '';
    const files = currentProject.files || [];

    files.forEach((file, idx) => {
      const tab = document.createElement('div');
      tab.className = `file-tab ${idx === activeFileIndex ? 'active' : ''}`;
      tab.textContent = file.name;
      tab.onclick = () => {
        saveCurrentEditorContent();
        activeFileIndex = idx;
        renderFileTabs();
        loadActiveFileContent();
      };
      editorTabs.appendChild(tab);
    });
  }

  // Developer Console Output Tabs
  function setDevConsoleTab(activeTab) {
    const tabs = [
      { id: 'console', btn: tabBtnConsole, view: consoleView },
      { id: 'preview', btn: tabBtnPreview, view: previewContainer },
      { id: 'tests', btn: tabBtnTests, view: testsView },
      { id: 'inquiries', btn: tabBtnInquiries, view: inquiriesView }
    ];

    tabs.forEach(t => {
      if (t.id === activeTab) {
        t.btn.className = 'text-white font-semibold flex items-center space-x-1';
        t.view.classList.remove('hidden');
      } else {
        t.btn.className = 'text-slate-400 hover:text-white flex items-center space-x-1';
        t.view.classList.add('hidden');
      }
    });
  }

  tabBtnConsole.addEventListener('click', () => setDevConsoleTab('console'));
  tabBtnPreview.addEventListener('click', () => {
    setDevConsoleTab('preview');
    saveCurrentEditorContent();
    sandbox.executeWebPreview(previewContainer, currentProject.files);
  });
  tabBtnTests.addEventListener('click', () => setDevConsoleTab('tests'));
  tabBtnInquiries.addEventListener('click', () => setDevConsoleTab('inquiries'));

  // Run in Sandbox Button
  btnRunSandbox.addEventListener('click', async () => {
    saveCurrentEditorContent();
    btnRunSandbox.disabled = true;
    btnRunSandbox.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i><span>Executing...</span>';

    const isPython = (currentProject.execution_mode === 'browser_pyodide');

    if (isPython) {
      setDevConsoleTab('console');
      consoleView.innerHTML = '<div class="text-cyan-400">Loading Pyodide WebAssembly runtime and executing Python code...</div>';

      const entryFile = currentProject.files.find(f => f.name.endsWith('.py')) || currentProject.files[0];
      const result = await sandbox.executePython(entryFile ? entryFile.content : '');

      execTimer.textContent = `Execution time: ${result.durationMs}ms`;

      if (result.success) {
        consoleView.innerHTML = `
          <div class="text-emerald-400 font-semibold">[Execution Success] Exit Code 0</div>
          <div class="text-slate-200 whitespace-pre-wrap">${escapeHtml(result.stdout || 'Program completed with no output.')}</div>
        `;
        if (result.telemetry && Object.keys(result.telemetry).length > 0) {
          consoleView.innerHTML += `
            <div class="text-cyan-300 font-semibold mt-2">[Extracted Telemetry for Verification]:</div>
            <pre class="text-[11px] text-slate-400">${escapeHtml(JSON.stringify(result.telemetry, null, 2))}</pre>
          `;
        }
      } else {
        consoleView.innerHTML = `
          <div class="text-rose-400 font-semibold">[Runtime Error]</div>
          <div class="text-rose-300 whitespace-pre-wrap">${escapeHtml(result.error)}</div>
        `;
      }
    } else {
      setDevConsoleTab('preview');
      sandbox.executeWebPreview(previewContainer, currentProject.files);
    }

    btnRunSandbox.disabled = false;
    btnRunSandbox.innerHTML = '<i class="fa-solid fa-play"></i><span>Run in Sandbox</span>';
  });

  // Developer Run Verification Button
  btnRunVerification.addEventListener('click', async () => {
    saveCurrentEditorContent();
    btnRunVerification.disabled = true;
    btnRunVerification.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i><span>Verifying...</span>';
    verificationDiag.classList.add('hidden');

    try {
      const outcome = await adaptive.runVerification(currentProject.files);

      // Populate Dev Tests Tab
      let testsHtml = `<div class="font-bold text-slate-200 border-b border-slate-800 pb-1.5 flex items-center justify-between">
        <span>Verification Suite Telemetry</span>
        <span class="text-[10px] text-slate-400">Timestamp: ${new Date().toLocaleTimeString()}</span>
      </div>`;

      if (outcome.step === 'layer1_failed') {
        verificationDiag.innerHTML = `<span class="text-rose-400 font-semibold">Layer 1 Failed:</span> ${escapeHtml(outcome.error)}`;
        verificationDiag.classList.remove('hidden');
        appendTutorMessage('tutor', `Your code encountered a runtime or syntax error: \`${outcome.error}\`. Would you like a hint?`);

        testsHtml += `<div class="p-2 rounded bg-rose-950/40 border border-rose-500/30 text-rose-300">
          <strong>Layer 1 (Runtime) FAILED:</strong> ${escapeHtml(outcome.error)}
        </div>`;
      } else if (outcome.step === 'layer2_failed') {
        const v = outcome.verification;
        let checksSummary = (v.checks || []).map(c => `• ${c.name}: ${c.passed ? '✓ Passed' : '✗ Failed (' + c.diagnostic + ')'}`).join('<br>');
        verificationDiag.innerHTML = `<span class="text-amber-400 font-semibold">Layer 2 Correctness Failed:</span><br>${checksSummary}`;
        verificationDiag.classList.remove('hidden');

        let msg = `Layer 2 detected a mathematical discrepancy: ${v.diagnostics}.`;
        if (outcome.offerRemediation) {
          msg += "\n\nNotice: You can request a **Bridge Task** to deconstruct this milestone.";
        }
        appendTutorMessage('tutor', msg);

        testsHtml += `<div class="text-emerald-400">✓ Layer 1 (Runtime Execution): Passed</div>`;
        testsHtml += `<div class="space-y-1 pt-1"><div class="text-amber-400 font-semibold">Layer 2 Correctness Checks:</div>`;
        (v.checks || []).forEach(chk => {
          testsHtml += `<div class="p-2 rounded bg-slate-900 border border-slate-800 text-[11px] flex items-center justify-between">
            <div>
              <span class="${chk.passed ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}">${chk.passed ? 'PASS' : 'FAIL'}</span>
              <span class="text-slate-300 ml-1.5">${chk.name}</span>
            </div>
            <div class="text-slate-500 font-mono text-[10px]">${chk.diagnostic || 'Within tolerance'}</div>
          </div>`;
        });
        testsHtml += `</div>`;
      } else if (outcome.step === 'layer2_passed') {
        verificationDiag.innerHTML = `<span class="text-emerald-400 font-semibold">Layer 2 Passed!</span> Deterministic correctness verified. Answer Layer 3 Probe below.`;
        verificationDiag.classList.remove('hidden');

        let msg = "Awesome work! All numerical correctness checks passed! Answer the conceptual probe on the left panel to achieve topic mastery.";
        if (outcome.offerStretch) {
          msg += "\n\nYou also unlocked an optional **Stretch Goal**!";
        }
        appendTutorMessage('tutor', msg);

        testsHtml += `<div class="text-emerald-400">✓ Layer 1 (Runtime Execution): Passed</div>`;
        testsHtml += `<div class="text-emerald-400">✓ Layer 2 (Quantitative Correctness): All checks passed within specified numerical tolerances</div>`;
        testsHtml += `<div class="p-2 rounded bg-indigo-950/30 border border-indigo-500/20 text-indigo-300">
          <strong>Layer 3 Status:</strong> Awaiting conceptual explanation on left panel.
        </div>`;
      }

      testsView.innerHTML = testsHtml;

    } catch (err) {
      alert(`Verification Error: ${err.message}`);
    } finally {
      btnRunVerification.disabled = false;
      btnRunVerification.innerHTML = '<i class="fa-solid fa-play"></i><span>Verify Milestone</span>';
    }
  });

  // Developer Layer 3 Submission
  btnSubmitLayer3.addEventListener('click', async () => {
    const text = layer3Input.value.trim();
    if (text.length < 10) {
      alert('Please provide a substantive conceptual explanation (at least 10 characters).');
      return;
    }

    btnSubmitLayer3.disabled = true;
    btnSubmitLayer3.textContent = 'Evaluating Reasoning...';

    try {
      const assessment = await adaptive.submitLayer3Probe(text);
      if (assessment.passed) {
        alert("Milestone Mastered! Next milestone unlocked.");
        appendTutorMessage('tutor', `**Mastery Confirmed!** ${assessment.feedback}`);
        layer3Input.value = '';
      } else {
        alert(`Conceptual Gap: ${assessment.feedback}`);
        appendTutorMessage('tutor', `You're close! Missing concepts: ${assessment.conceptual_gaps.join(', ')}. Revise and resubmit.`);
      }
    } catch (err) {
      alert(`Assessment Error: ${err.message}`);
    } finally {
      btnSubmitLayer3.disabled = false;
      btnSubmitLayer3.textContent = 'Submit Conceptual Explanation';
    }
  });

  // Adaptations in Dev mode
  btnRequestRemediation.addEventListener('click', async () => {
    try {
      const adapt = await adaptive.requestAdaptation('remediation');
      appendTutorMessage('tutor', `**[Bridge Task Activated]** ${adapt.title}\n\n${adapt.instructions}`);
      alert(`Bridge Task Activated: ${adapt.title}`);
    } catch (e) {
      alert(e.message);
    }
  });

  btnRequestStretch.addEventListener('click', async () => {
    try {
      const adapt = await adaptive.requestAdaptation('stretch_challenge');
      appendTutorMessage('tutor', `**[Stretch Challenge Activated]** ${adapt.title}\n\n${adapt.instructions}`);
      alert(`Stretch Challenge Activated: ${adapt.title}`);
    } catch (e) {
      alert(e.message);
    }
  });

  // Inquiries chips in Dev Console
  document.querySelectorAll('.inquiry-prompt-chip').forEach(chip => {
    chip.addEventListener('click', async () => {
      const query = chip.getAttribute('data-query');
      appendTutorMessage('user', query);
      await dispatchTutorRequest(query);
    });
  });

  // -------------------------------------------------------------
  // 7. Embedded Socratic AI Tutor
  // -------------------------------------------------------------
  tutorForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const msg = tutorInput.value.trim();
    if (!msg) return;

    appendTutorMessage('user', msg);
    tutorInput.value = '';

    await dispatchTutorRequest(msg);
  });

  document.querySelectorAll('.tutor-chip').forEach(chip => {
    chip.addEventListener('click', async () => {
      const msg = chip.getAttribute('data-msg');
      appendTutorMessage('user', msg);
      await dispatchTutorRequest(msg);
    });
  });

  async function dispatchTutorRequest(msg) {
    if (!currentProject) return;

    const activeM = adaptive.getActiveMilestone();
    const activeFile = currentProject.files[activeFileIndex];

    const typingIndicator = appendTutorMessage('tutor', 'Thinking...');

    try {
      const resp = await api.sendTutorMessage({
        project_id: currentProject.id,
        milestone_id: activeM ? activeM.id : 'm1',
        message: msg,
        hint_tier: parseInt(selectHintTier.value, 10),
        code_context: activeFile ? activeFile.content.slice(0, 1500) : '',
        error_context: consoleView.innerText.slice(0, 500)
      });

      typingIndicator.remove();
      appendTutorMessage('tutor', resp.response.message, resp.response.disclaimer);

      if (guidedTutorRecentMsg) {
        guidedTutorRecentMsg.textContent = `Mentor: ${resp.response.message.slice(0, 120)}...`;
      }

    } catch (err) {
      typingIndicator.remove();
      appendTutorMessage('tutor', `Error contacting tutor: ${err.message}`);
    }
  }

  function appendTutorMessage(role, text, disclaimer = null) {
    const div = document.createElement('div');
    div.className = `p-3 rounded-xl max-w-[90%] text-xs space-y-1 ${
      role === 'user' ? 'chat-bubble-user ml-auto' : 'chat-bubble-tutor mr-auto'
    }`;

    div.innerHTML = `<div class="whitespace-pre-wrap">${escapeHtml(text)}</div>`;
    if (disclaimer) {
      div.innerHTML += `<div class="text-[10px] text-slate-500 italic border-t border-slate-700/60 pt-1 mt-1">${escapeHtml(disclaimer)}</div>`;
    }

    tutorChatMessages.appendChild(div);
    tutorChatMessages.scrollTop = tutorChatMessages.scrollHeight;
    return div;
  }

  // -------------------------------------------------------------
  // 8. Save & Export
  // -------------------------------------------------------------
  btnSaveProject.addEventListener('click', async () => {
    if (!currentProject) return;
    saveCurrentEditorContent();
    btnSaveProject.disabled = true;
    btnSaveProject.innerHTML = '<i class="fa-solid fa-spinner fa-spin mr-1"></i>Saving...';

    try {
      await api.saveProject(currentProject.id, {
        files: currentProject.files,
        active_milestone_id: adaptive.activeMilestoneId
      });
      alert('Project progress saved successfully!');
    } catch (err) {
      alert(`Save failed: ${err.message}`);
    } finally {
      btnSaveProject.disabled = false;
      btnSaveProject.innerHTML = '<i class="fa-regular fa-floppy-disk mr-1"></i>Save';
    }
  });

  btnExportProject.addEventListener('click', () => {
    if (!currentProject) return;
    saveCurrentEditorContent();
    window.location.href = api.getExportUrl(currentProject.id);
  });

  // Helpers
  function escapeHtml(str) {
    if (!str) return '';
    return str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }
});
