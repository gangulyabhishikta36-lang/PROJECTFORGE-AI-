/**
 * api_client.js
 * =============
 * Centralized API client for ProjectForge AI.
 * Handles request correlation IDs, JSON serialization, timeout controls,
 * AbortController cancellation, structured error normalization, and stale response protection.
 */

class ApiClient {
  constructor(baseUrl = '') {
    this.baseUrl = baseUrl;
    this.currentRequests = new Map();
    this.requestCounter = 0;
  }

  _generateRequestId() {
    this.requestCounter += 1;
    return `req_client_${Date.now()}_${this.requestCounter}`;
  }

  async _request(endpoint, options = {}) {
    const requestId = options.requestId || this._generateRequestId();
    const timeoutMs = options.timeoutMs || 25000;
    const controller = options.abortController || new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

    const headers = {
      'Accept': 'application/json',
      'X-Request-ID': requestId,
      ...(options.headers || {})
    };

    if (options.body && typeof options.body === 'object' && !(options.body instanceof FormData)) {
      headers['Content-Type'] = 'application/json';
      options.body = JSON.stringify(options.body);
    }

    try {
      const response = await fetch(`${this.baseUrl}${endpoint}`, {
        ...options,
        headers,
        signal: controller.signal
      });

      clearTimeout(timeoutId);

      // Handle non-JSON responses (e.g. file downloads)
      const contentType = response.headers.get('content-type') || '';
      if (!contentType.includes('application/json')) {
        if (!response.ok) {
          throw {
            code: `HTTP_${response.status}`,
            message: `Server returned non-JSON error ${response.status}: ${response.statusText}`,
            request_id: requestId
          };
        }
        return response;
      }

      const data = await response.json();

      if (!response.ok) {
        const errorInfo = data.error || {};
        throw {
          code: errorInfo.code || `HTTP_${response.status}`,
          message: errorInfo.message || `Request failed with status ${response.status}`,
          details: errorInfo.details || {},
          request_id: errorInfo.request_id || requestId
        };
      }

      return data;
    } catch (err) {
      clearTimeout(timeoutId);

      if (err.name === 'AbortError') {
        throw {
          code: 'REQUEST_ABORTED',
          message: 'The operation was cancelled or timed out.',
          request_id: requestId
        };
      }

      // If already normalized
      if (err.code) {
        throw err;
      }

      // Network or connection failure
      throw {
        code: 'NETWORK_ERROR',
        message: err.message || 'Unable to connect to ProjectForge API server.',
        details: {},
        request_id: requestId
      };
    }
  }

  // --- Core API Contract Methods ---

  async getConfig(signal) {
    return this._request('/api/config', { method: 'GET', abortController: signal ? { signal } : undefined });
  }

  async getTemplates(signal) {
    return this._request('/api/templates', { method: 'GET', abortController: signal ? { signal } : undefined });
  }

  async generateProject(payload, signal) {
    return this._request('/api/project/generate', {
      method: 'POST',
      body: payload,
      timeoutMs: 30000,
      abortController: signal ? { signal } : undefined
    });
  }

  async adaptProject(payload, signal) {
    return this._request('/api/project/adapt', {
      method: 'POST',
      body: payload,
      timeoutMs: 20000,
      abortController: signal ? { signal } : undefined
    });
  }

  async sendTutorMessage(payload, signal) {
    return this._request('/api/tutor/message', {
      method: 'POST',
      body: payload,
      timeoutMs: 20000,
      abortController: signal ? { signal } : undefined
    });
  }

  async verifyLayer2(payload, signal) {
    return this._request('/api/verify/layer2', {
      method: 'POST',
      body: payload,
      timeoutMs: 15000,
      abortController: signal ? { signal } : undefined
    });
  }

  async verifyLayer3(payload, signal) {
    return this._request('/api/verify/layer3', {
      method: 'POST',
      body: payload,
      timeoutMs: 15000,
      abortController: signal ? { signal } : undefined
    });
  }

  async getProject(projectId, signal) {
    return this._request(`/api/project/${encodeURIComponent(projectId)}`, {
      method: 'GET',
      abortController: signal ? { signal } : undefined
    });
  }

  async saveProject(projectId, payload, signal) {
    return this._request(`/api/project/${encodeURIComponent(projectId)}/save`, {
      method: 'POST',
      body: payload,
      timeoutMs: 15000,
      abortController: signal ? { signal } : undefined
    });
  }

  getExportUrl(projectId) {
    return `/api/project/${encodeURIComponent(projectId)}/export`;
  }
}

// Export singleton instance for browser global
window.apiClient = new ApiClient();
