/**
 * adaptive_controller.js
 * ======================
 * Manages in-flight adaptive difficulty, 3-layer verification progression,
 * and learner mastery assessment.
 */

class AdaptiveController {
  constructor(apiClient, sandboxRunner) {
    this.api = apiClient;
    this.sandbox = sandboxRunner;
    this.project = null;
    this.activeMilestoneId = null;
    this.attempts = {}; // milestoneId -> int
    this.consecutiveFailures = {}; // milestoneId -> int
    this.milestoneStatus = {}; // milestoneId -> { l1: bool, l2: bool, l3: bool, mastered: bool }
    this.listeners = new Set();
  }

  initProject(project) {
    this.project = project;
    this.activeMilestoneId = project.milestones && project.milestones.length > 0 ? project.milestones[0].id : null;
    this.attempts = {};
    this.consecutiveFailures = {};
    this.milestoneStatus = {};

    project.milestones.forEach((m, idx) => {
      this.attempts[m.id] = 0;
      this.consecutiveFailures[m.id] = 0;
      this.milestoneStatus[m.id] = {
        l1: false,
        l2: false,
        l3: false,
        mastered: false,
        locked: idx !== 0,
        adaptations: []
      };
    });

    this._notify();
  }

  onChange(listener) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  _notify() {
    for (const listener of this.listeners) {
      listener(this.getState());
    }
  }

  getState() {
    return {
      project: this.project,
      activeMilestoneId: this.activeMilestoneId,
      status: this.milestoneStatus,
      attempts: this.attempts,
      consecutiveFailures: this.consecutiveFailures
    };
  }

  getActiveMilestone() {
    if (!this.project || !this.activeMilestoneId) return null;
    return this.project.milestones.find(m => m.id === this.activeMilestoneId) || null;
  }

  setActiveMilestone(milestoneId) {
    const status = this.milestoneStatus[milestoneId];
    if (status && !status.locked) {
      this.activeMilestoneId = milestoneId;
      this._notify();
    }
  }

  // -------------------------------------------------------------
  // Full 3-Layer Verification Workflow
  // -------------------------------------------------------------
  async runVerification(currentFiles) {
    const m = this.getActiveMilestone();
    if (!m) throw new Error("No active milestone.");

    const mId = m.id;
    this.attempts[mId] = (this.attempts[mId] || 0) + 1;

    // --- LAYER 1: Execution Check in Browser Sandbox ---
    let execResult;
    const isPython = (this.project.execution_mode === 'browser_pyodide');

    if (isPython) {
      const entryFile = currentFiles.find(f => f.name.endsWith('.py')) || currentFiles[0];
      execResult = await this.sandbox.executePython(entryFile ? entryFile.content : '');
    } else {
      const container = document.getElementById('preview-container');
      execResult = this.sandbox.executeWebPreview(container, currentFiles);
    }

    if (!execResult.success) {
      this.consecutiveFailures[mId] = (this.consecutiveFailures[mId] || 0) + 1;
      this.milestoneStatus[mId].l1 = false;
      this._notify();

      return {
        step: 'layer1_failed',
        error: execResult.error,
        stderr: execResult.stderr,
        recommendation: 'Fix runtime and syntax errors before testing correctness.'
      };
    }

    this.milestoneStatus[mId].l1 = true;
    this._notify();

    // --- LAYER 2: Deterministic Correctness & Quantitative Checks ---
    const telemetryPayload = execResult.telemetry || {};

    let layer2Result;
    try {
      const resp = await this.api.verifyLayer2({
        project_id: this.project.id,
        milestone_id: mId,
        evaluation_payload: telemetryPayload
      });
      layer2Result = resp.verification;
    } catch (err) {
      return {
        step: 'layer2_error',
        error: err.message || 'Failed to communicate with Layer 2 verification service.'
      };
    }

    if (!layer2Result.passed) {
      this.consecutiveFailures[mId] = (this.consecutiveFailures[mId] || 0) + 1;
      this.milestoneStatus[mId].l2 = false;
      this._notify();

      const shouldOfferRemediation = this.consecutiveFailures[mId] >= 2;

      return {
        step: 'layer2_failed',
        verification: layer2Result,
        consecutiveFailures: this.consecutiveFailures[mId],
        offerRemediation: shouldOfferRemediation
      };
    }

    // Layer 2 Passed!
    this.consecutiveFailures[mId] = 0;
    this.milestoneStatus[mId].l2 = true;
    const wasFirstAttempt = (this.attempts[mId] === 1);
    this._notify();

    return {
      step: 'layer2_passed',
      verification: layer2Result,
      offerStretch: wasFirstAttempt,
      layer3Spec: m.layer3_spec
    };
  }

  // --- LAYER 3: Understanding Verification & Mastery ---
  async submitLayer3Probe(learnerResponse) {
    const m = this.getActiveMilestone();
    if (!m) throw new Error("No active milestone.");

    const resp = await this.api.verifyLayer3({
      project_id: this.project.id,
      milestone_id: m.id,
      learner_response: learnerResponse
    });

    const assessment = resp.assessment;
    if (assessment.passed) {
      this.milestoneStatus[m.id].l3 = true;
      this.milestoneStatus[m.id].mastered = true;

      // Unlock next milestone if available
      const currentIndex = this.project.milestones.findIndex(item => item.id === m.id);
      if (currentIndex !== -1 && currentIndex + 1 < this.project.milestones.length) {
        const nextId = this.project.milestones[currentIndex + 1].id;
        this.milestoneStatus[nextId].locked = false;
      }

      this._notify();
    }

    return assessment;
  }

  // --- In-flight Adaptations ---
  async requestAdaptation(adaptationType) {
    const m = this.getActiveMilestone();
    if (!m) throw new Error("No active milestone.");

    const resp = await this.api.adaptProject({
      project_id: this.project.id,
      milestone_id: m.id,
      adaptation_type: adaptationType,
      context: { attempts: this.attempts[m.id] }
    });

    const adaptation = resp.adaptation;
    this.milestoneStatus[m.id].adaptations.push(adaptation);
    this._notify();
    return adaptation;
  }
}

window.AdaptiveController = AdaptiveController;
