/**
 * sandbox_runner.js
 * =================
 * Browser-only sandboxed execution environment.
 * Enforces zero server execution risk:
 *   1. Restricted <iframe> with sandbox="allow-scripts" for Web/Canvas
 *   2. In-browser Pyodide WebAssembly for Python
 * Captures stdout, stderr, uncaught exceptions, and telemetry for Layer 2 verification.
 */

class SandboxRunner {
  constructor() {
    this.pyodideInstance = null;
    this.isPyodideLoading = false;
    this.pyodideLoadPromise = null;
    this.activeIframe = null;
    this.messageHandlers = new Set();

    // Listen for sandboxed iframe messages
    window.addEventListener('message', (event) => {
      this._handleIframeMessage(event);
    });
  }

  _handleIframeMessage(event) {
    const data = event.data;
    if (!data || typeof data !== 'object') return;
    if (data.source !== 'projectforge_sandbox') return;

    for (const handler of this.messageHandlers) {
      handler(data);
    }
  }

  onMessage(handler) {
    this.messageHandlers.add(handler);
    return () => this.messageHandlers.delete(handler);
  }

  // -------------------------------------------------------------
  // HTML/CSS/JS Sandbox (Restricted Iframe)
  // -------------------------------------------------------------
  executeWebPreview(containerEl, files) {
    // Clear existing preview
    containerEl.innerHTML = '';

    const htmlFile = files.find(f => f.name.endsWith('.html')) || files[0];
    const cssFiles = files.filter(f => f.name.endsWith('.css'));
    const jsFiles = files.filter(f => f.name.endsWith('.js'));

    let htmlContent = htmlFile ? htmlFile.content : '<html><body></body></html>';

    // Build injection bundle
    let cssBundle = cssFiles.map(f => `<style>/* ${f.name} */\n${f.content}</style>`).join('\n');
    let jsBundle = jsFiles.map(f => `/* ${f.name} */\n${f.content}`).join('\n');

    // Bridge script injected into iframe to intercept errors and logs
    const bridgeScript = `
      <script>
        (function() {
          function send(type, payload) {
            window.parent.postMessage({
              source: 'projectforge_sandbox',
              type: type,
              payload: payload,
              timestamp: Date.now()
            }, '*');
          }

          window.onerror = function(msg, url, line, col, error) {
            send('error', { message: msg, line: line, col: col });
            return false;
          };

          const oldLog = console.log;
          console.log = function(...args) {
            oldLog.apply(console, args);
            send('log', { text: args.map(a => typeof a === 'object' ? JSON.stringify(a) : String(a)).join(' ') });
          };

          const oldErr = console.error;
          console.error = function(...args) {
            oldErr.apply(console, args);
            send('error', { message: args.map(a => typeof a === 'object' ? JSON.stringify(a) : String(a)).join(' ') });
          };

          window.addEventListener('DOMContentLoaded', function() {
            send('ready', { status: 'ok' });
          });
        })();
      </script>
    `;

    // Inject CSS into <head> and JS into <body>
    let combinedHtml = htmlContent;
    if (combinedHtml.includes('</head>')) {
      combinedHtml = combinedHtml.replace('</head>', `${bridgeScript}\n${cssBundle}\n</head>`);
    } else {
      combinedHtml = `${bridgeScript}\n${cssBundle}\n` + combinedHtml;
    }

    if (jsBundle) {
      const scriptTag = `<script>\ntry {\n${jsBundle}\n} catch(e) {\n  console.error(e.message);\n}\n</script>`;
      if (combinedHtml.includes('</body>')) {
        combinedHtml = combinedHtml.replace('</body>', `${scriptTag}\n</body>`);
      } else {
        combinedHtml += `\n${scriptTag}`;
      }
    }

    // Create restricted iframe: sandbox="allow-scripts"
    // Omitting allow-same-origin isolates cookies, origin storage, and parent DOM access
    const iframe = document.createElement('iframe');
    iframe.setAttribute('sandbox', 'allow-scripts');
    iframe.style.width = '100%';
    iframe.style.height = '100%';
    iframe.style.border = 'none';
    iframe.srcdoc = combinedHtml;

    containerEl.appendChild(iframe);
    this.activeIframe = iframe;

    return {
      success: true,
      mode: 'web_iframe',
    };
  }

  // -------------------------------------------------------------
  // Pyodide WebAssembly Python Sandbox
  // -------------------------------------------------------------
  async loadPyodide() {
    if (this.pyodideInstance) return this.pyodideInstance;
    if (this.pyodideLoadPromise) return this.pyodideLoadPromise;

    this.isPyodideLoading = true;
    this.pyodideLoadPromise = new Promise(async (resolve, reject) => {
      try {
        // Load Pyodide script from CDN if not already loaded
        if (!window.loadPyodide) {
          const script = document.createElement('script');
          script.src = 'https://cdn.jsdelivr.net/pyodide/v0.26.4/full/pyodide.js';
          script.async = true;
          document.head.appendChild(script);

          await new Promise((res, rej) => {
            script.onload = res;
            script.onerror = () => rej(new Error('Failed to load Pyodide WebAssembly runtime from CDN.'));
          });
        }

        const pyodide = await window.loadPyodide({
          indexURL: 'https://cdn.jsdelivr.net/pyodide/v0.26.4/full/'
        });

        this.pyodideInstance = pyodide;
        this.isPyodideLoading = false;
        resolve(pyodide);
      } catch (err) {
        this.isPyodideLoading = false;
        this.pyodideLoadPromise = null;
        reject(err);
      }
    });

    return this.pyodideLoadPromise;
  }

  async executePython(code, options = {}) {
    const startTime = performance.now();
    let stdoutLogs = [];
    let stderrLogs = [];

    let pyodide;
    try {
      pyodide = await this.loadPyodide();
    } catch (e) {
      return {
        success: false,
        error: `Pyodide Initialization Failed: ${e.message}`,
        stdout: '',
        stderr: '',
        durationMs: 0
      };
    }

    // Set up standard output captures
    pyodide.setStdout({ batched: (str) => stdoutLogs.push(str) });
    pyodide.setStderr({ batched: (str) => stderrLogs.push(str) });

    try {
      // Execute learner Python code in isolated namespace
      await pyodide.runPythonAsync(code);

      // Extract telemetry variables if they exist in global Python namespace
      const telemetry = {};
      const targetVars = [
        'test_mse', 'test_preds', 'dw', 'db', 'final_w', 'final_b',
        'loss_history', 'initial_energy', 'final_energy', 'force_magnitude',
        'status_ok', 'algorithm_pass'
      ];

      for (const varName of targetVars) {
        try {
          const val = pyodide.globals.get(varName);
          if (val !== undefined && val !== null) {
            // Convert Pyodide JS proxies to native JS types
            if (typeof val.toJs === 'function') {
              telemetry[varName] = val.toJs();
            } else {
              telemetry[varName] = val;
            }
          }
        } catch (_) {}
      }

      const durationMs = Math.round(performance.now() - startTime);

      return {
        success: true,
        stdout: stdoutLogs.join('\n'),
        stderr: stderrLogs.join('\n'),
        telemetry: telemetry,
        durationMs: durationMs
      };
    } catch (err) {
      const durationMs = Math.round(performance.now() - startTime);
      return {
        success: false,
        error: err.message,
        stdout: stdoutLogs.join('\n'),
        stderr: stderrLogs.join('\n'),
        durationMs: durationMs
      };
    }
  }
}

window.sandboxRunner = new SandboxRunner();
