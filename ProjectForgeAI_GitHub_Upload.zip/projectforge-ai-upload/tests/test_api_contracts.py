"""
test_api_contracts.py
======================
Comprehensive automated test suite for ProjectForge AI.
Tests API contracts, validation, 4D difficulty calibration, ambiguity detection,
Layer 2 quantitative checks, Layer 3 understanding probes, adaptive scaffolding,
persistence, export packaging, and security safeguards.
"""

import pytest
import json
import io
import zipfile
from app import app
from difficulty_engine import DifficultyEngine
from quantitative_verifier import QuantitativeVerifier


@pytest.fixture
def client():
    app.config["TESTING"] = True
    with app.test_client() as client:
        yield client


# =====================================================================
# 1. Configuration & Security Tests
# =====================================================================
def test_config_endpoint_safe(client):
    """Verify /api/config returns safe config and NEVER leaks raw secrets."""
    resp = client.get("/api/config")
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["status"] == "success"
    cfg = data["config"]

    # Security check: absolutely no raw API keys in response
    assert "gemini_key" not in cfg
    assert "openai_key" not in cfg
    assert "anthropic_key" not in cfg
    assert "supported_execution_modes" in cfg
    assert "active_provider" in cfg
    assert resp.headers.get("X-Content-Type-Options") == "nosniff"


def test_request_id_correlation(client):
    """Verify X-Request-ID correlation header is tracked and echoed."""
    custom_id = "test_req_correlation_999"
    resp = client.get("/api/config", headers={"X-Request-ID": custom_id})
    assert resp.status_code == 200
    assert resp.headers.get("X-Request-ID") == custom_id
    assert resp.get_json()["request_id"] == custom_id


# =====================================================================
# 2. Request Validation Tests
# =====================================================================
def test_generate_missing_or_short_prompt(client):
    """Verify prompt validation: empty or short prompts fail with 422."""
    resp = client.post("/api/project/generate", json={"prompt": ""})
    assert resp.status_code == 422
    err = resp.get_json()["error"]
    assert err["code"] == "VALIDATION_ERROR"

    resp2 = client.post("/api/project/generate", json={"prompt": "hi"})
    assert resp2.status_code == 422


def test_generate_invalid_difficulty(client):
    """Verify difficulty outside 1-10 fails with 422."""
    resp = client.post("/api/project/generate", json={"prompt": "Build linear regression", "difficulty": 15})
    assert resp.status_code == 422

    resp2 = client.post("/api/project/generate", json={"prompt": "Build linear regression", "difficulty": 0})
    assert resp2.status_code == 422

    resp3 = client.post("/api/project/generate", json={"prompt": "Build linear regression", "difficulty": "abc"})
    assert resp3.status_code == 422


def test_generate_invalid_persona_or_domain(client):
    """Verify persona and domain enum validation."""
    resp = client.post("/api/project/generate", json={
        "prompt": "Build linear regression",
        "difficulty": 5,
        "persona": "superadmin"
    })
    assert resp.status_code == 422

    resp2 = client.post("/api/project/generate", json={
        "prompt": "Build linear regression",
        "difficulty": 5,
        "domain": "invalid_domain_xyz"
    })
    assert resp2.status_code == 422


def test_generate_malformed_json(client):
    """Verify malformed JSON body returns 400."""
    resp = client.post("/api/project/generate", data="not-a-json", content_type="application/json")
    assert resp.status_code == 400


# =====================================================================
# 3. Ambiguity & Boundary Clarification Tests
# =====================================================================
def test_ambiguous_prompt_returns_clarification(client):
    """Verify broad/vague prompts trigger structured pedagogical clarification."""
    resp = client.post("/api/project/generate", json={"prompt": "Teach me quantum computing", "difficulty": 5})
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["status"] == "needs_clarification"
    c = data["clarification"]
    assert "explanation" in c
    assert len(c["clarifying_questions"]) >= 2


# =====================================================================
# 4. Successful Generation & 4D Calibration Tests
# =====================================================================
def test_successful_project_generation(client):
    """Verify valid prompt generates a complete, structured project model."""
    resp = client.post("/api/project/generate", json={
        "prompt": "Build a linear regression model from scratch using gradient descent.",
        "difficulty": 5,
        "persona": "student"
    })
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["status"] == "success"

    project = data["project"]
    assert project["id"].startswith("proj_")
    assert len(project["milestones"]) >= 3
    assert len(project["files"]) >= 1

    # Check 4D difficulty profile
    profile = project["difficulty_profile"]
    assert profile["conceptual"] == 5
    assert profile["implementation"] == 5
    assert profile["prerequisite"] == 5
    assert profile["independence"] == 5

    # Check that each milestone contains Layer 1, 2, and 3 specs
    for m in project["milestones"]:
        assert "layer1_spec" in m
        assert "layer2_spec" in m
        assert "layer3_spec" in m


def test_educator_mode_includes_rubric(client):
    """Verify educator persona generates teacher grading criteria."""
    resp = client.post("/api/project/generate", json={
        "prompt": "Build a linear regression model from scratch using gradient descent.",
        "difficulty": 5,
        "persona": "educator"
    })
    assert resp.status_code == 200
    project = resp.get_json()["project"]
    assert project["educator_rubric"] is not None
    assert "grading_criteria" in project["educator_rubric"]


# =====================================================================
# 5. Layer 2 Quantitative Verification Tests
# =====================================================================
def test_layer2_numerical_evaluation(client):
    """Test Layer 2 verification for deterministic calculations."""
    # First generate the project
    gen_resp = client.post("/api/project/generate", json={
        "prompt": "Build a linear regression model from scratch using gradient descent.",
        "difficulty": 5
    })
    project = gen_resp.get_json()["project"]
    p_id = project["id"]
    m_id = project["milestones"][0]["id"]

    # Test passing payload
    pass_payload = {
        "test_mse": 4.0,
        "test_preds": [2.0, 4.0, 6.0]
    }
    resp = client.post("/api/verify/layer2", json={
        "project_id": p_id,
        "milestone_id": m_id,
        "evaluation_payload": pass_payload
    })
    assert resp.status_code == 200
    res = resp.get_json()["verification"]
    assert res["passed"] is True
    assert res["status"] == "pass"

    # Test failing payload (numerical divergence)
    fail_payload = {
        "test_mse": 99.5,
        "test_preds": [10.0, 20.0, 30.0]
    }
    resp_fail = client.post("/api/verify/layer2", json={
        "project_id": p_id,
        "milestone_id": m_id,
        "evaluation_payload": fail_payload
    })
    assert resp_fail.status_code == 200
    res_fail = resp_fail.get_json()["verification"]
    assert res_fail["passed"] is False
    assert res_fail["status"] == "fail"


def test_quantitative_verifier_loss_convergence():
    """Unit test for loss convergence invariant."""
    # Monotonic drop from 10 to 1
    good_losses = [10.0, 8.0, 5.0, 3.0, 1.2]
    res = QuantitativeVerifier.verify_loss_convergence(good_losses, min_reduction_pct=50.0)
    assert res["passed"] is True

    # Diverging losses
    bad_losses = [1.0, 5.0, 20.0, 100.0]
    res_bad = QuantitativeVerifier.verify_loss_convergence(bad_losses)
    assert res_bad["passed"] is False


def test_quantitative_verifier_energy_conservation():
    """Unit test for Hamiltonian energy conservation in orbital simulations."""
    # Drift within 2%
    res = QuantitativeVerifier.verify_energy_conservation(100.0, 101.5, tolerance=0.03)
    assert res["passed"] is True

    # Severe drift > 10%
    res_drift = QuantitativeVerifier.verify_energy_conservation(100.0, 115.0, tolerance=0.05)
    assert res_drift["passed"] is False


# =====================================================================
# 6. Layer 3 Conceptual Understanding Tests
# =====================================================================
def test_layer3_understanding_evaluation(client):
    """Test Layer 3 conceptual reflection assessment."""
    gen_resp = client.post("/api/project/generate", json={
        "prompt": "Build a linear regression model from scratch using gradient descent.",
        "difficulty": 5
    })
    project = gen_resp.get_json()["project"]
    p_id = project["id"]
    m_id = project["milestones"][0]["id"]

    # Passing conceptual answer mentioning key terms
    passing_resp = client.post("/api/verify/layer3", json={
        "project_id": p_id,
        "milestone_id": m_id,
        "learner_response": "We square the errors because it penalizes larger errors more severely and is differentiable everywhere, while canceling negative signs."
    })
    assert passing_resp.status_code == 200
    ass = passing_resp.get_json()["assessment"]
    assert ass["passed"] is True
    assert ass["outcome"] == "mastered"

    # Shallow / Missing answer
    failing_resp = client.post("/api/verify/layer3", json={
        "project_id": p_id,
        "milestone_id": m_id,
        "learner_response": "Because squaring is good math practice."
    })
    assert failing_resp.status_code == 200
    ass_fail = failing_resp.get_json()["assessment"]
    assert ass_fail["passed"] is False
    assert ass_fail["outcome"] == "gap_identified"


# =====================================================================
# 7. Adaptive Difficulty & Scaffolding Tests
# =====================================================================
def test_adaptive_remediation_and_stretch(client):
    """Test in-flight adaptation requests."""
    gen_resp = client.post("/api/project/generate", json={
        "prompt": "Build a linear regression model from scratch using gradient descent.",
        "difficulty": 5
    })
    project = gen_resp.get_json()["project"]
    p_id = project["id"]
    m_id = project["milestones"][0]["id"]

    # Request remediation
    rem_resp = client.post("/api/project/adapt", json={
        "project_id": p_id,
        "milestone_id": m_id,
        "adaptation_type": "remediation"
    })
    assert rem_resp.status_code == 200
    adapt_rem = rem_resp.get_json()["adaptation"]
    assert adapt_rem["type"] == "remediation"
    assert adapt_rem["parent_milestone_id"] == m_id

    # Request stretch challenge
    stretch_resp = client.post("/api/project/adapt", json={
        "project_id": p_id,
        "milestone_id": m_id,
        "adaptation_type": "stretch_challenge"
    })
    assert stretch_resp.status_code == 200
    adapt_stretch = stretch_resp.get_json()["adaptation"]
    assert adapt_stretch["type"] == "stretch_challenge"


# =====================================================================
# 8. Socratic Tutor Tier Tests
# =====================================================================
def test_tutor_tiers(client):
    """Verify Socratic tutor respects Tier 1, 2, and 3 guidance styles."""
    gen_resp = client.post("/api/project/generate", json={
        "prompt": "Build a linear regression model from scratch using gradient descent.",
        "difficulty": 5
    })
    project = gen_resp.get_json()["project"]
    p_id = project["id"]
    m_id = project["milestones"][0]["id"]

    for tier in [1, 2, 3]:
        resp = client.post("/api/tutor/message", json={
            "project_id": p_id,
            "milestone_id": m_id,
            "message": "How do I calculate the gradient?",
            "hint_tier": tier
        })
        assert resp.status_code == 200
        data = resp.get_json()["response"]
        assert data["hint_tier"] == tier
        assert len(data["message"]) > 20


# =====================================================================
# 9. Persistence & Export Tests
# =====================================================================
def test_save_and_export_project(client):
    """Verify saving progress and generating clean, secure ZIP export."""
    gen_resp = client.post("/api/project/generate", json={
        "prompt": "Build a linear regression model from scratch using gradient descent.",
        "difficulty": 5
    })
    project = gen_resp.get_json()["project"]
    p_id = project["id"]

    # Save progress with modified file
    modified_files = [
        {"name": "regression.py", "language": "python", "content": "# Updated learner solution\ndef test(): pass"}
    ]
    save_resp = client.post(f"/api/project/{p_id}/save", json={
        "files": modified_files,
        "active_milestone_id": "m1"
    })
    assert save_resp.status_code == 200

    # Retrieve saved project
    get_resp = client.get(f"/api/project/{p_id}")
    assert get_resp.status_code == 200
    assert get_resp.get_json()["project"]["files"][0]["content"] == "# Updated learner solution\ndef test(): pass"

    # Export ZIP
    export_resp = client.get(f"/api/project/{p_id}/export")
    assert export_resp.status_code == 200
    assert export_resp.headers.get("Content-Type") == "application/zip"

    # Inspect zip contents
    zip_bytes = io.BytesIO(export_resp.data)
    with zipfile.ZipFile(zip_bytes, "r") as zf:
        file_list = zf.namelist()
        assert "regression.py" in file_list
        assert "PROJECT_MASTERY_REPORT.md" in file_list
        # Ensure no secrets or hidden files in zip
        for fname in file_list:
            assert not fname.startswith(".")
            assert "env" not in fname.lower()


def test_path_traversal_rejection(client):
    """Verify directory traversal attempts in project IDs are rejected."""
    resp = client.get("/api/project/..%2F..%2Fetc%2Fpasswd")
    assert resp.status_code in (404, 400, 422)
