"""
tests/test_stage2_blueprint_architecture.py
============================================
Comprehensive automated test suite for Stage 2:
Structured Project Blueprint Architecture.

Tests:
1. 20-field Blueprint schema completeness and field types.
2. Provenance separation (learner-supplied vs system-inferred vs working assumptions vs retrieval requirements).
3. Ambiguity and polysemy detection ('equilibrium', 'regression', 'model', 'stability').
4. Milestone dependency validation:
   - Valid linear and branching DAGs.
   - Rejection of circular dependencies (cycle detection).
   - Rejection of self-referential dependencies.
   - Rejection of references to nonexistent milestones.
5. Feasibility and technical architecture validation:
   - Unsupported runtimes rejected.
   - Missing required fields detected and failed.
6. Conditional domain requirements across diverse subjects:
   - Programming (Algorithms / AVL Tree / Sorting)
   - Mathematics (Gradient Descent / Optimization)
   - Statistics & Econometrics (Macroeconomic Inflation / Regression)
   - Physics & Scientific Simulation (Gravitational Orbits)
   - Interdisciplinary topics
7. Downstream system contract interfaces:
   - KnowledgeRetrievalContract
   - ArtifactGenerationContract
   - VerificationSpecContract
   - TutorContextContract
8. Inspectable blueprint API endpoint (/api/project/blueprint) validation and contract preservation.
"""

import pytest
from app import app
from blueprint_engine import (
    BlueprintEngine,
    BlueprintValidationResult,
    KnowledgeRetrievalContract,
    ArtifactGenerationContract,
    VerificationSpecContract,
    TutorContextContract,
)
from curriculum_generator import CurriculumGenerator


@pytest.fixture
def client():
    app.config["TESTING"] = True
    with app.test_client() as client:
        yield client


@pytest.fixture
def generator():
    return CurriculumGenerator()


# =====================================================================
# 1. 20-Field Blueprint Completeness & Schema
# =====================================================================
def test_blueprint_has_all_20_canonical_fields():
    """Verify that every created blueprint contains all 20 canonical fields and provenance."""
    bp = BlueprintEngine.create_blueprint("Build a linear regression model from scratch", difficulty=5)

    canonical_fields = [
        "project_objective", "intended_deliverable", "domain_roles",
        "central_question", "key_concepts", "prerequisites", "assumptions",
        "required_inputs_resources", "planned_outputs", "technical_architecture",
        "milestones", "milestone_dependencies", "learning_objectives",
        "implementation_strategy", "verification_strategy", "expected_failure_modes",
        "known_limitations", "external_info_requirements", "required_tools",
        "completion_criteria"
    ]
    for field in canonical_fields:
        assert field in bp, f"Missing canonical field: {field}"
        assert bp[field] is not None, f"Field {field} is None"

    # Provenance bucket must exist
    assert "provenance" in bp
    prov = bp["provenance"]
    assert "learner_supplied" in prov
    assert "system_inferred" in prov
    assert "working_assumptions" in prov
    assert "clarification_requirements" in prov
    assert "external_retrieval_requirements" in prov
    assert "unverified_limitations" in prov


def test_blueprint_validation_passes_valid_curated_blueprint():
    """Valid curated blueprint passes validation with zero errors."""
    bp = BlueprintEngine.create_blueprint("Build a linear regression model from scratch", difficulty=5)
    result = BlueprintEngine.validate_blueprint(bp)
    assert isinstance(result, BlueprintValidationResult)
    assert result.is_valid is True
    assert len(result.errors) == 0


# =====================================================================
# 2. Provenance Separation
# =====================================================================
def test_provenance_distinguishes_learner_supplied_from_system_inferred():
    """Verify learner inputs are never conflated with system inferences or assumptions."""
    bp = BlueprintEngine.create_blueprint(
        prompt="Simulate monetary policy inflation with machine learning",
        difficulty=7,
        persona="student",
        domain="economics"
    )
    prov = bp["provenance"]

    # Learner supplied
    assert prov["learner_supplied"]["raw_prompt"] == "Simulate monetary policy inflation with machine learning"
    assert prov["learner_supplied"]["requested_difficulty"] == 7
    assert prov["learner_supplied"]["requested_persona"] == "student"
    assert prov["learner_supplied"]["explicit_domain_preference"] == "economics"

    # System inferred
    assert prov["system_inferred"]["domain_roles"]["primary"] == "economics"
    assert prov["system_inferred"]["domain_roles"]["methodological"] == "machine_learning"
    assert prov["system_inferred"]["domain_roles"]["evaluation"] == "econometrics_and_statistics"

    # Working assumptions
    assert len(prov["working_assumptions"]) > 0


# =====================================================================
# 3. Ambiguity & Polysemy Detection
# =====================================================================
def test_detect_ambiguity_equilibrium_terms():
    """Verify polysemic term 'equilibrium' triggers multi-disciplinary interpretations."""
    ambiguities = BlueprintEngine.detect_ambiguities("Simulate market equilibrium under taxation")
    assert len(ambiguities) >= 1
    eq_amb = next(a for a in ambiguities if a["term"] == "equilibrium")
    assert "economics" in [alt["role"] for alt in eq_amb["alternatives"]]
    assert "physics" in [alt["role"] for alt in eq_amb["alternatives"]]
    assert "game_theory" in [alt["role"] for alt in eq_amb["alternatives"]]
    assert "competitive supply/demand" in eq_amb["default_assumption"]


def test_detect_ambiguity_regression_terms():
    """Verify term 'regression' identifies statistical OLS vs ML gradient descent alternatives."""
    ambiguities = BlueprintEngine.detect_ambiguities("Implement robust regression")
    assert len(ambiguities) >= 1
    reg_amb = next(a for a in ambiguities if a["term"] == "regression")
    roles = [alt["role"] for alt in reg_amb["alternatives"]]
    assert "statistics" in roles
    assert "machine_learning" in roles


# =====================================================================
# 4. Milestone Dependency Validation & Cycle Detection
# =====================================================================
def test_milestone_dependency_cycle_detection():
    """Blueprint validator must detect and reject circular milestone dependencies."""
    bp = BlueprintEngine.create_blueprint("Linear regression from scratch")

    # Introduce a cycle: m1 -> m2 -> m3 -> m1
    bp["milestones"] = [
        {"id": "m1", "title": "M1", "purpose": "P1", "depends_on": ["m3"]},
        {"id": "m2", "title": "M2", "purpose": "P2", "depends_on": ["m1"]},
        {"id": "m3", "title": "M3", "purpose": "P3", "depends_on": ["m2"]},
    ]
    bp["milestone_dependencies"] = {
        "m1": ["m3"],
        "m2": ["m1"],
        "m3": ["m2"],
    }

    result = BlueprintEngine.validate_blueprint(bp)
    assert result.is_valid is False
    assert any("Circular milestone dependency" in err for err in result.errors)


def test_milestone_self_referential_dependency_rejected():
    """A milestone depending on itself must be rejected."""
    bp = BlueprintEngine.create_blueprint("Linear regression from scratch")
    bp["milestones"][0]["depends_on"] = [bp["milestones"][0]["id"]]
    bp["milestone_dependencies"][bp["milestones"][0]["id"]] = [bp["milestones"][0]["id"]]

    result = BlueprintEngine.validate_blueprint(bp)
    assert result.is_valid is False
    assert any("Self-referential" in err for err in result.errors)


def test_milestone_reference_to_nonexistent_dependency_rejected():
    """A milestone depending on a nonexistent ID must be rejected."""
    bp = BlueprintEngine.create_blueprint("Linear regression from scratch")
    bp["milestones"][0]["depends_on"] = ["nonexistent_milestone_xyz"]
    bp["milestone_dependencies"][bp["milestones"][0]["id"]] = ["nonexistent_milestone_xyz"]

    result = BlueprintEngine.validate_blueprint(bp)
    assert result.is_valid is False
    assert any("undefined milestone" in err for err in result.errors)


# =====================================================================
# 5. Missing Required Information & Feasibility Constraints
# =====================================================================
def test_missing_required_fields_fails_validation():
    """Blueprint validator fails when canonical fields are stripped."""
    bp = BlueprintEngine.create_blueprint("Linear regression from scratch")
    del bp["project_objective"]
    del bp["verification_strategy"]

    result = BlueprintEngine.validate_blueprint(bp)
    assert result.is_valid is False
    assert any("Missing required blueprint field: 'project_objective'" in err for err in result.errors)
    assert any("Missing required blueprint field: 'verification_strategy'" in err for err in result.errors)


def test_unsupported_runtime_fails_validation():
    """Blueprint validator rejects unsupported execution environments."""
    bp = BlueprintEngine.create_blueprint("Linear regression from scratch")
    bp["technical_architecture"]["runtime"] = "docker_unrestricted_root"

    result = BlueprintEngine.validate_blueprint(bp)
    assert result.is_valid is False
    assert any("Unsupported runtime" in err for err in result.errors)


# =====================================================================
# 6. Domain-Agnostic Subject Coverage
# =====================================================================
def test_blueprint_economics_and_ml_interdisciplinary_decomposition():
    """Interdisciplinary economic + ML project assigns distinct functional roles."""
    bp = BlueprintEngine.create_blueprint("Investigate inflation and unemployment with machine learning")
    roles = bp["domain_roles"]
    assert roles["primary"] == "economics"
    assert roles["methodological"] == "machine_learning"
    assert roles["evaluation"] == "econometrics_and_statistics"
    assert bp["technical_architecture"]["runtime"] == "browser_pyodide"


def test_blueprint_algorithms_decomposition():
    """Computer science algorithms prompt maps to asymptotic operations and discrete math."""
    bp = BlueprintEngine.create_blueprint("Build a balanced AVL Tree in Python")
    roles = bp["domain_roles"]
    assert roles["primary"] == "computer_science_algorithms"
    assert roles["methodological"] == "asymptotic_analysis"
    assert bp["technical_architecture"]["runtime"] == "browser_pyodide"


def test_blueprint_physics_simulation_decomposition():
    """Physics simulation prompt maps to classical mechanics, Verlet integration, and Canvas."""
    bp = BlueprintEngine.create_blueprint("Build a planetary orbit gravitational simulation")
    roles = bp["domain_roles"]
    assert roles["primary"] == "classical_mechanics"
    assert roles["methodological"] == "numerical_integration"
    assert roles["computational"] == "html5_canvas_javascript"
    assert bp["technical_architecture"]["runtime"] == "browser_iframe"


# =====================================================================
# 7. Downstream System Contract Interfaces
# =====================================================================
def test_knowledge_retrieval_contract_extraction():
    """KnowledgeRetrievalContract cleanly extracts structured search requirements."""
    bp = BlueprintEngine.create_blueprint("Build an epidemic SIR contagion model on Canvas")
    retrieval_spec = KnowledgeRetrievalContract.extract_retrieval_query_spec(bp)
    assert "blueprint_id" in retrieval_spec
    assert "primary_domain" in retrieval_spec
    assert "central_question" in retrieval_spec
    assert "required_information" in retrieval_spec

    # Evidence validator accepts valid citations
    valid_payload = {
        "sources": [
            {
                "title": "Kermack and McKendrick Epidemic Model (1927)",
                "provenance_type": "peer_reviewed_literature",
                "excerpt": "Differential transmission rate beta and removal rate gamma govern epidemic threshold."
            }
        ]
    }
    is_valid, errors = KnowledgeRetrievalContract.validate_evidence_payload(valid_payload)
    assert is_valid is True
    assert len(errors) == 0

    # Evidence validator rejects sources lacking provenance or excerpt
    invalid_payload = {"sources": [{"title": "Blog post"}]}
    is_valid2, errors2 = KnowledgeRetrievalContract.validate_evidence_payload(invalid_payload)
    assert is_valid2 is False
    assert len(errors2) > 0


def test_artifact_generation_contract():
    """ArtifactGenerationContract formats validated blueprint for code generation."""
    bp = BlueprintEngine.create_blueprint("Linear regression from scratch")
    gen_spec = ArtifactGenerationContract.build_generation_spec(bp)
    assert gen_spec["language"] == "python"
    assert gen_spec["runtime"] == "browser_pyodide"
    assert len(gen_spec["milestones"]) >= 3


def test_verification_spec_contract():
    """VerificationSpecContract extracts milestone check criteria."""
    bp = BlueprintEngine.create_blueprint("Linear regression from scratch")
    m1_spec = VerificationSpecContract.extract_milestone_verification_specs(bp, "m1")
    assert m1_spec is not None
    assert m1_spec["milestone_id"] == "m1"
    assert m1_spec["check_spec"]["type"] == "scalar_match"
    assert m1_spec["check_spec"]["expected"] == 4.0


def test_tutor_context_contract():
    """TutorContextContract provides project blueprint and active milestone grounding."""
    bp = BlueprintEngine.create_blueprint("Linear regression from scratch")
    tutor_ctx = TutorContextContract.get_grounded_tutor_context(bp, "m1")
    assert tutor_ctx["project_objective"] == bp["project_objective"]
    assert tutor_ctx["active_milestone"]["id"] == "m1"
    assert "working_assumptions" in tutor_ctx
    assert "known_limitations" in tutor_ctx


# =====================================================================
# 8. Inspectable Blueprint API Endpoint (/api/project/blueprint)
# =====================================================================
def test_api_blueprint_endpoint_valid_request(client):
    """POST /api/project/blueprint returns structured 20-field blueprint with validation."""
    resp = client.post("/api/project/blueprint", json={
        "prompt": "Build a linear regression model from scratch using gradient descent",
        "difficulty": 5,
        "persona": "student"
    })
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["status"] == "success"
    assert "blueprint" in data
    assert "validation" in data
    assert data["validation"]["is_valid"] is True

    bp = data["blueprint"]
    assert bp["project_objective"] != ""
    assert len(bp["milestones"]) >= 3
    assert bp["provenance"]["learner_supplied"]["raw_prompt"] != ""


def test_api_blueprint_endpoint_validation_errors(client):
    """POST /api/project/blueprint rejects empty or invalid requests."""
    resp = client.post("/api/project/blueprint", json={"prompt": ""})
    assert resp.status_code == 422
    assert resp.get_json()["error"]["code"] == "VALIDATION_ERROR"

    resp2 = client.post("/api/project/blueprint", json={"prompt": "valid prompt", "difficulty": 99})
    assert resp2.status_code == 422


def test_generated_project_embeds_validated_blueprint(client):
    """Generated projects embed the 20-field blueprint and validation result."""
    resp = client.post("/api/project/generate", json={
        "prompt": "Build a linear regression model from scratch using gradient descent.",
        "difficulty": 5
    })
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["status"] == "success"
    assert "blueprint" in data
    assert "blueprint" in data["project"]
    assert "blueprint_validation" in data["project"]
    assert data["project"]["blueprint_validation"]["is_valid"] is True
