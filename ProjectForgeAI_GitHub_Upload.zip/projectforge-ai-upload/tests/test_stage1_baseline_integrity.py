"""
tests/test_stage1_baseline_integrity.py
=======================================
Focused regression test suite for Stage 1:
1. Verification of curated, supported exemplars (Linear Regression & Orbital Simulation).
2. Honest reporting for uncurated topics in offline mode (unsupported_offline).
3. Rejection of false-success behaviors:
   - Empty or unverified checks must NEVER report passed: True.
   - Missing payload fields in assertions must fail.
   - Deliberately incorrect math/physics outputs must fail Layer 2.
   - 25-word irrelevant non-answers must fail Layer 3 conceptual evaluation.
4. Preservation of API and dual-mode metadata contracts.
"""

import pytest
from app import app
from curriculum_generator import CurriculumGenerator
from quantitative_verifier import QuantitativeVerifier


@pytest.fixture
def client():
    app.config["TESTING"] = True
    with app.test_client() as client:
        yield client


@pytest.fixture
def generator():
    return CurriculumGenerator()


# =====================================================================
# 1. Curated Exemplar Verification
# =====================================================================
def test_curated_linear_regression_verified(client):
    """Supported curated Linear Regression project generates complete and verified."""
    resp = client.post("/api/project/generate", json={
        "prompt": "Build a linear regression model from scratch using gradient descent.",
        "difficulty": 5,
        "persona": "student"
    })
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["status"] == "success"

    project = data["project"]
    assert project["verification_level"] == "verified"
    assert project["generation_status"] == "complete"
    assert project["is_curated"] is True
    assert len(project["milestones"]) >= 3

    # Milestone 0 has valid quantitative checks
    m0 = project["milestones"][0]
    checks = m0["layer2_spec"]["checks"]
    assert len(checks) >= 2
    check_ids = [c["id"] for c in checks]
    assert "mse_eval" in check_ids
    assert "predictions_vector" in check_ids


def test_curated_orbital_simulation_verified(client):
    """Supported curated Orbital Gravity Simulation generates complete and verified."""
    resp = client.post("/api/project/generate", json={
        "prompt": "Build a planetary orbit simulation with gravity and energy conservation.",
        "difficulty": 5,
        "persona": "student"
    })
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["status"] == "success"

    project = data["project"]
    assert project["verification_level"] == "verified"
    assert project["generation_status"] == "complete"
    assert project["is_curated"] is True
    assert project["execution_mode"] == "browser_iframe"


# =====================================================================
# 2. Honest Reporting for Uncurated Topics in Offline Mode
# =====================================================================
def test_prompt_outside_curated_topics_offline_reports_unsupported(client):
    """Uncurated topics in offline mode must report unsupported_offline, NOT a fake success stub."""
    resp = client.post("/api/project/generate", json={
        "prompt": "Build a balanced AVL Tree in Python",
        "difficulty": 6,
        "persona": "student",
        "domain": "algorithms"
    })
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["status"] == "unsupported_offline"
    assert data["reason"] == "unsupported_domain_offline"
    assert data["verification_status"] == "unable_to_verify"
    assert "Build a balanced AVL Tree in Python" in data["unsupported_topic"]
    assert len(data["limitations"]) > 0
    assert len(data["suggested_curated_topics"]) >= 2
    assert "project" not in data


def test_another_uncurated_topic_offline_truthful(client):
    """Complex econometrics/ML prompt in offline mode is truthfully flagged."""
    resp = client.post("/api/project/generate", json={
        "prompt": "Estimate macroeconomic inflation using machine learning and time series",
        "difficulty": 7,
        "persona": "student"
    })
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["status"] == "unsupported_offline"
    assert data["verification_status"] == "unable_to_verify"


# =====================================================================
# 3. Rejection of False-Success in Verification (Layer 2)
# =====================================================================
def test_empty_verification_criteria_cannot_pass(client):
    """A milestone with zero checks must NOT report passed: True."""
    # Create draft project with empty checks
    gen = CurriculumGenerator()
    draft = gen.generate_project("Sorting algorithm visualizer", allow_unverified_draft=True)
    assert draft["status"] == "partial"
    proj = draft["project"]
    from persistence_manager import PersistenceManager
    PersistenceManager.save_project(proj)

    m_id = proj["milestones"][0]["id"]
    resp = client.post("/api/verify/layer2", json={
        "project_id": proj["id"],
        "milestone_id": m_id,
        "evaluation_payload": {"anything": True}
    })
    assert resp.status_code == 200
    ver = resp.get_json()["verification"]
    assert ver["passed"] is False
    assert ver["status"] == "unverified"
    assert "No quantitative verification criteria are defined" in ver["diagnostics"]


def test_unverified_placeholder_check_cannot_pass():
    """Unverified placeholder check must return passed: False and unable_to_verify."""
    check_spec = {
        "id": "dummy_check",
        "type": "unverified_placeholder",
        "name": "Placeholder Test"
    }
    result = QuantitativeVerifier.evaluate_check(check_spec, {"dummy_check": True})
    assert result["passed"] is False
    assert result["status"] == "unable_to_verify"


def test_boolean_assertion_missing_field_fails():
    """Boolean assertion check with missing payload field must fail."""
    check_spec = {
        "id": "status_check",
        "type": "boolean_assertion",
        "payload_key": "status_ok",
        "expected": True
    }
    # Payload is completely missing the required key
    result = QuantitativeVerifier.evaluate_check(check_spec, {})
    assert result["passed"] is False
    assert result["status"] == "fail"
    assert "Missing required payload field" in result["diagnostic"]


def test_deliberate_mathematical_failure_fails_layer2(client):
    """Deliberately wrong slope or divergent MSE must fail Layer 2."""
    gen_resp = client.post("/api/project/generate", json={
        "prompt": "Build a linear regression model from scratch using gradient descent.",
        "difficulty": 5
    })
    project = gen_resp.get_json()["project"]
    p_id = project["id"]
    m_id = project["milestones"][0]["id"]

    # Wrong MSE (999.0 vs expected 4.0) and wrong predictions
    fail_payload = {
        "test_mse": 999.0,
        "test_preds": [100.0, 200.0, 300.0]
    }
    resp = client.post("/api/verify/layer2", json={
        "project_id": p_id,
        "milestone_id": m_id,
        "evaluation_payload": fail_payload
    })
    assert resp.status_code == 200
    ver = resp.get_json()["verification"]
    assert ver["passed"] is False
    assert ver["status"] == "fail"
    assert any(c["passed"] is False for c in ver["checks"])


def test_deliberate_energy_violation_fails():
    """Severe Hamiltonian energy drift must fail conservation verification."""
    result = QuantitativeVerifier.verify_energy_conservation(initial_energy=100.0, final_energy=250.0, tolerance=0.05)
    assert result["passed"] is False
    assert result["drift_percentage"] > 100.0


# =====================================================================
# 4. Rejection of False-Success in Conceptual Understanding (Layer 3)
# =====================================================================
def test_layer3_eliminates_25_word_cheat_loophole(client):
    """A 30-word response containing zero required concepts must FAIL Layer 3."""
    gen_resp = client.post("/api/project/generate", json={
        "prompt": "Build a linear regression model from scratch using gradient descent.",
        "difficulty": 5
    })
    project = gen_resp.get_json()["project"]
    p_id = project["id"]
    m_id = project["milestones"][0]["id"]

    # 30 words of completely irrelevant grocery list text (previously passed due to >= 25 words check)
    bogus_25_word_response = (
        "I went to the supermarket yesterday afternoon and bought three fresh red apples, "
        "two ripe yellow bananas, a gallon of whole milk, and some delicious sourdough bread for breakfast tomorrow morning."
    )
    assert len(bogus_25_word_response.split()) >= 25

    resp = client.post("/api/verify/layer3", json={
        "project_id": p_id,
        "milestone_id": m_id,
        "learner_response": bogus_25_word_response
    })
    assert resp.status_code == 200
    ass = resp.get_json()["assessment"]
    assert ass["passed"] is False
    assert ass["outcome"] == "gap_identified"


def test_layer3_accepts_genuine_conceptual_explanation(client):
    """A response that explains the actual mathematical concepts passes Layer 3."""
    gen_resp = client.post("/api/project/generate", json={
        "prompt": "Build a linear regression model from scratch using gradient descent.",
        "difficulty": 5
    })
    project = gen_resp.get_json()["project"]
    p_id = project["id"]
    m_id = project["milestones"][0]["id"]

    genuine_response = (
        "Squaring prediction errors ensures that negative residuals cancel positive ones, "
        "penalizes larger errors more heavily, and keeps the loss function differentiable everywhere."
    )
    resp = client.post("/api/verify/layer3", json={
        "project_id": p_id,
        "milestone_id": m_id,
        "learner_response": genuine_response
    })
    assert resp.status_code == 200
    ass = resp.get_json()["assessment"]
    assert ass["passed"] is True
    assert ass["outcome"] == "mastered"


# =====================================================================
# 5. Dual-Mode Contract Preservation for Unverified Draft
# =====================================================================
def test_unverified_draft_project_dual_mode_contract(generator):
    """When an unverified draft is generated, it contains dual-mode metadata but no dummy checks."""
    res = generator.generate_project("Numerical ODE Solver in Python", difficulty=5, allow_unverified_draft=True)
    assert res["status"] == "partial"
    project = res["project"]
    assert project["verification_level"] == "unverified_draft"
    assert project["generation_status"] == "partial"

    # Dual-mode overview contract
    assert "overview" in project
    assert "what_building" in project["overview"]
    assert "prerequisites" in project["overview"]

    # Dual-mode milestone contract
    for m in project["milestones"]:
        assert "task_brief" in m
        assert "concept_layers" in m
        assert len(m["concept_layers"]) == 5
        assert "code_context" in m
        assert "developer_notes" in m
        # Verification criteria must be empty, not fake passing checks
        assert len(m["layer2_spec"].get("checks", [])) == 0
        assert m["layer2_spec"].get("verification_status") == "unable_to_verify"
