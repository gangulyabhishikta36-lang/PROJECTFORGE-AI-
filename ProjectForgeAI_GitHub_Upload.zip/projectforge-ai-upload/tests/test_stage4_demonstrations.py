"""
tests/test_stage4_demonstrations.py
===================================
End-to-End Demonstration Suite for Stage 4 ProjectForge AI:
Tests 4 representative project types across two distinct difficulty levels
(Level 3 Undergraduate Introductory vs Level 8 Rigorous Graduate):

1. Project A (Mathematics): Newton-Raphson & Taylor Series Derivation
2. Project B (Econometrics/Statistics): OLS & Ridge Regression with Gauss-Markov Diagnostics
3. Project C (Software Engineering): Self-Balancing AVL Tree with Logarithmic Bounds
4. Project D (Simulation/Physics): Symplectic Velocity Verlet vs Forward Euler Orbital Dynamics

Negative Tests:
- Deliberate formula and syntax errors
- Verification failure detection
- Iterative repair engine resolution
"""

import pytest
from blueprint_engine import BlueprintEngine, KnowledgeRetrievalContract
from knowledge_retriever import KnowledgeRetriever
from project_generator import (
    GenerationOrchestrator,
    VerificationIntegrator,
    VerificationStatus,
    ProjectRepairEngine,
    QualityStatus
)


# =============================================================================
# PROJECT A: MATHEMATICAL DERIVATION (LEVEL 3 vs LEVEL 8)
# =============================================================================

def test_demonstration_project_a_mathematics_level_3():
    orchestrator = GenerationOrchestrator()
    bp = BlueprintEngine.create_blueprint("Newton-Raphson root finding and Taylor series expansion", difficulty=3)
    project = orchestrator.generate(bp, difficulty=3)

    assert project["profile"]["level"] == 3
    assert project["profile"]["scaffolding_pct"] == 65
    assert project["profile"]["numerical_tolerance"] == 1e-4

    code_files = {f: art["reference"] for f, art in project["artifacts"].items()}
    criteria = project["verification_criteria"]

    # Verify each milestone
    for m in project["milestones"]:
        vres = VerificationIntegrator.verify_milestone(m["id"], code_files, criteria)
        assert vres["status"] == VerificationStatus.PASSED, f"Milestone {m['id']} failed: {vres['message']}"

    assert project["quality_report"]["certification_status"] == QualityStatus.CERTIFIED_COMPLETE


def test_demonstration_project_a_mathematics_level_8():
    orchestrator = GenerationOrchestrator()
    bp = BlueprintEngine.create_blueprint("Newton-Raphson root finding and Taylor series expansion", difficulty=8)
    project = orchestrator.generate(bp, difficulty=8)

    assert project["profile"]["level"] == 8
    assert project["profile"]["scaffolding_pct"] == 20
    assert project["profile"]["numerical_tolerance"] == 1e-8

    code_files = {f: art["reference"] for f, art in project["artifacts"].items()}
    criteria = project["verification_criteria"]

    for m in project["milestones"]:
        vres = VerificationIntegrator.verify_milestone(m["id"], code_files, criteria)
        assert vres["status"] == VerificationStatus.PASSED, f"Milestone {m['id']} failed: {vres['message']}"

    assert project["quality_report"]["certification_status"] == QualityStatus.CERTIFIED_COMPLETE


# =============================================================================
# PROJECT B: ECONOMETRICS & STATISTICS (LEVEL 3 vs LEVEL 8)
# =============================================================================

def test_demonstration_project_b_econometrics_level_3():
    orchestrator = GenerationOrchestrator()
    bp = BlueprintEngine.create_blueprint("Gauss-Markov OLS and Ridge regression parameter estimation", difficulty=3)
    project = orchestrator.generate(bp, difficulty=3)

    assert project["profile"]["level"] == 3
    assert project["profile"]["scaffolding_pct"] == 65

    code_files = {f: art["reference"] for f, art in project["artifacts"].items()}
    criteria = project["verification_criteria"]

    for m in project["milestones"]:
        vres = VerificationIntegrator.verify_milestone(m["id"], code_files, criteria)
        assert vres["status"] == VerificationStatus.PASSED, f"Milestone {m['id']} failed: {vres['message']}"

    assert project["quality_report"]["certification_status"] == QualityStatus.CERTIFIED_COMPLETE


def test_demonstration_project_b_econometrics_level_8():
    orchestrator = GenerationOrchestrator()
    bp = BlueprintEngine.create_blueprint("Gauss-Markov OLS and Ridge regression parameter estimation", difficulty=8)
    project = orchestrator.generate(bp, difficulty=8)

    assert project["profile"]["level"] == 8
    assert project["profile"]["scaffolding_pct"] == 20

    code_files = {f: art["reference"] for f, art in project["artifacts"].items()}
    criteria = project["verification_criteria"]

    for m in project["milestones"]:
        vres = VerificationIntegrator.verify_milestone(m["id"], code_files, criteria)
        assert vres["status"] == VerificationStatus.PASSED, f"Milestone {m['id']} failed: {vres['message']}"

    assert project["quality_report"]["certification_status"] == QualityStatus.CERTIFIED_COMPLETE


# =============================================================================
# PROJECT C: SOFTWARE ENGINEERING (LEVEL 3 vs LEVEL 8)
# =============================================================================

def test_demonstration_project_c_software_avl_tree_level_3():
    orchestrator = GenerationOrchestrator()
    bp = BlueprintEngine.create_blueprint("Production self-balancing AVL Tree in Python", difficulty=3)
    project = orchestrator.generate(bp, difficulty=3)

    assert project["profile"]["level"] == 3
    assert "node.py" in project["artifacts"]
    assert "rotator.py" in project["artifacts"]
    assert "avl_tree.py" in project["artifacts"]

    code_files = {f: art["reference"] for f, art in project["artifacts"].items()}
    criteria = project["verification_criteria"]

    for m in project["milestones"]:
        vres = VerificationIntegrator.verify_milestone(m["id"], code_files, criteria)
        assert vres["status"] == VerificationStatus.PASSED, f"Milestone {m['id']} failed: {vres['message']}"

    assert project["quality_report"]["certification_status"] == QualityStatus.CERTIFIED_COMPLETE


def test_demonstration_project_c_software_avl_tree_level_8():
    orchestrator = GenerationOrchestrator()
    bp = BlueprintEngine.create_blueprint("Production self-balancing AVL Tree in Python", difficulty=8)
    project = orchestrator.generate(bp, difficulty=8)

    assert project["profile"]["level"] == 8
    assert project["profile"]["scaffolding_pct"] == 20

    code_files = {f: art["reference"] for f, art in project["artifacts"].items()}
    criteria = project["verification_criteria"]

    for m in project["milestones"]:
        vres = VerificationIntegrator.verify_milestone(m["id"], code_files, criteria)
        assert vres["status"] == VerificationStatus.PASSED, f"Milestone {m['id']} failed: {vres['message']}"

    assert project["quality_report"]["certification_status"] == QualityStatus.CERTIFIED_COMPLETE


# =============================================================================
# PROJECT D: PHYSICS & SIMULATION (LEVEL 3 vs LEVEL 8)
# =============================================================================

def test_demonstration_project_d_physics_orbit_level_3():
    orchestrator = GenerationOrchestrator()
    bp = BlueprintEngine.create_blueprint("Planetary orbit simulation with symplectic Verlet vs Euler", difficulty=3)
    project = orchestrator.generate(bp, difficulty=3)

    assert project["profile"]["level"] == 3
    assert "physics.py" in project["artifacts"]
    assert "integrators.py" in project["artifacts"]

    code_files = {f: art["reference"] for f, art in project["artifacts"].items()}
    criteria = project["verification_criteria"]

    for m in project["milestones"]:
        vres = VerificationIntegrator.verify_milestone(m["id"], code_files, criteria)
        assert vres["status"] == VerificationStatus.PASSED, f"Milestone {m['id']} failed: {vres['message']}"

    assert project["quality_report"]["certification_status"] == QualityStatus.CERTIFIED_COMPLETE


def test_demonstration_project_d_physics_orbit_level_8():
    orchestrator = GenerationOrchestrator()
    bp = BlueprintEngine.create_blueprint("Planetary orbit simulation with symplectic Verlet vs Euler", difficulty=8)
    project = orchestrator.generate(bp, difficulty=8)

    assert project["profile"]["level"] == 8
    assert project["profile"]["scaffolding_pct"] == 20

    code_files = {f: art["reference"] for f, art in project["artifacts"].items()}
    criteria = project["verification_criteria"]

    for m in project["milestones"]:
        vres = VerificationIntegrator.verify_milestone(m["id"], code_files, criteria)
        assert vres["status"] == VerificationStatus.PASSED, f"Milestone {m['id']} failed: {vres['message']}"

    assert project["quality_report"]["certification_status"] == QualityStatus.CERTIFIED_COMPLETE


# =============================================================================
# NEGATIVE TESTS & AUTOMATED REPAIR
# =============================================================================

def test_negative_orbital_energy_blowup_in_euler():
    """
    Negative test: explicitly confirms that Forward Euler FAILS strict energy conservation
    while Symplectic Verlet PASSES.
    """
    from project_generator import ExecutionEnvironmentManager

    test_code = """
import math
from physics import TwoBodyPhysics
from integrators import OrbitalIntegrators

def evaluate():
    v_circ = (TwoBodyPhysics.G * TwoBodyPhysics.M_STAR / 10.0) ** 0.5
    
    # 1. Verlet
    xv, yv, vxv, vyv = 10.0, 0.0, 0.0, v_circ
    e0_v = TwoBodyPhysics.compute_total_energy(xv, yv, vxv, vyv)
    for _ in range(500):
        xv, yv, vxv, vyv = OrbitalIntegrators.step_velocity_verlet(xv, yv, vxv, vyv, 0.01)
    drift_v = abs((TwoBodyPhysics.compute_total_energy(xv, yv, vxv, vyv) - e0_v) / e0_v)

    # 2. Euler
    xe, ye, vxe, vye = 10.0, 0.0, 0.0, v_circ
    e0_e = TwoBodyPhysics.compute_total_energy(xe, ye, vxe, vye)
    for _ in range(500):
        xe, ye, vxe, vye = OrbitalIntegrators.step_forward_euler(xe, ye, vxe, vye, 0.01)
    drift_e = abs((TwoBodyPhysics.compute_total_energy(xe, ye, vxe, vye) - e0_e) / e0_e)

    return {"verlet_drift": drift_v, "euler_drift": drift_e}
"""
    orchestrator = GenerationOrchestrator()
    bp = BlueprintEngine.create_blueprint("Planetary orbit simulation with symplectic Verlet vs Euler", difficulty=5)
    project = orchestrator.generate(bp, difficulty=5)

    code_files = {f: art["reference"] for f, art in project["artifacts"].items()}
    code_files["eval.py"] = test_code

    res = ExecutionEnvironmentManager.execute_in_memory(code_files, entry_point="eval.py")
    assert res["success"] is True
    eval_res = res["env"]["evaluate"]()

    # Verlet drift must be bounded (< 0.005)
    assert eval_res["verlet_drift"] < 0.005
    # Forward Euler drift is orders of magnitude larger (> 10^6 times Verlet drift)
    assert eval_res["euler_drift"] > 0.005
    assert eval_res["euler_drift"] > 1000.0 * eval_res["verlet_drift"]


def test_negative_deliberate_error_and_repair_loop():
    """
    Negative test: injects deliberate bug into reference solution, confirms milestone failure,
    triggers ProjectRepairEngine, and verifies recovery.
    """
    orchestrator = GenerationOrchestrator()
    bp = BlueprintEngine.create_blueprint("Newton-Raphson root finding in calculus", difficulty=5)
    project = orchestrator.generate(bp, difficulty=5)

    # Inject deliberate ZeroDivisionError bug into solver
    original_solver = project["artifacts"]["solver.py"]["reference"]
    broken_solver = original_solver.replace("step = fx / dfx", "step = fx / 0.0")
    project["artifacts"]["solver.py"]["reference"] = broken_solver

    code_files = {f: art["reference"] for f, art in project["artifacts"].items()}
    m2_id = project["milestones"][1]["id"]

    # 1. Milestone MUST fail due to deliberate bug
    failed_check = VerificationIntegrator.verify_milestone(m2_id, code_files, project["verification_criteria"])
    assert failed_check["status"] == VerificationStatus.FAILED

    # 2. Run Repair Engine
    repair_res = ProjectRepairEngine.diagnose_and_repair(project, m2_id)
    assert repair_res["success"] is True
    assert repair_res["final_status"] == VerificationStatus.PASSED
    assert len(repair_res["repair_history"]) >= 1
