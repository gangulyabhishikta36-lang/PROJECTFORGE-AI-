"""
test_e2e_linear_regression.py
=============================
Automated End-to-End Acceptance Test for ProjectForge AI.
Simulates the complete 16-step learner workflow specified in Section 11:
1. User submits prompt at difficulty 5.
2. Backend validates & generates structured project.
3. Milestones & starter files are structured.
4. Learner submits intentionally incorrect gradient/loss calculation.
5. Layer 2 detects the discrepancy and returns failed criteria.
6. Learner requests Socratic hint from embedded tutor.
7. Tutor receives milestone context and delivers Tier 1 guidance.
8. Learner fixes the implementation with correct numerical values.
9. Layer 2 verifies correctness and passes.
10. Learner answers Layer 3 conceptual transfer question.
11. System records mastery separately from code correctness.
12. Learner saves progress and exports project ZIP.
13. Learner reloads project and saved progress is verified intact.
14. Tests failure resilience (unavailable provider, malformed input).
"""

import pytest
import io
import zipfile
from app import app


@pytest.fixture
def client():
    app.config["TESTING"] = True
    with app.test_client() as client:
        yield client


def test_complete_linear_regression_e2e_workflow(client):
    prompt_text = "Build a linear regression model from scratch using gradient descent."

    # Step 1 & 2: Submit prompt at difficulty 5
    gen_resp = client.post("/api/project/generate", json={
        "prompt": prompt_text,
        "difficulty": 5,
        "persona": "student",
        "domain": "auto"
    })
    assert gen_resp.status_code == 200
    gen_data = gen_resp.get_json()
    assert gen_data["status"] == "success"

    project = gen_data["project"]
    project_id = project["id"]
    milestones = project["milestones"]
    files = project["files"]

    assert len(milestones) >= 3
    assert len(files) >= 1
    m1 = milestones[0]
    m1_id = m1["id"]

    # Step 3: Verify initial state
    assert project["difficulty_profile"]["master_difficulty"] == 5
    assert project["difficulty_profile"]["conceptual"] == 5

    # Step 4 & 5: Learner submits intentionally incorrect calculation to Layer 2
    incorrect_payload = {
        "test_mse": 99.8,        # Expected is 4.0
        "test_preds": [10.0, 20.0, 30.0]
    }
    fail_verify_resp = client.post("/api/verify/layer2", json={
        "project_id": project_id,
        "milestone_id": m1_id,
        "evaluation_payload": incorrect_payload
    })
    assert fail_verify_resp.status_code == 200
    fail_res = fail_verify_resp.get_json()["verification"]
    assert fail_res["passed"] is False
    assert fail_res["status"] == "fail"
    # Verify diagnostic feedback is descriptive
    assert any("Failed" in c["diagnostic"] for c in fail_res["checks"])

    # Step 6 & 7: Learner asks tutor for a conceptual Socratic hint (Tier 1)
    tutor_resp = client.post("/api/tutor/message", json={
        "project_id": project_id,
        "milestone_id": m1_id,
        "message": "Why is my MSE loss not matching the expected value?",
        "hint_tier": 1,
        "code_context": files[0]["content"],
        "error_context": fail_res["diagnostics"]
    })
    assert tutor_resp.status_code == 200
    tutor_data = tutor_resp.get_json()["response"]
    assert tutor_data["hint_tier"] == 1
    assert "MSE" in tutor_data["message"] or "loss" in tutor_data["message"].lower()

    # Step 8 & 9: Learner fixes implementation and submits correct calculations
    correct_payload = {
        "test_mse": 4.0,
        "test_preds": [2.0, 4.0, 6.0]
    }
    pass_verify_resp = client.post("/api/verify/layer2", json={
        "project_id": project_id,
        "milestone_id": m1_id,
        "evaluation_payload": correct_payload
    })
    assert pass_verify_resp.status_code == 200
    pass_res = pass_verify_resp.get_json()["verification"]
    assert pass_res["passed"] is True
    assert pass_res["status"] == "pass"

    # Step 10 & 11: Learner completes Layer 3 Conceptual Transfer Question
    l3_resp = client.post("/api/verify/layer3", json={
        "project_id": project_id,
        "milestone_id": m1_id,
        "learner_response": "We square the errors to penalize larger errors disproportionately, ensure the function is smooth and differentiable, and eliminate negative signs."
    })
    assert l3_resp.status_code == 200
    l3_assessment = l3_resp.get_json()["assessment"]
    assert l3_assessment["passed"] is True
    assert l3_assessment["outcome"] == "mastered"

    # Step 12: Learner modifies working file and saves progress
    working_files = [
        {"name": "regression.py", "language": "python", "content": "# Completed Milestone 1\ncompute_mse_loss = lambda yt, yp: sum((yp[i]-yt[i])**2 for i in range(len(yt)))/len(yt)"}
    ]
    save_resp = client.post(f"/api/project/{project_id}/save", json={
        "files": working_files,
        "active_milestone_id": "m2"
    })
    assert save_resp.status_code == 200

    # Step 13: Learner reloads project and verifies saved state
    load_resp = client.get(f"/api/project/{project_id}")
    assert load_resp.status_code == 200
    loaded_proj = load_resp.get_json()["project"]
    assert loaded_proj["files"][0]["content"] == working_files[0]["content"]
    assert loaded_proj["active_milestone_id"] == "m2"
    assert m1_id in loaded_proj.get("mastery_assessments", {})

    # Step 14: Learner exports project ZIP
    export_resp = client.get(f"/api/project/{project_id}/export")
    assert export_resp.status_code == 200
    zip_buf = io.BytesIO(export_resp.data)
    with zipfile.ZipFile(zip_buf, "r") as zf:
        contents = zf.namelist()
        assert "regression.py" in contents
        assert "PROJECT_MASTERY_REPORT.md" in contents
        report = zf.read("PROJECT_MASTERY_REPORT.md").decode("utf-8")
        assert "[Mastered]" in report

    # Step 15 & 16: Failure resilience tests
    # Malformed Layer 3 response (empty / too short)
    bad_l3 = client.post("/api/verify/layer3", json={
        "project_id": project_id,
        "milestone_id": m1_id,
        "learner_response": "short"
    })
    assert bad_l3.status_code == 422

    # Nonexistent project lookup
    ghost_resp = client.get("/api/project/proj_nonexistent_xyz")
    assert ghost_resp.status_code == 404
