"""
tests/test_stage2_ambiguity_and_parallel_domains.py
===================================================
Automated regression & capability test suite for Phase 2:
1. Blocking Ambiguity State Machine:
   - Ambiguous prompts block generation (status: REQUIRES_CLARIFICATION).
   - Blueprint is not created when blocked.
   - Clarification options, questions, and tradeoffs are presented.
   - No silent resolution via default_assumption.
   - Clarification response resumes workflow to READY_FOR_BLUEPRINT -> BLUEPRINT_VALIDATED.
   - Explicit user resolution is permanently embedded in provenance.
2. Parallel Domain Specifications:
   - Parallel domains decomposed with quantitative relevance, concepts, methods, and verification types.
   - No forced primary/supporting hierarchy.
3. Unfamiliar & Interdisciplinary Topics:
   - Double pendulum chaotic dynamics
   - SIR epidemiological contagion model
   - B-Tree database storage engine
   - Quantum teleportation circuit
   - Invariant verification checks synthesized without unverified_placeholder stubs.
4. Flask Clarification Endpoints:
   - POST /api/clarification/start
   - POST /api/clarification/respond
   - POST /api/project/blueprint with enforce_clarification=True
"""

import pytest
from app import app
from blueprint_engine import (
    BlueprintEngine,
    AmbiguityStateMachine,
    WorkflowState,
    AmbiguityClarificationRequiredException,
    DomainSpec,
)


@pytest.fixture
def client():
    app.config["TESTING"] = True
    with app.test_client() as client:
        yield client


# =====================================================================
# 1. Blocking Ambiguity State Machine
# =====================================================================

def test_ambiguous_prompt_blocks_downstream_generation():
    """Verify that a prompt containing ambiguous terms blocks generation at REQUIRES_CLARIFICATION."""
    prompt = "Simulate market equilibrium under taxation and policy shifts"
    session = AmbiguityStateMachine.start_session(prompt, enforce_clarification=True)

    assert session.state == WorkflowState.REQUIRES_CLARIFICATION
    assert len(session.unresolved_ambiguities) >= 1
    assert session.blueprint is None
    assert session.to_dict()["can_proceed_to_generation"] is False
    assert "equilibrium" in [amb["term"] for amb in session.unresolved_ambiguities]
    assert session.clarification_question != ""


def test_clarification_response_resumes_workflow():
    """Verify that providing an explicit learner choice resolves ambiguity and synthesizes blueprint."""
    prompt = "Simulate market equilibrium under taxation and policy shifts"
    session = AmbiguityStateMachine.start_session(prompt, enforce_clarification=True)
    assert session.state == WorkflowState.REQUIRES_CLARIFICATION

    # Learner explicitly chooses microeconomics interpretation
    user_choices = {"equilibrium": "Competitive market clearing price and quantity"}
    resumed = AmbiguityStateMachine.resolve_clarification(session.session_id, user_choices)

    assert resumed.state == WorkflowState.BLUEPRINT_VALIDATED
    assert resumed.blueprint is not None
    assert resumed.to_dict()["can_proceed_to_generation"] is True
    assert len(resumed.unresolved_ambiguities) == 0

    # Verify provenance embeds the explicit user resolution, not a silent default
    bp = resumed.blueprint
    prov = bp["provenance"]
    assert "resolved_clarifications" in prov["learner_supplied"]
    assert "equilibrium" in prov["learner_supplied"]["resolved_clarifications"]
    res_entry = prov["learner_supplied"]["resolved_clarifications"]["equilibrium"]
    assert res_entry["user_response"] == "Competitive market clearing price and quantity"


def test_multiple_ambiguities_partial_resolution_remains_blocked():
    """If prompt has multiple ambiguities ('equilibrium' and 'stability'), resolving only one keeps workflow blocked."""
    prompt = "Evaluate equilibrium state and verify stability under stochastic perturbations"
    session = AmbiguityStateMachine.start_session(prompt, enforce_clarification=True)
    assert session.state == WorkflowState.REQUIRES_CLARIFICATION
    terms = [amb["term"] for amb in session.unresolved_ambiguities]
    assert "equilibrium" in terms
    assert "stability" in terms

    # Resolve only equilibrium
    partial_res = AmbiguityStateMachine.resolve_clarification(session.session_id, {"equilibrium": "economics"})
    assert partial_res.state == WorkflowState.REQUIRES_CLARIFICATION
    assert len(partial_res.unresolved_ambiguities) == 1
    assert partial_res.unresolved_ambiguities[0]["term"] == "stability"
    assert partial_res.blueprint is None


def test_enforce_clarification_exception_in_create_blueprint():
    """Calling create_blueprint with enforce_clarification=True raises exception on ambiguous prompts."""
    prompt = "Implement regression on financial assets"
    with pytest.raises(AmbiguityClarificationRequiredException) as exc_info:
        BlueprintEngine.create_blueprint(prompt, enforce_clarification=True)
    assert "unresolved ambiguous term" in str(exc_info.value)
    assert any(a["term"] == "regression" for a in exc_info.value.unresolved_ambiguities)


# =====================================================================
# 2. Parallel Domain Specifications
# =====================================================================

def test_parallel_domain_specifications_structure():
    """Verify that decompose_domains produces parallel DomainSpec objects with quantitative relevance."""
    prompt = "Investigate inflation dynamics using neural networks and numerical ODE integration"
    domains = BlueprintEngine.decompose_domains(prompt)

    assert isinstance(domains, list)
    assert len(domains) >= 2

    domain_ids = [d["id"] for d in domains]
    assert "economics" in domain_ids
    assert "machine_learning" in domain_ids

    for d in domains:
        assert "id" in d
        assert "name" in d
        assert 0.0 <= d["relevance"] <= 1.0
        assert isinstance(d["concepts"], list) and len(d["concepts"]) > 0
        assert isinstance(d["methods"], list) and len(d["methods"]) > 0
        assert isinstance(d["prerequisites"], list)
        assert isinstance(d["milestones"], list)
        assert "verification_type" in d


def test_interdisciplinary_blueprint_embeds_parallel_domains():
    """Blueprint embeds parallel domains in 'domains' field and validates successfully."""
    bp = BlueprintEngine.create_blueprint(
        "Model macroeconomic inflation using machine learning and differential calculus",
        difficulty=7
    )
    assert "domains" in bp
    assert len(bp["domains"]) >= 2
    val = BlueprintEngine.validate_blueprint(bp)
    assert val.is_valid is True


# =====================================================================
# 3. Unfamiliar & Interdisciplinary Objectives
# =====================================================================

def test_unfamiliar_epidemic_sir_contagion_model():
    """Prompt for epidemic SIR contagion model generates verified milestones, not placeholders."""
    bp = BlueprintEngine.create_blueprint(
        "Simulate epidemic SIR contagion disease transmission model on Canvas",
        difficulty=6
    )
    assert bp["project_objective"] != ""
    assert len(bp["milestones"]) >= 3
    assert bp["technical_architecture"]["language"] == "javascript_html"

    # Must NOT contain unverified_placeholder checks
    for m in bp["milestones"]:
        check_type = m.get("verification_check", {}).get("type")
        assert check_type != "unverified_placeholder"
        assert check_type in ("property_check", "unit_test_suite", "scalar_match", "energy_conservation")

    val = BlueprintEngine.validate_blueprint(bp)
    assert val.is_valid is True


def test_unfamiliar_lorenz_attractor_chaotic_dynamics():
    """Prompt for Lorenz attractor chaotic dynamics generates concrete differential equations and milestones."""
    bp = BlueprintEngine.create_blueprint(
        "Simulate Lorenz attractor chaotic dynamics and evaluate sensitivity to initial conditions",
        difficulty=8
    )
    assert bp["technical_architecture"]["language"] == "python"
    assert len(bp["milestones"]) >= 3
    for m in bp["milestones"]:
        assert m.get("verification_check", {}).get("type") != "unverified_placeholder"

    val = BlueprintEngine.validate_blueprint(bp)
    assert val.is_valid is True


def test_unfamiliar_btree_storage_engine():
    """Prompt for B-Tree storage engine generates systems algorithms milestones and unit tests."""
    bp = BlueprintEngine.create_blueprint(
        "Build an on-disk B-Tree index storage engine in Python",
        difficulty=7
    )
    parallel_domains = [d["id"] for d in bp["domains"]]
    assert "computer_science_algorithms" in parallel_domains
    val = BlueprintEngine.validate_blueprint(bp)
    assert val.is_valid is True


# =====================================================================
# 4. Flask Clarification Endpoints
# =====================================================================

def test_api_clarification_start_ambiguous(client):
    """POST /api/clarification/start with ambiguous prompt returns REQUIRES_CLARIFICATION."""
    resp = client.post("/api/clarification/start", json={
        "prompt": "Build an equilibrium price clearing engine",
        "difficulty": 5
    })
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["status"] == "success"
    session = data["session"]
    assert session["state"] == "REQUIRES_CLARIFICATION"
    assert session["session_id"] != ""
    assert len(session["unresolved_ambiguities"]) >= 1


def test_api_clarification_respond_resumes_workflow(client):
    """POST /api/clarification/respond provides explicit choice and returns validated blueprint."""
    # 1. Start session
    start_resp = client.post("/api/clarification/start", json={
        "prompt": "Build an equilibrium price clearing engine",
        "difficulty": 5
    })
    session_id = start_resp.get_json()["session"]["session_id"]

    # 2. Respond to ambiguity
    resp = client.post("/api/clarification/respond", json={
        "session_id": session_id,
        "responses": {"equilibrium": "Microeconomic supply and demand clearance"}
    })
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["status"] == "success"
    session = data["session"]
    assert session["state"] == "BLUEPRINT_VALIDATED"
    assert session["blueprint"] is not None
    assert session["can_proceed_to_generation"] is True


def test_api_project_blueprint_enforce_clarification_blocks(client):
    """POST /api/project/blueprint with enforce_clarification=True returns requires_clarification status."""
    resp = client.post("/api/project/blueprint", json={
        "prompt": "Model economic equilibrium and inflation stability",
        "difficulty": 5,
        "enforce_clarification": True
    })
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["status"] == "requires_clarification"
    assert "session_id" in data
    assert len(data["unresolved_ambiguities"]) >= 1
