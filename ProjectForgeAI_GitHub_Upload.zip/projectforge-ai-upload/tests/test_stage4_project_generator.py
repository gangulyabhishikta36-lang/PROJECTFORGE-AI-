"""
tests/test_stage4_project_generator.py
======================================
Comprehensive Unit & Integration Test Suite for Stage 4 Project Generator:
- ExecutionEnvironmentManager (AST syntax check, isolated execution)
- ArtifactRegistry & Import Graph Validation
- DifficultyCalibrator (Levels 1-10)
- ProjectTypeSelector (5 domain strategies)
- PedagogicalStructureGenerator (13 components, Dual-Mode Learning Views)
- VerificationIntegrator (scalar_match, property_check, unit_test_suite)
- ProjectRepairEngine (diagnostic repair loop)
- GenerationQualityController (12 criteria audit)
- Flask API Endpoints (/api/project/generate_v4, /repair, /verify_milestone)
"""

import pytest
import json
from blueprint_engine import BlueprintEngine, KnowledgeRetrievalContract
from knowledge_retriever import KnowledgeRetriever
from project_generator import (
    ExecutionEnvironmentManager,
    ArtifactRegistry,
    DifficultyCalibrator,
    ProjectTypeSelector,
    PedagogicalStructureGenerator,
    VerificationIntegrator,
    VerificationStatus,
    ProjectRepairEngine,
    GenerationQualityController,
    QualityStatus,
    GenerationOrchestrator,
    MathematicalDerivationStrategy,
    StatisticalEconometricStrategy,
    SoftwareEngineeringStrategy,
    MachineLearningDataScienceStrategy,
    PhysicsSimulationStrategy
)
from app import app


# -----------------------------------------------------------------------------
# 1. ExecutionEnvironmentManager Tests
# -----------------------------------------------------------------------------

def test_ast_syntax_validation():
    valid_code = "def add(a, b):\n    return a + b\n"
    is_valid, err = ExecutionEnvironmentManager.validate_syntax(valid_code)
    assert is_valid is True
    assert err is None

    invalid_code = "def broken(\n    return a +\n"
    is_valid, err = ExecutionEnvironmentManager.validate_syntax(invalid_code, "broken.py")
    assert is_valid is False
    assert "SyntaxError in broken.py" in err


def test_import_analysis():
    code = """
import math
import os.path
from solver import NewtonSolver
from utils.helpers import calc_norm
"""
    imports = ExecutionEnvironmentManager.analyze_imports(code)
    assert "math" in imports
    assert "os.path" in imports
    assert "solver" in imports
    assert "utils.helpers" in imports


def test_in_memory_execution_capture():
    files = {
        "helper.py": "def multiply(x, y):\n    return x * y\n",
        "main.py": "from helper import multiply\nprint('Result is', multiply(6, 7))\n"
    }
    res = ExecutionEnvironmentManager.execute_in_memory(files, entry_point="main.py")
    assert res["success"] is True
    assert res["exit_code"] == 0
    assert "Result is 42" in res["stdout"]
    assert res["stderr"] == ""
    assert res["runtime_ms"] > 0.0


def test_execution_captures_runtime_exceptions():
    files = {
        "main.py": "x = 10 / 0\n"
    }
    res = ExecutionEnvironmentManager.execute_in_memory(files, entry_point="main.py")
    assert res["success"] is False
    assert res["exit_code"] == 1
    assert "ZeroDivisionError" in res["stderr"]
    assert res["error_stage"] == "runtime_execution"


# -----------------------------------------------------------------------------
# 2. ArtifactRegistry & Import Graph Tests
# -----------------------------------------------------------------------------

def test_artifact_registry_detects_unresolved_imports():
    reg = ArtifactRegistry()
    reg.register_artifact("main.py", "import non_existent_pkg\nprint('hi')", "source", "reference", "main")
    ok, errors = reg.validate_import_graph()
    assert ok is False
    assert any("non_existent_pkg" in e for e in errors)


def test_artifact_registry_validates_connected_modules():
    reg = ArtifactRegistry()
    reg.register_artifact("node.py", "class Node:\n    pass\n", "source", "reference", "node")
    reg.register_artifact("tree.py", "from node import Node\nclass Tree:\n    pass\n", "source", "reference", "tree")
    ok, errors = reg.validate_import_graph()
    assert ok is True
    assert len(errors) == 0


# -----------------------------------------------------------------------------
# 3. DifficultyCalibrator Tests
# -----------------------------------------------------------------------------

def test_difficulty_calibration_gradient():
    p1 = DifficultyCalibrator.get_profile(1)
    p3 = DifficultyCalibrator.get_profile(3)
    p8 = DifficultyCalibrator.get_profile(8)
    p10 = DifficultyCalibrator.get_profile(10)

    # Scaffolding decreases as difficulty increases
    assert p1["scaffolding_pct"] > p3["scaffolding_pct"] > p8["scaffolding_pct"] > p10["scaffolding_pct"]
    assert p1["scaffolding_pct"] == 85
    assert p10["scaffolding_pct"] == 5

    # Numerical tolerances tighten
    assert p1["numerical_tolerance"] >= p3["numerical_tolerance"] >= p8["numerical_tolerance"] >= p10["numerical_tolerance"]
    assert p1["numerical_tolerance"] == 1e-2
    assert p10["numerical_tolerance"] == 1e-12


# -----------------------------------------------------------------------------
# 4. ProjectTypeSelector Tests
# -----------------------------------------------------------------------------

def test_strategy_selection_across_domains():
    bp_math = {"domain_roles": {"primary": "mathematics"}, "raw_prompt": "Derive Newton-Raphson convergence"}
    bp_econ = {"domain_roles": {"primary": "economics"}, "raw_prompt": "Gauss-Markov OLS and Ridge regression"}
    bp_algo = {"domain_roles": {"primary": "algorithms"}, "raw_prompt": "Self-balancing AVL Tree"}
    bp_ml = {"domain_roles": {"primary": "machine_learning"}, "raw_prompt": "Linear regression gradient descent"}
    bp_phys = {"domain_roles": {"primary": "simulation"}, "raw_prompt": "Gravitational orbit Verlet vs Euler"}

    assert isinstance(ProjectTypeSelector.select_strategy(bp_math), MathematicalDerivationStrategy)
    assert isinstance(ProjectTypeSelector.select_strategy(bp_econ), StatisticalEconometricStrategy)
    assert isinstance(ProjectTypeSelector.select_strategy(bp_algo), SoftwareEngineeringStrategy)
    assert isinstance(ProjectTypeSelector.select_strategy(bp_ml), MachineLearningDataScienceStrategy)
    assert isinstance(ProjectTypeSelector.select_strategy(bp_phys), PhysicsSimulationStrategy)


# -----------------------------------------------------------------------------
# 5. PedagogicalStructureGenerator & Dual-Mode Views Tests
# -----------------------------------------------------------------------------

def test_pedagogical_structure_and_dual_mode_views():
    bp = BlueprintEngine.create_blueprint("Implement self-balancing AVL Tree", difficulty=5)
    evidence = {"evidence_records": [], "claims": [{"claim_id": "c1", "text": "AVL height is bounded"}], "conflicts": []}
    profile = DifficultyCalibrator.get_profile(5)

    strat = SoftwareEngineeringStrategy()
    spec = strat.generate_project_specification(bp, evidence, profile)
    payload = PedagogicalStructureGenerator.assemble_pedagogical_payload(spec, bp, evidence, profile)

    # Verify 13 pedagogical components exist
    assert "executive_summary" in payload
    assert "motivation" in payload
    assert "theory" in payload
    assert "assumptions" in payload
    assert "architecture" in payload
    assert "environment" in payload
    assert "milestones" in payload
    assert "artifacts" in payload
    assert "tutor_guidance" in payload
    assert "verification_criteria" in payload
    assert "failure_modes" in payload
    assert "extensions" in payload
    assert "traceability_ledger" in payload

    # Verify Dual-Mode workspace contracts
    dual = payload["dual_mode_views"]
    assert "guided_learning" in dual
    assert "developer_workspace" in dual

    guided = dual["guided_learning"]
    assert guided["mode"] == "guided_learning"
    assert len(guided["step_by_step_walkthrough"]) == len(payload["milestones"])

    dev = dual["developer_workspace"]
    assert dev["mode"] == "developer_workspace"
    assert "avl_tree.py" in dev["file_explorer"]
    assert "main.py" in dev["raw_code_files"]


# -----------------------------------------------------------------------------
# 6. VerificationIntegrator & Quality Controller Tests
# -----------------------------------------------------------------------------

def test_verification_integrator_scalar_and_tests():
    code_files = {
        "math_mod.py": "def get_error():\n    return 1e-5\n",
        "main.py": "from math_mod import get_error\ndef run_demonstration():\n    return {'root_error': get_error()}\n",
        "test_math.py": "from math_mod import get_error\ndef test_error_bound():\n    assert get_error() < 1e-4\n"
    }

    criteria = {
        "m1": {"type": "scalar_match", "metric": "root_error", "threshold": 1e-4},
        "m2": {"type": "unit_test_suite", "target_test": "test_math.py"}
    }

    res_m1 = VerificationIntegrator.verify_milestone("m1", code_files, criteria)
    assert res_m1["status"] == VerificationStatus.PASSED

    res_m2 = VerificationIntegrator.verify_milestone("m2", code_files, criteria)
    assert res_m2["status"] == VerificationStatus.PASSED


def test_generation_quality_controller_audits():
    orchestrator = GenerationOrchestrator()
    bp = BlueprintEngine.create_blueprint("Newton-Raphson root finding in calculus", difficulty=3)
    project = orchestrator.generate(bp, difficulty=3)

    qrep = project["quality_report"]
    assert qrep["composite_score"] >= 0.90
    assert qrep["certification_status"] == QualityStatus.CERTIFIED_COMPLETE
    assert qrep["criteria_scores"]["code_syntactical_validity"] == 1.0
    assert qrep["criteria_scores"]["reference_executability"] == 1.0


# -----------------------------------------------------------------------------
# 7. ProjectRepairEngine Tests
# -----------------------------------------------------------------------------

def test_repair_engine_fixes_failing_milestone():
    broken_solver = '''"""
solver.py
"""
class NewtonRaphsonSolver:
    def solve(self, f, df, x0):
        fx = f(x0)
        dfx = df(x0)
        # BUG: deliberate zero division
        step = fx / 0.0
        return {"root": x0 - step, "converged": True}
'''
    main_code = '''"""
main.py
"""
from solver import NewtonRaphsonSolver
def run_demonstration():
    solver = NewtonRaphsonSolver()
    res = solver.solve(lambda x: x**2 - 2, lambda x: 2*x, 1.0)
    return {"root_error": abs(res["root"] - 1.4142)}
'''
    project_data = {
        "artifacts": {
            "solver.py": {"reference": broken_solver, "type": "source"},
            "main.py": {"reference": main_code, "type": "source"}
        },
        "verification_criteria": {
            "m1": {"type": "scalar_match", "metric": "root_error", "threshold": 0.1}
        }
    }

    # Verify that initial milestone check fails
    initial_check = VerificationIntegrator.verify_milestone(
        "m1",
        {f: art["reference"] for f, art in project_data["artifacts"].items()},
        project_data["verification_criteria"]
    )
    assert initial_check["status"] == VerificationStatus.FAILED

    # Run repair engine
    repair_res = ProjectRepairEngine.diagnose_and_repair(project_data, "m1")
    assert repair_res["success"] is True
    assert len(repair_res["repair_history"]) > 0


# -----------------------------------------------------------------------------
# 8. Flask API Integration Tests
# -----------------------------------------------------------------------------

def test_api_generate_v4_and_verify():
    client = app.test_client()

    payload = {
        "prompt": "Rigorous planetary orbit simulation with symplectic Verlet",
        "difficulty": 4
    }
    resp = client.post("/api/project/generate_v4", json=payload)
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["status"] == "success"
    project = data["project"]
    proj_id = data["project_id"]

    assert "dual_mode_views" in project
    assert project["quality_report"]["certification_status"] in (
        QualityStatus.CERTIFIED_COMPLETE,
        QualityStatus.CONDITIONALLY_COMPLETE
    )

    # Test verify milestone endpoint
    m_resp = client.post("/api/project/verify_milestone", json={
        "project_id": proj_id,
        "milestone_id": project["milestones"][0]["id"]
    })
    assert m_resp.status_code == 200
    m_data = m_resp.get_json()
    assert m_data["status"] == "success"
    assert m_data["verification"]["status"] == VerificationStatus.PASSED

    # Test retrieve project from registry
    get_resp = client.get(f"/api/project/v4/{proj_id}")
    assert get_resp.status_code == 200
    assert get_resp.get_json()["project"]["id"] == proj_id
