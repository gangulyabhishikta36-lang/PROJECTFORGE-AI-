"""
tests/test_frontend_dual_mode.py
================================
Verifies that the Flask application serves the required Dual-Mode Workspace
DOM elements and that template integration meets all structural contracts.
"""

import pytest
from app import app


@pytest.fixture
def client():
    app.config["TESTING"] = True
    with app.test_client() as client:
        yield client


def test_dual_mode_dom_elements_present(client):
    response = client.get("/")
    assert response.status_code == 200
    html = response.data.decode("utf-8")

    # 1. Mode Switcher & Selection Modal
    assert 'id="header-mode-switcher"' in html
    assert 'id="btn-mode-guided"' in html
    assert 'id="btn-mode-dev"' in html
    assert 'id="modal-mode-select"' in html
    assert 'id="modal-select-guided"' in html
    assert 'id="modal-select-dev"' in html

    # 2. Guided Learning View Containers
    assert 'id="workspace-guided-view"' in html
    assert 'id="guided-overview-panel"' in html
    assert 'id="guided-active-panel"' in html
    assert 'id="concept-layers-container"' in html
    assert 'id="code-editor-guided"' in html
    assert 'id="btn-guided-run-sandbox"' in html
    assert 'id="guided-output-interpreted"' in html
    assert 'id="btn-guided-verify"' in html

    # 3. Developer Workspace View Containers
    assert 'id="workspace-dev-view"' in html
    assert 'id="code-editor"' in html
    assert 'id="dev-todo-list"' in html
    assert 'id="tab-btn-console"' in html
    assert 'id="tab-btn-preview"' in html
    assert 'id="tab-btn-tests"' in html
    assert 'id="tab-btn-inquiries"' in html
    assert 'id="tests-view"' in html
    assert 'id="inquiries-view"' in html

    # 4. KaTeX Math Assets
    assert 'katex.min.css' in html
    assert 'katex.min.js' in html


def test_generate_endpoint_dual_mode_contract(client):
    response = client.post(
        "/api/project/generate",
        json={
            "prompt": "Linear Regression with Gradient Descent from Scratch",
            "difficulty": 5,
            "persona": "student",
            "domain": "auto",
        },
    )
    assert response.status_code == 200
    data = response.get_json()
    assert data["status"] == "success"
    project = data["project"]

    # Check overview
    assert "overview" in project
    assert "what_building" in project["overview"]
    assert "what_you_will_learn" in project["overview"]
    assert "what_you_will_build" in project["overview"]
    assert "prerequisites" in project["overview"]

    # Check milestones dual-mode properties
    for m in project["milestones"]:
        assert "task_brief" in m
        assert "concept_layers" in m
        assert len(m["concept_layers"]) == 5
        assert "code_context" in m
        assert "developer_notes" in m

