"""
tests/test_dual_mode_contracts.py
=================================
Automated verification tests for Dual-Mode Learning Workspace metadata contracts:
1. Guided Learning metadata (overview, task_brief, 5 concept_layers, code_context).
2. Developer Workspace metadata (developer_notes, incomplete_sections, technical structure).
3. Universal coverage (both benchmark projects and arbitrary/generalized projects).
"""

import pytest
from curriculum_generator import CurriculumGenerator


@pytest.fixture
def generator():
    return CurriculumGenerator()


def test_linear_regression_dual_mode_metadata(generator):
    res = generator.generate_project("Linear Regression with Gradient Descent from Scratch", difficulty=5)
    assert res["status"] == "success"
    project = res["project"]

    # 1. Project-level Overview
    assert "overview" in project
    overview = project["overview"]
    assert "what_building" in overview
    assert "why_matters" in overview
    assert isinstance(overview.get("what_you_will_learn"), list) and len(overview["what_you_will_learn"]) > 0
    assert isinstance(overview.get("what_you_will_build"), list) and len(overview["what_you_will_build"]) > 0
    assert "prerequisites" in overview
    prereqs = overview["prerequisites"]
    assert isinstance(prereqs.get("essential"), list)
    assert isinstance(prereqs.get("helpful"), list)
    assert isinstance(prereqs.get("taught_here"), list)

    # 2. Milestones validation
    milestones = project.get("milestones", [])
    assert len(milestones) >= 3

    for m in milestones:
        # A. Task Brief (5-question framework)
        assert "task_brief" in m, f"Milestone {m.get('id')} missing task_brief"
        tb = m["task_brief"]
        assert "goal" in tb and len(tb["goal"]) > 0
        assert "why_matters" in tb and len(tb["why_matters"]) > 0
        assert isinstance(tb.get("concepts"), list) and len(tb["concepts"]) > 0
        assert isinstance(tb.get("instructions"), list) and len(tb["instructions"]) > 0
        assert "success_criteria" in tb and len(tb["success_criteria"]) > 0

        # B. 5-Layer Concept Explorer
        assert "concept_layers" in m, f"Milestone {m.get('id')} missing concept_layers"
        layers = m["concept_layers"]
        assert len(layers) == 5
        layer_levels = [l["level"] for l in layers]
        assert layer_levels == [1, 2, 3, 4, 5]
        layer_names = [l["name"] for l in layers]
        assert "Intuition" in layer_names[0]
        assert "Mathematical Foundation" in layer_names[1]
        assert "Derivation" in layer_names[2]
        assert "Implementation Link" in layer_names[3]
        assert "Advanced" in layer_names[4]

        # C. Contextual Code Guidance
        assert "code_context" in m, f"Milestone {m.get('id')} missing code_context"
        assert isinstance(m["code_context"], list) and len(m["code_context"]) > 0
        for cc in m["code_context"]:
            assert "name" in cc
            assert "purpose" in cc
            assert "inputs" in cc
            assert "outputs" in cc
            assert "math_link" in cc

        # D. Developer Notes
        assert "developer_notes" in m, f"Milestone {m.get('id')} missing developer_notes"
        dn = m["developer_notes"]
        assert "summary" in dn
        assert isinstance(dn.get("incomplete_sections"), list)
        for sec in dn["incomplete_sections"]:
            assert "function" in sec
            assert "status" in sec
            assert "requirement" in sec


def test_generalized_project_dual_mode_fallback(generator):
    # In offline mode, uncurated topic must truthfully report unsupported_offline rather than false success
    res = generator.generate_project("Build a balanced AVL Tree in Python", difficulty=6, domain="algorithms")
    assert res["status"] == "unsupported_offline"
    assert "suggested_curated_topics" in res
    assert res["verification_status"] == "unable_to_verify"

    # When explicit draft is requested, verify dual-mode metadata exists without dummy passing checks
    res_draft = generator.generate_project("Build a balanced AVL Tree in Python", difficulty=6, domain="algorithms", allow_unverified_draft=True)
    assert res_draft["status"] == "partial"
    project = res_draft["project"]
    assert project["verification_level"] == "unverified_draft"

    # Verify fallback ensures all keys exist
    assert "overview" in project
    assert "what_building" in project["overview"]
    assert "prerequisites" in project["overview"]

    milestones = project.get("milestones", [])
    assert len(milestones) > 0
    for m in milestones:
        assert "task_brief" in m
        assert "concept_layers" in m
        assert len(m["concept_layers"]) == 5
        assert "code_context" in m
        assert "developer_notes" in m
        # Verification criteria must NOT be fake passing assertions
        assert len(m["layer2_spec"].get("checks", [])) == 0
        assert m["layer2_spec"].get("verification_status") == "unable_to_verify"
