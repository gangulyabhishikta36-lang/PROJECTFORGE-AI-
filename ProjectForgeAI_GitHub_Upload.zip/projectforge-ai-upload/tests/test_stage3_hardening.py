"""
tests/test_stage3_hardening.py
==============================
Rigorous implementation-level verification for Stage 3 Integrity Hardening:
1. Content hashing integrity (raw hash, normalized hash, sensitivity, empty content rejection, truncation).
2. Excerpt-to-content traceability.
3. Multi-dimensional source evaluation (non-probabilistic qualitative scoring).
4. Claim status lifecycle (extracted -> source_supported -> independently_verified).
5. Deep SSRF protection with DNS resolution & redirect chain security.
6. Conflict detection distinguishing genuine contradictions from methodological/definitional differences.
7. Complete 7-stage traceability matrix integrity and bidirectional lookup.
"""

import pytest
import time
import hashlib
from blueprint_engine import BlueprintEngine
from knowledge_retriever import (
    KnowledgeRetriever,
    RetrievalStatus,
    SourceType,
    ClaimStatus,
    ConflictType,
    RetrievedDocument,
    EvidenceRecord,
    TechnicalClaim,
    ConflictReport,
    SourceEvaluator,
    SecurityGuard,
    DocumentFetcher,
    ClaimExtractor,
    ConflictDetector,
    MockKnowledgeProvider,
)


# =====================================================================
# 1. Critical Content-Hashing & Integrity Tests (Section 2.1)
# =====================================================================

def test_non_empty_document_produces_valid_reproducible_hash():
    """A non-empty document produces a valid, reproducible SHA-256 hash."""
    content = "The ordinary least squares estimator minimizes the sum of squared residuals: S(beta) = sum((y - X*beta)^2)."
    doc1 = RetrievedDocument(
        raw_url="https://example.com/ols",
        resolved_url="https://example.com/ols",
        title="OLS Specification",
        body_content=content,
        status_code=200
    )
    doc2 = RetrievedDocument(
        raw_url="https://example.com/ols",
        resolved_url="https://example.com/ols",
        title="OLS Specification",
        body_content=content,
        status_code=200
    )
    expected_hash = hashlib.sha256(" ".join(content.split()).encode("utf-8")).hexdigest()
    assert doc1.normalized_content_hash == expected_hash
    assert doc1.normalized_content_hash == doc2.normalized_content_hash
    assert doc1.content_hash == expected_hash
    assert doc1.is_empty is False


def test_changing_even_one_byte_changes_content_hash():
    """Cryptographic sensitivity: changing a single character alters the content hash completely."""
    content_a = "Hamiltonian total energy H = T + V = 0.5 * m * v^2 + m * g * h."
    content_b = "Hamiltonian total energy H = T + V = 0.5 * m * v^2 + m * g * H."  # One character change

    doc_a = RetrievedDocument(raw_url="https://nasa.gov/h1", resolved_url="https://nasa.gov/h1", title="H1", body_content=content_a, status_code=200)
    doc_b = RetrievedDocument(raw_url="https://nasa.gov/h2", resolved_url="https://nasa.gov/h2", title="H2", body_content=content_b, status_code=200)

    assert doc_a.normalized_content_hash != doc_b.normalized_content_hash
    assert doc_a.raw_content_hash != doc_b.raw_content_hash


def test_empty_content_explicitly_identified_and_rejected():
    """Empty content cannot masquerade as a valid retrieved document or verified evidence."""
    doc_empty = RetrievedDocument(
        raw_url="https://example.com/empty",
        resolved_url="https://example.com/empty",
        title="Empty Page",
        body_content="   \n\t  ",
        status_code=200
    )
    assert doc_empty.is_empty is True
    assert doc_empty.status_code == 204  # Explicit No Content
    assert "empty" in doc_empty.error_message.lower()

    # EvidenceRecord creation with empty excerpt is marked empty
    ev_empty = EvidenceRecord(
        evidence_id="ev_empty_1",
        title="Empty",
        canonical_url="https://example.com/empty",
        original_url="https://example.com/empty",
        source_type=SourceType.UNVERIFIED_WEB,
        publisher="example.com",
        author_or_organization="unknown",
        publication_date=None,
        retrieval_timestamp=time.time(),
        retrieval_provider="mock",
        exact_excerpt="",
        content_hash="empty_hash"
    )
    assert ev_empty.is_empty is True


def test_truncated_content_distinguishable_from_complete():
    """Truncated content is explicitly tracked via is_truncated flag."""
    doc_complete = RetrievedDocument(
        raw_url="https://example.com/c", resolved_url="https://example.com/c",
        title="Complete", body_content="Small text", status_code=200, is_truncated=False
    )
    doc_truncated = RetrievedDocument(
        raw_url="https://example.com/t", resolved_url="https://example.com/t",
        title="Truncated", body_content="Large text stream...", status_code=200, is_truncated=True
    )
    assert doc_complete.is_truncated is False
    assert doc_truncated.is_truncated is True

    # Evaluator records risk for truncated document
    eval_trunc = SourceEvaluator.evaluate(doc_truncated)
    assert eval_trunc.evidence_completeness == "truncated"
    assert any("truncated" in r.lower() for r in eval_trunc.identified_risks)


def test_excerpt_stored_in_evidence_record_is_traceable():
    """Evidence record verifies that its excerpt actually exists in the source content."""
    body = "In gravitational N-body simulations, standard explicit Euler integration fails to conserve energy."
    doc = RetrievedDocument(raw_url="https://nasa.gov/nbody", resolved_url="https://nasa.gov/nbody", title="N-body", body_content=body, status_code=200)

    # Valid excerpt present in body
    ev_valid = EvidenceRecord(
        evidence_id="ev_1", title="N-body", canonical_url=doc.resolved_url, original_url=doc.raw_url,
        source_type=SourceType.INSTITUTIONAL_SPECIFICATION, publisher="nasa.gov", author_or_organization="NASA",
        publication_date=None, retrieval_timestamp=time.time(), retrieval_provider="mock",
        exact_excerpt="standard explicit Euler integration fails to conserve energy",
        content_hash=doc.content_hash,
        is_excerpt_traceable=("standard explicit Euler integration fails to conserve energy" in doc.body_content)
    )
    assert ev_valid.is_excerpt_traceable is True

    # Fabricated excerpt not present in body
    ev_fake = EvidenceRecord(
        evidence_id="ev_2", title="N-body", canonical_url=doc.resolved_url, original_url=doc.raw_url,
        source_type=SourceType.INSTITUTIONAL_SPECIFICATION, publisher="nasa.gov", author_or_organization="NASA",
        publication_date=None, retrieval_timestamp=time.time(), retrieval_provider="mock",
        exact_excerpt="Quantum gravitational wormholes provide faster than light warp propulsion",
        content_hash=doc.content_hash,
        is_excerpt_traceable=("Quantum gravitational wormholes" in doc.body_content)
    )
    assert ev_fake.is_excerpt_traceable is False


# =====================================================================
# 2. Multi-Dimensional Source Evaluation (Section 2.3)
# =====================================================================

def test_source_evaluation_separates_dimensions_and_avoids_false_precision():
    """Source evaluation computes distinct qualitative dimensions without false probability claims."""
    doc = RetrievedDocument(
        raw_url="https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.Ridge.html",
        resolved_url="https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.Ridge.html",
        title="Ridge Regression - Scikit-Learn",
        body_content="""
        ### Ridge Regression and Tikhonov Regularization
        Minimizes the objective function:
        $$L(w) = ||y - Xw||_2^2 + \\alpha ||w||_2^2$$
        ```python
        def ridge_fit(X, y, alpha=1.0):
            # Analytical solution: w = (X^T X + alpha * I)^(-1) X^T y
            pass
        ```
        Proof of invertibility: adding alpha * I guarantees strict positive definiteness.
        """,
        status_code=200
    )
    evaluation = SourceEvaluator.evaluate(doc, domain="machine_learning", key_terms=["ridge", "regularization"])

    # Multi-dimensional attributes
    assert evaluation.publisher_authority >= 0.90
    assert evaluation.technical_specificity >= 0.80
    assert evaluation.methodological_quality >= 0.70
    assert evaluation.is_primary_source is True
    assert evaluation.version_compatibility == "modern_current"
    assert evaluation.evidence_completeness == "complete"
    # Composite rank has explicit non-probabilistic interpretation
    assert 0.0 <= evaluation.composite_heuristic_rank <= 1.0
    assert "NOT a probability of factual truth" in evaluation.rank_interpretation


# =====================================================================
# 3. Claim Extraction, Source Support, and Independent Verification (Section 2.4)
# =====================================================================

def test_claim_lifecycle_separates_source_support_from_independent_verification():
    """
    Validates explicit claim lifecycle:
    1. Claim extracted from text.
    2. Source support verified against excerpt.
    3. Independent verification conducted via numerical calculation, NOT LLM assertion.
    """
    ev = EvidenceRecord(
        evidence_id="ev_mse_01",
        title="Mean Squared Error Derivation",
        canonical_url="https://mathworld.wolfram.com/LeastSquares.html",
        original_url="https://mathworld.wolfram.com/LeastSquares.html",
        source_type=SourceType.ACADEMIC_TEXTBOOK,
        publisher="wolfram.com",
        author_or_organization="Eric Weisstein",
        publication_date=None,
        retrieval_timestamp=time.time(),
        retrieval_provider="mock",
        exact_excerpt="The Mean Squared Error loss is given by: $$L = \\frac{1}{N} \\sum_{i=1}^N (y_i - \\hat{y}_i)^2$$.",
        content_hash="h_mse_123",
        milestone_ids=["m1"]
    )

    claims = ClaimExtractor.extract_claims_from_evidence(ev)
    assert len(claims) >= 1
    mse_claim = claims[0]

    # Source support was verified
    assert mse_claim.status in (ClaimStatus.INDEPENDENTLY_VERIFIED, ClaimStatus.SOURCE_SUPPORTED_NOT_INDEPENDENTLY_VERIFIED)
    # Independent verification executed numerical identity check
    assert mse_claim.independent_verification_status == "verified"
    assert mse_claim.status == ClaimStatus.INDEPENDENTLY_VERIFIED


def test_unsupported_claim_marked_source_support_unconfirmed():
    """If a claim is not supported by the evidence excerpt, it is flagged source_support_unconfirmed."""
    ev = EvidenceRecord(
        evidence_id="ev_sorting",
        title="Quicksort",
        canonical_url="https://nist.gov/quicksort",
        original_url="https://nist.gov/quicksort",
        source_type=SourceType.INSTITUTIONAL_SPECIFICATION,
        publisher="nist.gov",
        author_or_organization="NIST",
        publication_date=None,
        retrieval_timestamp=time.time(),
        retrieval_provider="mock",
        exact_excerpt="Quicksort is a divide-and-conquer algorithm with expected time O(n log n).",
        content_hash="h_sort",
        milestone_ids=["m1"]
    )
    unrelated_claim = TechnicalClaim(
        claim_id="cl_unrelated",
        claim_text="General relativity predicts gravitational redshift near massive stellar bodies.",
        claim_type="physics",
        blueprint_field="tech",
        milestone_id="m1"
    )
    is_supported = ClaimExtractor.validate_source_support(unrelated_claim, ev)
    assert is_supported is False
    assert unrelated_claim.status == ClaimStatus.SOURCE_SUPPORT_UNCONFIRMED


# =====================================================================
# 4. Deep SSRF & Security Hardening (Section 2.5)
# =====================================================================

def test_ssrf_guard_blocks_dns_rebinding_and_private_resolutions(monkeypatch):
    """Guards against DNS rebinding where a public domain resolves to a private IP."""
    # Simulate a domain that resolves to 127.0.0.1
    import socket
    def mock_getaddrinfo(host, port):
        if "rebind.example.com" in host:
            return [(socket.AF_INET, socket.SOCK_STREAM, 6, "", ("127.0.0.1", 80))]
        elif "metadata-spoof.com" in host:
            return [(socket.AF_INET, socket.SOCK_STREAM, 6, "", ("169.254.169.254", 80))]
        return [(socket.AF_INET, socket.SOCK_STREAM, 6, "", ("93.184.216.34", 80))]

    monkeypatch.setattr(socket, "getaddrinfo", mock_getaddrinfo)

    safe1, reason1 = SecurityGuard.validate_url("http://rebind.example.com/exploit", resolve_dns=True)
    assert safe1 is False
    assert "resolves to forbidden IP '127.0.0.1'" in reason1

    safe2, reason2 = SecurityGuard.validate_url("http://metadata-spoof.com/latest", resolve_dns=True)
    assert safe2 is False
    assert "resolves to forbidden IP '169.254.169.254'" in reason2

    safe3, reason3 = SecurityGuard.validate_url("http://example.com/safe", resolve_dns=True)
    assert safe3 is True
    assert reason3 is None


def test_document_fetcher_prevents_redirect_to_private_ip(monkeypatch):
    """DocumentFetcher checks every hop in a redirect chain, blocking hops to internal IPs."""
    class MockRedirectSession:
        def get(self, url, **kwargs):
            class MockResp:
                def __init__(self, status, headers):
                    self.status_code = status
                    self.headers = headers
                    self.encoding = "utf-8"
                def iter_content(self, chunk_size):
                    return [b""]
            if url == "http://public-site.com/redirect":
                # First hop attempts to redirect to AWS metadata endpoint
                return MockResp(302, {"Location": "http://169.254.169.254/latest/meta-data/"})
            return MockResp(200, {})

    fetcher = DocumentFetcher(session=MockRedirectSession())
    doc = fetcher.fetch("http://public-site.com/redirect")
    assert doc.status_code == 403
    assert "SSRF / Security Block" in doc.error_message


# =====================================================================
# 5. Conflict Detection & Disciplinary Reconciliation (Section 2.6)
# =====================================================================

def test_conflict_detection_distinguishes_conflict_types():
    """Detects methodological differences and differing definitions without falsely treating them as contradictions."""
    ev_pop = EvidenceRecord(
        evidence_id="e_pop", title="Population Variance", canonical_url="https://stats.org/pop",
        original_url="https://stats.org/pop", source_type=SourceType.ACADEMIC_TEXTBOOK,
        publisher="stats.org", author_or_organization="Stats", publication_date=None,
        retrieval_timestamp=time.time(), retrieval_provider="mock",
        exact_excerpt="The population variance divides the sum of squared differences by 1/N.", content_hash="h_p"
    )
    ev_sample = EvidenceRecord(
        evidence_id="e_samp", title="Sample Variance", canonical_url="https://stats.org/sample",
        original_url="https://stats.org/sample", source_type=SourceType.ACADEMIC_TEXTBOOK,
        publisher="stats.org", author_or_organization="Stats", publication_date=None,
        retrieval_timestamp=time.time(), retrieval_provider="mock",
        exact_excerpt="The sample variance divides by 1/(N-1) using Bessel's correction for unbiased estimation.", content_hash="h_s"
    )

    claims = [
        TechnicalClaim(claim_id="c_pop", claim_text="Variance 1/N", claim_type="statistical", blueprint_field="math", milestone_id="m1"),
        TechnicalClaim(claim_id="c_samp", claim_text="Variance 1/(N-1)", claim_type="statistical", blueprint_field="math", milestone_id="m1")
    ]

    conflicts = ConflictDetector.detect_conflicts(claims, [ev_pop, ev_sample])
    assert len(conflicts) >= 1
    conf = conflicts[0]
    assert conf.conflict_type == ConflictType.DIFFERING_DEFINITIONS
    assert conf.is_genuine_disagreement is False
    assert "Bessel" in conf.description
    assert conf.resolution_status == "resolved"


# =====================================================================
# 6. Complete 7-Stage Traceability Matrix Integrity (Section 2.7)
# =====================================================================

def test_traceability_matrix_bidirectional_lookups_and_validation():
    """Validates complete referential integrity, forward trace, and reverse trace."""
    bp = BlueprintEngine.create_blueprint("Build a balanced AVL Tree in Python", difficulty=6, domain="algorithms")
    retriever = KnowledgeRetriever(search_provider=MockKnowledgeProvider())
    pkg = retriever.retrieve_for_blueprint(bp)

    # Validate referential integrity
    is_valid, errors = KnowledgeRetriever.validate_traceability_matrix(pkg, bp)
    assert is_valid is True, f"Referential errors: {errors}"

    # Forward trace from first evidence record
    first_ev_id = pkg.evidence_records[0]["evidence_id"]
    forward = KnowledgeRetriever.forward_trace(pkg, first_ev_id)
    assert forward["evidence_id"] == first_ev_id
    assert len(forward["supported_claims"]) > 0

    # Reverse trace from first milestone
    first_m_id = bp["milestones"][0]["id"]
    reverse = KnowledgeRetriever.reverse_trace(pkg, first_m_id)
    assert reverse["milestone_id"] == first_m_id
    assert len(reverse["grounding_claims"]) > 0
